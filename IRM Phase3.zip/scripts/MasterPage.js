var cityList =[
	{
		"managerName" : "OPPENHEIMER",
		"fundType" : "FII",
		"managerNumber" : "75092267",
		"profitPercentage" : "4.70532"
	},
	{
		"managerName"  : "OPPENHEIMER",
		"fundType" : "FIIR",
		"managerNumber" : "75092267",
		"profitPercentage" : "4.70532"
	},
	{
		"managerName"  : "OPPENHEIMER",
		"fundType" : "FIIR",
		"managerNumber" : "75092267",
		"profitPercentage" : "4.70532"
	}
];
$m.juci.addDataset("listVisible","");
var cityId="";
//$m.juci.addDataset("dataCategoriesInCity", dataCategoriesInCity);