var x2js = new X2JS();
var dbHelper;
$m.juci.addDataset("countryDetails", []);
$m.juci.addDataset("countryName", "INDIA");

$m.onReady(function(){
	$m.pageTitle("Country Details");
	$m.pageTitleLeftButton('<img id="menu" class="menuimage" src="images/Backward.png"></img>');
	/*$m.pageTitleRightButton('<img id="menu" class="menuimage" src="images/more.png""></img>');*/
});

$m.onData(function(event){
	var data = event.data;
	$m.juci.dataset("countryName", data);
	var countryDetails = [];
	var dbhelpercallback = function(db) {
		window.dbHelpher = db;
		holding_details.getCountryFundManager(data, function(res){
		console.log(res.rows);
		for(var i = 0 ; i < res.rows.length ; i++){
			res.rows[i].PERCENTAGE = res.rows[i].PERCENTAGE.toFixed(5);
		}
		for(var i = 0 ; i < res.rows.length ; i++){
			if(res.rows[i].STATUS == "BANK"){
				res.rows[i].STATUS = "BNK";
			}
			if(res.rows[i].STATUS == "CORP"){
				res.rows[i].STATUS = "CRP";
			}
			if(res.rows[i].STATUS == "TRUSTS"){
				res.rows[i].STATUS = "TRS";
			}
		}
		countryDetails = res.rows;
		if(res.rows.length == 0){
			$m.alert("No Cities found");
		}
		$m.juci.dataset("countryDetails", countryDetails);
	},function(fres){
		$m.alert("No Fund Managers found");
	});
    };
    getDbhelper(dbhelpercallback);
});

function redirectToCityDetails(event){
	$m.open("City Details","/IRM2/CityDetails.html", event.target.innerText);
}