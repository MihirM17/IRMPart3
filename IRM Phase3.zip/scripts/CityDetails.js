var x2js = new X2JS();
var dbHelper;
$m.juci.addDataset("cityList", []);

$m.onReady(function(){
	$m.pageTitle("City Details");
	$m.pageTitleLeftButton('<img id="menu" class="menuimage" src="images/Backward.png"></img>');
	/*$m.pageTitleRightButton('<img id="menu" class="menuimage" src="images/more.png""></img>');*/
});

$m.onData(function(event){
	var data = event.data;
	var cityDetails = [];
	var dbhelpercallback = function(db) {
		window.dbHelpher = db;
		holding_details.getCityFundManager(data, function(res){
		console.log(res.rows);
		for(var i = 0 ; i < res.rows.length ; i++){
			res.rows[i].PERCENTAGE = res.rows[i].PERCENTAGE.toFixed(5);
		}
		for(var i = 0 ; i < res.rows.length ; i++){
			if(res.rows[i].STATUS == "BANK"){
				res.rows[i].STATUS = "BNK";
			}
			if(res.rows[i].STATUS == "CORP"){
				res.rows[i].STATUS = "CRP";
			}
			if(res.rows[i].STATUS == "TRUSTS"){
				res.rows[i].STATUS = "TRS";
			}
		}
		cityDetails = res.rows;
		$m.juci.dataset("cityList", cityDetails);
	},function(fres){
		$m.alert("No Fund Managers found");
	});
    };
    getDbhelper(dbhelpercallback);
});

function redirectToInteractionList(event){
	$m.open("Searching...", "/IRM2/InteractionList.html", event.target.textContent)
}