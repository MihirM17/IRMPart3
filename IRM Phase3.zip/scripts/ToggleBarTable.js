var FundManagerList=[{
					"manager_id": 1,
					"FUND_MANAGER":"OPPENHEIMER",
					"TYPE":"FII",
					"NUMBER":"75092267",
					"PERCENT":"4.70532"
					},
					{
					"manager_id": 2,
					"FUND_MANAGER":"OPPENHEIMER",
					"TYPE":"FII",
					"NUMBER":"75092267",
					"PERCENT":"4.70532"
					},
					{
					"manager_id": 3,
					"FUND_MANAGER":"OPPENHEIMER",
					"TYPE":"FII",
					"NUMBER":"75092267",
					"PERCENT":"4.70532"
					},
					{
					"manager_id": 4,
					"FUND_MANAGER":"OPPENHEIMER",
					"TYPE":"FII",
					"NUMBER":"75092267",
					"PERCENT":"4.70532"
					},
					{
					"manager_id": 5,
					"FUND_MANAGER":"OPPENHEIMER",
					"TYPE":"FII",
					"NUMBER":"75092267",
					"PERCENT":"4.70532"
					},
					{
					"manager_id": 6,
					"FUND_MANAGER":"OPPENHEIMER",
					"TYPE":"FII",
					"NUMBER":"75092267",
					"PERCENT":"4.70532"
					}];

$m.juci.addDataset("fundManagerInformation",FundManagerList);