var sync_time_detailsTableName = "sync_time_details";
// Constructor
function sync_time_details(obj){
	var columns = sync_time_details.getColumns();
	for(var i=0; i<columns.length; i++){
		if(typeof obj[columns[i].name] === "string"){
			obj[columns[i].name] = obj[columns[i].name].replace(/,/g , "");
		}
		this[columns[i].name] = obj[columns[i].name] ? obj[columns[i].name] : columns[i].objdefault;
	}
} 

// Prototype methods
sync_time_details.lastSync = function(success_callback,failure_callback){
	var query = "select * from sync_time_details";
	window.dbHelper.db.executeSql(query, success_callback,failure_callback,[]);
};

sync_time_details.prototype.insert = function(success_callback,failure_callback){
	window.dbHelper.Insert(sync_time_detailsTableName,this).execute(success_callback,failure_callback);
};

sync_time_details.prototype.remove = function(success_callback,failure_callback){
	var filter = new DB.Filter.equal("customerid", "'" + this.customerid + "'");
	window.dbHelper.Delete(sync_time_detailsTableName,this).setFilter(filter).execute(success_callback,failure_callback);
};

sync_time_details.prototype.update = function(success_callback,failure_callback){
	window.dbHelper.Replace(sync_time_detailsTableName,this).execute(success_callback,failure_callback);
};

// Static Helpers
sync_time_details.createTable = function(success_callback,failure_callback){
	window.dbHelper.CreateTable(sync_time_detailsTableName, this.getColumns(),true).execute(success_callback,failure_callback);
};

sync_time_details.alterTable = function(columns, success_callback,failure_callback){
	window.dbHelper.AlterTable(sync_time_detailsTableName, columns).execute(success_callback,failure_callback);
};

sync_time_details.multipleInsert = function(entity, success_callback,failure_callback,inc_cb){
	window.dbHelper.MultiInsert(sync_time_detailsTableName, getKeyColums(this.getColumns()), entity, success_callback, inc_cb);
};

sync_time_details.multipleReplace = function(entity,success_callback,failure_callback){
	window.dbHelper.MultiReplace(sync_time_detailsTableName,getKeyColums(this.getColumns()), entity, success_callback, function inc_cb(tName, incrCounter, rowsInserted) {
		$m.logInfo(tName + '---' + rowsInserted + 'record(s) inserted successfully');
		$m.showProgress("Sync Time Details "  + rowsInserted + 'record(s) inserted successfully');
	});
};


sync_time_details.selectHolding = function(success_callback,failure_callback){
	var query = "select * from sync_time_details order by SHARESHELD DESC,RECORDDATE DESC LIMIT 15";
	window.dbHelper.db.executeSql(query, success_callback,failure_callback,[]);
};

sync_time_details.removeAll = function(success_callback,failure_callback){
	var query = "delete from sync_time_details";
	window.dbHelper.db.executeSql(query, success_callback,failure_callback,[]);
};

sync_time_details.multipleDelete = function(filter,success_callback,failure_callback){
	window.dbHelper.Delete(sync_time_detailsTableName,this).setFilter(filter).execute(success_callback,failure_callback);
};

sync_time_details.Select = function(success_callback,failure_callback){
	//var filter = new window.DB.Filter.equal("todelete", "'0'");
	window.dbHelper.Select(sync_time_detailsTableName, null,false).execute(function(response){
		if($m.isWeb()){
			response = JSON.parse(JSON.stringify(response));
		}
		success_callback(response);
	},failure_callback);
};

sync_time_details.SelectWithFilter = function(a,success_callback,failure_callback){
	var filter = new DB.Filter.equal("tempapplid", "'" + a + "'");
	var deletefilter = new window.DB.Filter.equal("todelete", "'0'");
	var andfilter = new DB.CompositeFilter(DB.CompositeFilter.AND,[deletefilter,filter]);
	window.dbHelper.Select(sync_time_detailsTableName, null,false).setFilter(andfilter).execute(function(response){
		if($m.isWeb()){
			response = JSON.parse(JSON.stringify(response));
		}
		//$m.logInfo(JSON.stringify(response));
		success_callback(response);
	},failure_callback);
};

sync_time_details.UpdateTable = function(data,filter,success_callback,failure_callback) {
	window.dbHelper.Update(sync_time_detailsTableName,data)
	.setFilter(filter)
	.execute(success_callback,failure_callback);
};

sync_time_details.selectDataToSync = function(readSuccess,readFailure){
	var filter = new window.DB.Filter.equal("issync", "'0'");
	window.dbHelper.Select(sync_time_detailsTableName,null,false)
	.setFilter(filter)
	.execute(function(response){
		if($m.isWeb()){
			response = JSON.parse(JSON.stringify(response));
		}
		var rows = [], resultsetLength = response.rows.length;
		for(var i=0; i<resultsetLength; i++){
			rows.push(new sync_time_details(response.rows[i]));
		}
		readSuccess(rows);
	},readFailure);
};

sync_time_details.multipleDataInsert = function(info,inc_cb,success_callback,failure_callback){
	window.dbHelper.MultiReplace(sync_time_detailsTableName,getKeyColums(holding_details.getColumns()), info, success_callback,inc_cb);
};

sync_time_details.updateSync = function(data,filter,success_callback,failure_callback) {
	window.dbHelper.Update(sync_time_detailsTableName,data)
	.setFilter(filter)
	.execute(success_callback,failure_callback);
};

sync_time_details.getColumns = function(){
	return [
			{"name" : "HOLDINGTIME",						"datatype" : "VARCHAR",						"objdefault" :''},
			{"name" : "MASTERTIME",							"datatype" : "VARCHAR",						"objdefault" :''},
			{"name" : "INTERACTIONTIME",					"datatype" : "VARCHAR",						"objdefault" :''}
		];
}; 

window.sync_time_details = sync_time_details;