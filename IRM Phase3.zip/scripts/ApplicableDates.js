var applicable_datesTableName = "applicable_dates";
// Constructor
function applicable_dates(obj){
	var columns = applicable_dates.getColumns();
	for(var i=0; i<columns.length; i++){
		if(typeof obj[columns[i].name] === "string"){
			obj[columns[i].name] = obj[columns[i].name].replace(/,/g , "");
		}
		this[columns[i].name] = obj[columns[i].name] ? obj[columns[i].name] : columns[i].objdefault;
	}
} 

// Prototype methods
applicable_dates.selectAll = function(success_callback, failure_callback){
	var query = "select * from applicable_dates";
	window.dbHelper.db.executeSql(query, success_callback,failure_callback,[]);
};

applicable_dates.prototype.insert = function(success_callback,failure_callback){
	window.dbHelper.Insert(applicable_datesTableName,this).execute(success_callback,failure_callback);
};

applicable_dates.prototype.remove = function(success_callback,failure_callback){
	var filter = new DB.Filter.equal("customerid", "'" + this.customerid + "'");
	window.dbHelper.Delete(applicable_datesTableName,this).setFilter(filter).execute(success_callback,failure_callback);
};

applicable_dates.prototype.update = function(success_callback,failure_callback){
	window.dbHelper.Replace(applicable_datesTableName,this).execute(success_callback,failure_callback);
};

// Static Helpers
applicable_dates.createTable = function(success_callback,failure_callback){
	window.dbHelper.CreateTable(applicable_datesTableName, this.getColumns(),true).execute(success_callback,failure_callback);
};

applicable_dates.alterTable = function(columns, success_callback,failure_callback){
	window.dbHelper.AlterTable(applicable_datesTableName, columns).execute(success_callback,failure_callback);
};

applicable_dates.multipleInsert = function(entity, success_callback,failure_callback,inc_cb){
	window.dbHelper.MultiInsert(applicable_datesTableName, getKeyColums(this.getColumns()), entity, success_callback, inc_cb);
};

applicable_dates.multipleReplace = function(entity,success_callback,failure_callback){
	window.dbHelper.MultiReplace(applicable_datesTableName,getKeyColums(this.getColumns()), entity, success_callback, function inc_cb(tName, incrCounter, rowsInserted) {
		$m.logInfo(tName + '---' + rowsInserted + 'record(s) inserted successfully');
		$m.showProgress("Applicable Dates "  + rowsInserted + 'record(s) inserted successfully');
	});
};


applicable_dates.selectHolding = function(success_callback,failure_callback){
	var query = "select * from applicable_dates order by SHARESHELD DESC,RECORDDATE DESC LIMIT 15";
	window.dbHelper.db.executeSql(query, success_callback,failure_callback,[]);
};

applicable_dates.removeAll = function(success_callback,failure_callback){
	var query = "delete from applicable_dates";
	window.dbHelper.db.executeSql(query, success_callback,failure_callback,[]);
};

applicable_dates.multipleDelete = function(filter,success_callback,failure_callback){
	window.dbHelper.Delete(applicable_datesTableName,this).setFilter(filter).execute(success_callback,failure_callback);
};

applicable_dates.Select = function(success_callback,failure_callback){
	//var filter = new window.DB.Filter.equal("todelete", "'0'");
	window.dbHelper.Select(applicable_datesTableName, null,false).execute(function(response){
		if($m.isWeb()){
			response = JSON.parse(JSON.stringify(response));
		}
		success_callback(response);
	},failure_callback);
};

applicable_dates.SelectWithFilter = function(a,success_callback,failure_callback){
	var filter = new DB.Filter.equal("tempapplid", "'" + a + "'");
	var deletefilter = new window.DB.Filter.equal("todelete", "'0'");
	var andfilter = new DB.CompositeFilter(DB.CompositeFilter.AND,[deletefilter,filter]);
	window.dbHelper.Select(applicable_datesTableName, null,false).setFilter(andfilter).execute(function(response){
		if($m.isWeb()){
			response = JSON.parse(JSON.stringify(response));
		}
		//$m.logInfo(JSON.stringify(response));
		success_callback(response);
	},failure_callback);
};

applicable_dates.UpdateTable = function(data,filter,success_callback,failure_callback) {
	window.dbHelper.Update(applicable_datesTableName,data)
	.setFilter(filter)
	.execute(success_callback,failure_callback);
};

applicable_dates.selectDataToSync = function(readSuccess,readFailure){
	var filter = new window.DB.Filter.equal("issync", "'0'");
	window.dbHelper.Select(applicable_datesTableName,null,false)
	.setFilter(filter)
	.execute(function(response){
		if($m.isWeb()){
			response = JSON.parse(JSON.stringify(response));
		}
		var rows = [], resultsetLength = response.rows.length;
		for(var i=0; i<resultsetLength; i++){
			rows.push(new applicable_dates(response.rows[i]));
		}
		readSuccess(rows);
	},readFailure);
};

applicable_dates.multipleDataInsert = function(info,inc_cb,success_callback,failure_callback){
	window.dbHelper.MultiReplace(applicable_datesTableName,getKeyColums(holding_details.getColumns()), info, success_callback,inc_cb);
};

applicable_dates.updateSync = function(data,filter,success_callback,failure_callback) {
	window.dbHelper.Update(applicable_datesTableName,data)
	.setFilter(filter)
	.execute(success_callback,failure_callback);
};

applicable_dates.getColumns = function(){
	return [
			{"name" : "RECORDDATE",						"datatype" : "DATE",						"objdefault" :''},
			{"name" : "DISPLAYDATE",					"datatype" : "VARCHAR",						"objdefault" :''}
		];
}; 

window.applicable_dates = applicable_dates;