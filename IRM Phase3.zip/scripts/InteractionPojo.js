var interaction_detailsTableName = "interaction_details";
// Constructor
function interaction_details(obj){
	var columns = interaction_details.getColumns();
	for(var i=0; i<columns.length; i++){
		if(typeof obj[columns[i].name] === "string"){
			obj[columns[i].name] = obj[columns[i].name].replace(/,/g , "");
		}
		this[columns[i].name] = obj[columns[i].name] ? obj[columns[i].name] : columns[i].objdefault;
	}
}

// Prototype methods
interaction_details.getLastRecord = function(data,success_callback,failure_callback){
	var basequery = "select * from interaction_details where NAME_OF_PERSON like '%"+data+"%' and DATE_OF_INT = (select max(DATE_OF_INT) from interaction_details where NAME_OF_PERSON like '%"+data+"%')";
	window.dbHelper.db.executeSql(basequery, success_callback, failure_callback,[]);
};
interaction_details.getFundManagers = function(success_callback,failure_callback){
	var basequery = "select DISTINCT NAME_OF_PERSON from interaction_details";
	window.dbHelper.db.executeSql(basequery, success_callback, failure_callback,[]);
};
interaction_details.getAccompainedBy = function(success_callback,failure_callback){
	var basequery = "select DISTINCT ACCOMPANIED_BY from interaction_details";
	window.dbHelper.db.executeSql(basequery, success_callback, failure_callback,[]);
};
interaction_details.getInvestors = function(success_callback,failure_callback){
	var basequery = "select DISTINCT FUND_NAME from interaction_details";
	window.dbHelper.db.executeSql(basequery, success_callback, failure_callback,[]);
};
interaction_details.getBrokerageHouse = function(success_callback,failure_callback){
	var basequery = "select DISTINCT BROKERAGE_HOUSE from interaction_details";
	window.dbHelper.db.executeSql(basequery, success_callback, failure_callback,[]);
};
interaction_details.getCountry = function(success_callback,failure_callback){
	var basequery = "select DISTINCT COUNTRY_OF_MEETING from interaction_details";
	window.dbHelper.db.executeSql(basequery, success_callback, failure_callback,[]);
};
interaction_details.getCity = function(success_callback,failure_callback){
	var basequery = "select DISTINCT CITY_OF_MEETING from interaction_details";
	window.dbHelper.db.executeSql(basequery, success_callback, failure_callback,[]);
};
interaction_details.getLocationOfMeeting = function(success_callback,failure_callback){
	var basequery = "select DISTINCT LOCATION_OF_MEETING from interaction_details";
	window.dbHelper.db.executeSql(basequery, success_callback, failure_callback,[]);
};
interaction_details.searchInteraction = function(data,success_callback,failure_callback){
	var basequery = "select * from interaction_details WHERE ";
	var query_flag  = 1;
	if(!(data.fromDate[0] === "" || data.fromDate[0] === undefined)){
		if(query_flag == 1){
			basequery += "DATE_OF_INT >= '"+data.fromDate[0].toString("yyyy-MM-dd")+"' and DATE_OF_INT < '"+data.fromDate[1].toString("yyyy-MM-dd")+"'";
			query_flag = 2;
		}
		else{
			basequery += " and DATE_OF_INT >= '"+data.fromDate[0].toString("yyyy-MM-dd")+"' and DATE_OF_INT < '"+data.fromDate[1].toString("yyyy-MM-dd")+"'";
		}
	}
	if(data.nameOfFundManager){
		if(query_flag == 1){
			basequery += " FUND_NAME like '%"+data.nameOfFundManager+"%'";
			query_flag = 2;
		}
		else{
			basequery += " and FUND_NAME like '%"+data.nameOfFundManager+"%'";
		}
	}
	if(data.accompainedBy){
		if(query_flag == 1){
			basequery += " ACCOMPANIED_BY like '%"+data.accompainedBy+"%'";
			query_flag = 2;
		}
		else{
			basequery += " and ACCOMPANIED_BY like '%"+data.accompainedBy+"%'";
		}
	}
	if(data.nameOfInvestor){
		if(query_flag == 1){
			basequery += " NAME_OF_PERSON like '%"+data.nameOfInvestor+"%'";
			query_flag = 2;
		}
		else{
			basequery += " and NAME_OF_PERSON like '%"+data.nameOfInvestor+"%'";
		}
	}
	if(data.selectedInteractionType){
		if(query_flag == 1){
			basequery += " TYPE_OF_INT like '%"+data.selectedInteractionType+"%'";
			query_flag = 2;
		}
		else{
			basequery += " and TYPE_OF_INT like '%"+data.selectedInteractionType+"%'";
		}
	}
	if(data.brokerageHouse){
		if(query_flag == 1){
			basequery += " BROKERAGE_HOUSE like '%"+data.brokerageHouse+"%'";
			query_flag = 2;
		}
		else{
			basequery += " and BROKERAGE_HOUSE like '%"+data.brokerageHouse+"%'";
		}
	}
	if(data.selectedMetBy){
		if(query_flag == 1){
			basequery += " MET_BY like '%"+data.selectedMetBy+"%'";
			query_flag = 2;
		}
		else{
			basequery += " and MET_BY like '%"+data.selectedMetBy+"%'";
		}
	}
	if(data.selectedAlsoAttended){
		if(query_flag == 1){
			basequery += " ALSO_ATTENDED like '%"+data.selectedAlsoAttended+"%'";
			query_flag = 2;
		}
		else{
			basequery += " and ALSO_ATTENDED like '%"+data.selectedAlsoAttended+"%'";
		}
	}
	if(data.selectedCity){
		if(query_flag == 1){
			basequery += " CITY_OF_MEETING like '%"+data.selectedCity+"%'";
			query_flag = 2;
		}
		else{
			basequery += " and CITY_OF_MEETING like '%"+data.selectedCity+"%'";
		}
	}
	window.dbHelper.db.executeSql(basequery, success_callback,failure_callback,[]);
};

interaction_details.prototype.insert = function(data,success_callback,failure_callback){
	window.dbHelper.Insert(interaction_detailsTableName,this).execute(success_callback,failure_callback);
};

interaction_details.prototype.remove = function(success_callback,failure_callback){
	var filter = new DB.Filter.equal("customerid", "'" + this.customerid + "'");
	window.dbHelper.Delete(interaction_detailsTableName,this).setFilter(filter).execute(success_callback,failure_callback);
};

interaction_details.prototype.update = function(success_callback,failure_callback){
	window.dbHelper.Replace(interaction_detailsTableName,this).execute(success_callback,failure_callback);
};

// Static Helpers
interaction_details.createTable = function(success_callback,failure_callback){
	window.dbHelper.CreateTable(interaction_detailsTableName, this.getColumns(),true).execute(success_callback,failure_callback);
};

interaction_details.alterTable = function(columns, success_callback,failure_callback){
	window.dbHelper.AlterTable(interaction_detailsTableName, columns).execute(success_callback,failure_callback);
};

interaction_details.multipleInsert = function(entity, success_callback,failure_callback,inc_cb){
	window.dbHelper.MultiInsert(interaction_detailsTableName, getKeyColums(this.getColumns()), entity, success_callback, inc_cb);
};

interaction_details.multipleReplace = function(entity,success_callback,failure_callback){
	window.dbHelper.MultiReplace(interaction_detailsTableName,getKeyColums(this.getColumns()), entity, success_callback, function inc_cb(tName, incrCounter, rowsInserted) {
		$m.logInfo(tName + '---' + rowsInserted + 'record(s) inserted successfully');
		$m.showProgress("Interaction details " + rowsInserted + 'record(s) inserted successfully');
	});
};

interaction_details.removeAll = function(success_callback,failure_callback){
	var query = "delete from interaction_details";
	window.dbHelper.db.executeSql(query, success_callback,failure_callback,[]);
};

interaction_details.selectInteraction = function(data,success_callback,failure_callback){
//	data = data.replace(/\w\S*/g,//function(txt){return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();	});	*/
	var query = "select * from interaction_details where FUND_NAME = '"+data+"'";
	window.dbHelper.db.executeSql(query, success_callback,failure_callback,[]);
};

interaction_details.multipleDelete = function(filter,success_callback,failure_callback){
	window.dbHelper.Delete(interaction_detailsTableName,this).setFilter(filter).execute(success_callback,failure_callback);
};

interaction_details.Select = function(success_callback,failure_callback){
	window.dbHelper.Select(interaction_detailsTableName, null,false).execute(function(response){
		if($m.isWeb()){
			response = JSON.parse(JSON.stringify(response));
		}
		//$m.logInfo(JSON.stringify(response));
		success_callback(response);
	},failure_callback);
};


interaction_details.UpdateTable = function(data,success_callback,failure_callback) {
	window.dbHelper.Update(interaction_detailsTableName,data).execute(success_callback,failure_callback);
};


interaction_details.searchfilter = function(query,success_callback,failure_callback){
/*	window.dbHelper.Select(interaction_detailsTableName, null,false).setFilter(filter).execute(function(response){
		if($m.isWeb()){
			response = JSON.parse(JSON.stringify(response));
		}
		success_callback(response);
	},failure_callback);*/
 	window.dbHelper.db.executeSql(query, success_callback,failure_callback,[]);
};

interaction_details.selectDataToSync = function(readSuccess,readFailure){
	var filter = new window.DB.Filter.equal("issync", "'0'");
	window.dbHelper.Select(interaction_detailsTableName,null,false)
	.setFilter(filter)
	.execute(function(response){
		if($m.isWeb()){
			response = JSON.parse(JSON.stringify(response));
		}
		var rows = [], resultsetLength = response.rows.length;
		for(var i=0; i<resultsetLength; i++){
			rows.push(new interaction_details(response.rows[i]));
		}
		readSuccess(rows);
	},readFailure);
};

interaction_details.multipleDataInsert = function(info,inc_cb,success_callback,failure_callback){
	window.dbHelper.MultiReplace(interaction_detailsTableName,getKeyColums(interaction_details.getColumns()), info, success_callback,inc_cb);
};

interaction_details.updateSync = function(data,filter,success_callback,failure_callback) {
	window.dbHelper.Update(interaction_detailsTableName,data)
	.setFilter(filter)
	.execute(success_callback,failure_callback);
};

interaction_details.getColumns = function(){
	return [
			{"name" : "SRNO",					"datatype" : "INTEGER PRIMARY KEY",			"objdefault" :''},
			{"name" : "DATE_OF_INT",			"datatype" : "DATE",						"objdefault" :''},
			{"name" : "MEETINGNO",				"datatype" : "INTEGER",						"objdefault" :''},
			{"name" : "NAME_OF_PERSON",			"datatype" : "VARCHAR",						"objdefault" :''},
			{"name" : "ACCOMPANIED_BY",			"datatype" : "VARCHAR",						"objdefault" :''},
			{"name" : "GROUP_NAME",				"datatype" : "VARCHAR",						"objdefault" :''},
			{"name" : "FUND_NAME",				"datatype" : "VARCHAR",						"objdefault" :''},
			{"name" : "TYPE_OF_INT",			"datatype" : "VARCHAR",						"objdefault" :''},
			{"name" : "BROKERAGE_HOUSE",		"datatype" : "VARCHAR",						"objdefault" :''},
			{"name" : "CITY_OF_MEETING",		"datatype" : "VARCHAR",						"objdefault" :''},
			{"name" : "LOCATION_OF_MEETING",	"datatype" : "VARCHAR",						"objdefault" :''},
			{"name" : "MET_BY",					"datatype" : "VARCHAR",						"objdefault" :''},
			{"name" : "ALSO_ATTENDED",			"datatype" : "VARCHAR",						"objdefault" :''},
			{"name" : "IS_LOCAL_CONFERENCES",	"datatype" : "VARCHAR",						"objdefault" :''},
			{"name" : "COUNTRY_OF_MEETING",		"datatype" : "VARCHAR",						"objdefault" :''}
		];
}; 

window.interaction_details = interaction_details;