(function() {
    $m.onResume(function() {
        scrollTop();
    });

    function prependRs(x) {
        if (typeof x === "function") {
            x = x();
        }
        x = roundTo2(x);
        var isNegative = false;
        if (x < 0) {
            x = x * -1;
            isNegative = true;
        }
        var prependAmount = "₹ " + (x ? rupeeFormat(x) : '0');
        if (isNegative) {
            prependAmount = "-" + prependAmount
        }
        return prependAmount;
    }
    
    function rupeeFormat(nStr) {
        nStr += '';
        var x = nStr.split('.');
        var x1 = x[0];
        var x2 = x.length > 1 ? '.' + x[1] : '';
        var rgx = /(\d+)(\d{3})/;
        var z = 0;
        var len = String(x1).length;
        var num = parseInt((len / 2) - 1, 10);

        while (rgx.test(x1)) {
            if (z > 0) {
                x1 = x1.replace(rgx, '$1' + ',' + '$2');
            } else {
                x1 = x1.replace(rgx, '$1' + ',' + '$2');
                rgx = /(\d+)(\d{2})/;
            }
            z++;
            num--;
            if (num === 0) {
                break;
            }
        }
        return x1 + x2;
    }

    function roundTo2(v) {
        return Math.round(v * 100) / 100;
    }

    function getDbhelper(callback) {
        new window.DB(Constants.DBName, function(dbHelper) {
            window.dbHelper = dbHelper;
            callback(window.dbHelper);

        }, function(error) {
            $m.logError("Unable to open database due to -- " + JSON.stringify(error));
        });

    }
    
   function pojoselect(tablename,callback){
	 var dbhelpercallback = function(dbhelper) {
        if (dbhelper) {
        	 window[tablename].Select(function(res) {
                   callback(res);
            }, function(res) {
                $m.alert("Error while Fecthing from database");
                $m.logError("Read failed -- " + JSON.stringify(res));
            });
          
        } else {
            $m.alert("Error while opening database");
        }
    };
    Utils.GetDbhelper(dbhelpercallback);	
}
  function pojoselectwithfilter(tablename,callback,data){
	 var dbhelpercallback = function(dbhelper) {
        if (dbhelper) {
        	 window[tablename].SelectWithFilter(data,function(res) {
                   callback(res);
            }, function(res) {
                $m.alert("Error while Fecthing from database");
                $m.logError("Read failed -- " + JSON.stringify(res));
            });
          
        } else {
            $m.alert("Error while opening database");
        }
    };
    Utils.GetDbhelper(dbhelpercallback);	
}

function getUserName(){
	var username = $m.getUsername();
	if(!username){
		username = $m.getPref("userid");
	}
	return username;
//return 70094582;
}

function pojoselectbyOrder(tablename,callback,filter){
	 var dbhelpercallback = function(dbhelper) {
        if (dbhelper) {
        	 window[tablename].SelectByOrder(function(res) {
                   callback(res);
            }, function(res) {
                $m.alert("Error while Fecthing from database");
                $m.logError("Read failed -- " + JSON.stringify(res));
            });
          
        } else {
            $m.alert("Error while opening database");
        }
    };
    Utils.GetDbhelper(dbhelpercallback);	
}

function generateTempAppId(){
	var userid = $m.getUsername();
	if(!userid){
		userid = "70270441";
	}
	var date = new Date().toString("dd-MM-yyyy HH:mm:ss");
	var tempid = date.split(" ");
	var logindate = tempid[0].split("-");
	var logintime = tempid[1].split(":");
	for(var i=0;i<logindate.length;i++){
		userid = userid.concat(logindate[i]);
	}
	for(var i=0;i<logintime.length;i++){
		userid = userid.concat(logintime[i]);
	}
	return userid;			
}

 function pojoupdatetable(tablename,callback,data,filter,failcallback){
	 var dbhelpercallback = function(dbhelper) {
        if (dbhelper) {
        	window[tablename].UpdateTable(data,filter,function(res) {
                   callback(res);
            }, function(res) {
            	   failcallback(res);
                $m.alert("Error while updating to database");
            $m.logError("Failed to update "+tablename + "--- " + JSON.stringify(res));
            });
          
        } else {
            $m.alert("Error while opening database");
        }
    };
    Utils.GetDbhelper(dbhelpercallback);	
}

 function pojoupdate(tablename,callback,tabledata){
	 var dbhelpercallback = function(dbhelper) {
        if (dbhelper) {
        	 tabledata.update(function(res) {
                   callback(res);
            }, function(res) {
            $m.alert("Error while inserting to database");
	        $m.logError("Failed to insert " + tablename + "--- " + JSON.stringify(res));
            });
          
        } else {
            $m.alert("Error while opening database");
        }
    };
    Utils.GetDbhelper(dbhelpercallback);	
}
function pojoremove(tablename,callback,tabledata){
	 var dbhelpercallback = function(dbhelper) {
        if (dbhelper) {
        	 tabledata.remove(function(res) {
                   callback(res);
            }, function(res) {
            $m.alert("Error while deleting to database");
	        $m.logError("Failed to delete " + tablename + "--- " + JSON.stringify(res));
            });
          
        } else {
            $m.alert("Error while opening database");
        }
    };
    Utils.GetDbhelper(dbhelpercallback);	
}


    function showDialog(id) {
        juci.openPanel(id);
    }

    function hideDialog(id) {
        juci.closePanel(id);
    }

    function showPopup() {
        var popupClass = "popup";
        var popupElement = $m.juci.findByClass("popup");
        popupElement[0].show();
    }

    function hidePopup() {
        var popupClass = "popup";
        var popupElement = $m.juci.findByClass("popup");
        popupElement[0].hide();
    }

    function openPage(pageName, pageUrl, data, progressmessage) {
        /*	var options = {
        	  "openHamburger": "true",
        	  "hamburgerPages": [
        	    {
        	      "name": "Left Page",
        	      "url": "/InstaLife/menu.html",
        	      "type": "right",
        	      "width": 75
        	    }
        	  ],
        	  "showProgress": false
        	};*/
        $m.open(pageName, pageUrl, data, {progressMsg:progressmessage});
    }

    function setProgress(index) {
        if (index != -1) {
            try {
                var progressElement = $m.juci.findByClass("progress_line");
                progressElement[0].el.style.width = (index / Constants.TotalPages) * 100 + "%";
            } catch (e) {

            }
        }
    }

    function getTimeStamp() {
        return new Date().getTime();
    }

    function putPref(key, value) {
        $m.putPref(key, value);
        $m.savePref();
    }

    function getPref(key) {
        return $m.getPref(key);
    }
    
    function setResult(key) {
         $m.setResult(key);
    }
    
    function closepage() {
         $m.close();
    }
    
    function decode_base64 (s){
	    var e = {}, i, k, v = [], r = '', w = String.fromCharCode;
	    var n = [[65, 91], [97, 123], [48, 58], [43, 44], [47, 48]];
	
	    for (var z in n)
	    {
	        for (i = n[z][0]; i < n[z][1]; i++)
	        {
	            v.push(w(i));
	        }
	    }
	    for (i = 0; i < 64; i++)
	    {
	        e[v[i]] = i;
	    }
	
	    for (i = 0; i < s.length; i+=72)
	    {
	        var b = 0, c, x, l = 0, o = s.substring(i, i+72);
	        for (x = 0; x < o.length; x++)
	        {
	            c = e[o.charAt(x)];
	            b = (b << 6) + c;
	            l += 6;
	            while (l >= 8)
	            {
	                r += w((b >>> (l -= 8)) % 256);
	            }
	         }
	    }
	    return r;
	}

    function getAge(dob) {
        var today = new Date();
        var birthDate = new Date(dob);
        var age = today.getFullYear() - birthDate.getFullYear();
        var m = today.getMonth() - birthDate.getMonth();
        if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
            age--;
        }
        return age;
    }

    function getDate(date) {
        var dateString = "";

        if (typeof date === "string") {
            var dateSplit = date.split("/");
            date = dateSplit[1] + "/" + dateSplit[0] + "/" + dateSplit[2];
        }

        if (date) {
            dateString = new Date(date).toString("dd/MM/yyyy");
        } else {
            dateString = new Date().toString("dd/MM/yyyy");
        }
        return dateString;
    }


    function getRandomNum() {
        var min = 100000;
        var max = 999999;
        var num = Math.floor(Math.random() * (max - min + 1)) + min;
        return num;
    }

    function getSingleRandom() {
        var min = 0;
        var max = 9;
        var num = Math.floor(Math.random() * (max - min + 1)) + min;
        return num;
    }
    
    function setTimeStamp(date){
    	if(typeof date == "object"){
    		date.setHours(0,0,0,0);
    		return new Date(date).getTime();
    	}
    	else {
    		return date;
    	}
    }

    function getMinutes() {
        var startTime = new Date("01/01/2015").getTime();
        var currentTime = new Date().getTime();
        var timeDiff = currentTime - startTime;
        var numMin = Math.round(timeDiff / 60000).toString();
        var paddings = "0000000000000000";
        var requiredDigits = 7;
        var actuallDigits = requiredDigits - numMin.length;
        if (actuallDigits > 0) {
            numMin = paddings.substr(0, actuallDigits) + numMin;
        }
        return numMin;
    }



    function toUpperCase(name) {
        if (name) {
            name = name.replace(/\w+/g, function(txt) {
                return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();
            });
        }
        return name;
    }

    function scrollTop() {
        var pageBodyElem = document.getElementById("page-body");
        if (pageBodyElem) {
            pageBodyElem.scrollTop = 0;
        }
    }

    function getDateFormat(dateObj) {
        if (typeof dateObj == "function") {
            dateObj = dateObj();
        }
        if (dateObj) {
            var date = new Date(dateObj);
            return date.toString("yyyy-MM-dd HH:mm:ss");
        }
        return 0;
    }

    function getControl(id) {
        var control = $m.juci.getControl(id);
        return control;
    }

    function fireRequest(requestName, requestContent, callback) {
        if (!callback) {
            callback = function() {};
        }
        var url = "";
        url = window.Constants.ServiceUrl;
        if (false) {
            if (!callback) {
                callback = function() {};
            }
            var url = "";
            if ($m.isWeb()) {
                url = window.Constants.ServiceUrl;
                url = url + "?data=" + JSON.stringify(requestContent);
            } else {
                url = window.Constants.ServiceUrl + "?uname=" + $m.httpRequest.getUsernamePlaceholder() + "&pwd=" + $m.httpRequest.getPasswordPlaceholder();
                url = url + "&data=" + JSON.stringify(requestContent);
            }
            var xmlhttp = new XMLHttpRequest();
            xmlhttp.onreadystatechange = function() {
                if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {
                    var resultData = JSON.parse(xmlhttp.responseText);
                    callback(resultData);
                }
            };
            xmlhttp.open("POST", url, true);
            xmlhttp.send();
        } else {
            requestContent = {
                "data": $m.isWeb() ? encodeURIComponent(JSON.stringify(requestContent)) : requestContent
            };
            $m.post(url, requestContent, function(response) {
                if (response.code == 200) {
                    try {
                        var result = JSON.parse(response.result.data);
                        //$m.logInfo(requestName + " Success : Response " + JSON.stringify(response) + " Callback - " + callback);
                    } catch (e) {
                        result = response.result;
                        $m.logError(requestName + " Failed : Response " + JSON.stringify(response));
                    }
                    callback(result);
                } else {
                    $m.logError(requestName + " Failed : Response " + JSON.stringify(response) + "Message " + errMsg);
                    var errMsg = response.error.message;
                    if (response.code == 401) {
                        if ($m.isWeb()) {
                            window.reload();
                        }
                    }
                    callback(null);
                }
            });
        }
    }

    function generateUUID() {
        var d = new Date().getTime();
        var uuid = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
            var r = (d + Math.random() * 16) % 16 | 0;
            d = Math.floor(d / 16);
            return (c == 'x' ? r : (r & 0x7 | 0x8)).toString(16);
        });
        return uuid;
    }


    function getDaysInMonth(month, year) {
        return new Date(year, month, 0).getDate();
    }

    function check(str) {
        var tmp = {};
        for (var i = str.length - 1; i >= 0; i--) {
            var c = str.charAt(i);
            if (c in tmp) {
                tmp[c] += 1;
            } else {
                tmp[c] = 1;
            }
        }
        var result = {};
        for (var c in tmp) {
            if (tmp.hasOwnProperty(c)) {
                if (tmp[c] > 1) {
                    result[c] = tmp[c];
                }
            }
        }
        return result;
    }

    function checkObservable(data) {
        if (typeof data === "function") {
            data = ko.toJS(data);
        }
       else  if (typeof data === "object") {
            data = ko.toJS(data);
        }
        return data;
    }

    function checkRepetition(str) {
        var repetedChar = check(str);
        var isValid = true;
        for (var key in repetedChar) {
            if (repetedChar[key] > 2) {
                var repitionStr = key + key + key;
                var isNumber = isNaN(parseInt(repitionStr));
                if (str.indexOf(repitionStr) != -1 && isNumber) {
                    return false;
                }
            }
        }
        return isValid;
    }
	
	function setValueFromOptions(optionsDsId, value, comparator){
		var optionsDs = $m.juci.getDataset(optionsDsId)();
		var optionsLength = optionsDs.length;
		var v;
		for(var i = 0; i < optionsLength; i++){
			if(comparator(optionsDs[i],value)){
				v = optionsDs[i];
				break;
			}
		}
		return v ? v : value;
}
    function checkEndsWith(value) {
        var lastChar = value.substring(value.length - 1);
        if (lastChar === " ") {
            return false;
        }
        return true;
    }
    
    function setResult(key) {
		$m.setResult(key);
	}

	function closepage() {
		$m.close();
	}
	
	function getDeviceId(deviceCallback){
		$m.getDeviceId(deviceCallback);
	}

	/*function getLocation(time,boolean,callback) {
		$m.getLocation({
			"enableHighAccuracy":boolean,
			"timeout": time
		}, function(response) {
			if (response.code) {
				// Success
				latitude = response.result.position.coords.latitude;
				longitude = response.result.position.coords.longitude;
				if (callback) {
					callback(latitude, longitude);
				}
			} else if (response.error.message == "Request timed out") {
				// Error
				var errMsg = response.error.message;
				$m.alert("Please enable GPS Location", "GPS Message", function() {
					Utils.ClosePage();
				});
			}
		});
	}*/
	function confirmBox(displaytText,yesCallback,noCallback){
		$m.confirm({
			"title": "Confirm",
			"message": displaytText,
			"buttons": [{
					"label": "Yes"
				},
				{
					"label": "No"
				}
			]
		}, function(index) {
			if (index == 0) {
				yesCallback();
			} else if (index == 1) {
				noCallback();
			}
		});
	}
	
	function getRandomNum() {
		var min = 10000000;
		var max = 99999999;
		var num = Math.floor(Math.random() * (max - min + 1)) + min;
		return num;
	}
	
    window.Utils = {
        "PrependRs": prependRs,
        "ShowPopup": showPopup,
        "HidePopup": hidePopup,
        "OpenPage": openPage,
        "ShowDialog": showDialog,
        "HideDialog": hideDialog,
        "SetProgress": setProgress,
        "GetTimeStamp": getTimeStamp,
        "GetUserName": getUserName,
        "GetDbhelper": getDbhelper,
        "PutPref": putPref,
        "GetControl": getControl,
        "GenerateUUID": generateUUID,
        "FireRequest": fireRequest,
        "CheckObservable": checkObservable,
        "GetPref": getPref,
        "GetAge": getAge,
        "GetDate": getDate,
        "ToUpperCase": toUpperCase,
        "CheckRepetition": checkRepetition,
        "CheckEndsWith": checkEndsWith,
        "SetTimeStamp" :setTimeStamp,
        "ScrollTop":scrollTop,
        "PojoSelect":pojoselect,
        "PojoSelectByOrder":pojoselectbyOrder,
        "PojoSelectWithFilter":pojoselectwithfilter,
        "PojoUpdateTable":pojoupdatetable,
        "PojoUpdate":pojoupdate,
        "PojoRemove":pojoremove,
        "SetResult":setResult,
        "ClosePage":closepage,
        "GenerateTempAppId" : generateTempAppId,
        "DecodeBase64":decode_base64,
        "ConfirmBox":confirmBox,
        "GetRandomNum" :getRandomNum,
        "GetDateFormat":getDateFormat,
        "setValueFromOptions":setValueFromOptions
    };
})();
