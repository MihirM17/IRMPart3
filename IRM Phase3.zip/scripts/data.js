function complexComparator(i1, i2){
	if(i2.name){
		return i1.name == i2.name;
	}else{
		return i1 == i2;
	}
	
}


function formatValue(valueFromControl){
//	console.log(valueFromControl);
	if(valueFromControl.name == "ALL"){
		return valueFromControl.name;
	}
	else if(valueFromControl.name == "DOMESTIC"){
		return valueFromControl.name;
	}
	else if(valueFromControl.name == "FOREIGN"){
		return valueFromControl.name;
	}
	else
		return valueFromControl;	
}
function change(e){
	//e.control._control.refresh();
	console.log("change" + e.newValue);
}
//
function returnValue(valueFromControl){
	if(valueFromControl !== null)
	return valueFromControl.name;	
}
//
//

//juci.addDataset("complexValue", {value: "1", name: "red"});
//juci.addDataset("simpleValue", "red");
//juci.addDataset("Helo",["red","blue","yellow"]);

//juci.addDataset("options", [{name : "ne"}, {name :"blue"}, {name :"green"}]);

juci.addDataset("options", [{name : "parent1" , children  :[{name: "child1" , j :"Saads"}]}, {name :"parent2" , children  :[{name: "child21"} ,{name: "child22"}]}, {name :"parent3" , children  :[{name: "child31"} , {name: "child32"}]}]);
juci.addDataset("answer",{name: "parent1"} );