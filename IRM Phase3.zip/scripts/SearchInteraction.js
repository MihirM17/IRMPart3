$m.onReady(function(){
	$m.pageTitle("Interaction Search");
	$m.pageTitleLeftButton('<img id="menu" class="menuimage" src="images/menu-icon.png"></img>');
	/*$m.pageTitleRightButton('<img id="menu" class="menuimage" src="images/more.png"></img>');*/
	$m.juci.findById("__leftBtn").onClick(function(){openMenu(1);});
});

$m.juci.addDataset("interactiontype", ["83573489", "1234214"]);
$m.juci.addDataset("metBy", ["Meeting at Office", "1234214"]);
$m.juci.addDataset("also_attened",["Meeting at Office"]);
$m.juci.addDataset("fundNameList", []);
$m.juci.addDataset("accompainedByList", []);
$m.juci.addDataset("investors", []);
$m.juci.addDataset("brokerageHouseList", []);
$m.juci.addDataset("country", []);

var searchInteraction = {
	"fromDate" : [],
	"nameOfFundManager"	: "",
	"accompainedBy"	: "",
	"nameOfInvestor" : "",
	"selectedInteractionType" : "",
	"brokerageHouse" : "",
	"selectedMetBy" : "",
	"selectedAlsoAttended" : "",
	"selectedCity" : ""
};
$m.juci.addDataset("searchInteraction", searchInteraction);

$m.onResume(function(){
	var searchInteraction = {
		"fromDate" : [],
		"nameOfFundManager"	: "",
		"accompainedBy"	: "",
		"nameOfInvestor" : "",
		"selectedInteractionType" : "",
		"brokerageHouse" : "",
		"selectedMetBy" : "",
		"selectedAlsoAttended" : "",
		"selectedCity" : ""
	};
	$m.juci.dataset("searchInteraction", searchInteraction);
});

$m.onData(function() {
	getDbhelper();
	IRMServices.getIntType("", callbackforIntType);
	IRMServices.getMetBy("", callbackforMetBy);
});

var x2js = new X2JS();

function getDbhelper(callback) {
		new window.DB(Constants.DBName, function(db) {
		window.dbHelper = db;
		dbHelper = db;
		getFundName();
		getAccompainedBy();
		getInvestor();
		getBrokerageHouse();
		getCountry();
	//	callback(window.dbHelper);
	}, function(error) {
		$m.logError("Unable to open database due to -- " + JSON.stringify(error));
	});
}

function getFundName(){
	interaction_details.getFundManagers(function(res){
		$m.juci.dataset("fundNameList", res.rows);
		document.getElementById("interactionList").style.display = "none";
		getAccompainedBy();
	}, function(fresp){
		$m.alert("No result found");
	});
}

function getAccompainedBy(){
	interaction_details.getAccompainedBy(function(res){
			$m.juci.dataset("accompainedByList", res.rows);
			document.getElementById("accompained-by-list").style.display = "none";
		}, function(fresp){
			$m.alert("No result found");
		});
}

function getInvestor(){
	interaction_details.getInvestors(function(res){
		$m.juci.dataset("investors", res.rows);
		document.getElementById("investor-list").style.display = "none";
	}, function(fresp){
		$m.alert("No result found");
	});
}

function getBrokerageHouse(){
	interaction_details.getBrokerageHouse(function(res){
		$m.juci.dataset("brokerageHouseList", res.rows);
		document.getElementById("brokerage-house-list").style.display = "none";
	}, function(fresp){
		$m.alert("No result found");
	});
}

var callbackforIntType = function(resp){
	var response = x2js.xml_str2json(resp.data);
	var interaction_type = response["Envelope"]["Body"]["P_GET_IRM_INT_TYPEResponse"]["P_GET_IRM_INT_TYPEResult"];
	
	interaction_type = JSON.parse(interaction_type);
	$m.juci.dataset("interactiontype", interaction_type.Table);
};
var callbackforMetBy = function(resp){
	var response = x2js.xml_str2json(resp.data);
	var metBy = response["Envelope"]["Body"]["P_GET_IRM_METBYResponse"]["P_GET_IRM_METBYResult"];
	
	metBy = JSON.parse(metBy);
	var metByArray = [];
	var alsoAttendedArray = [];
	for(var i = 0 ;i < metBy.Table.length; i++){
		if(metBy.Table[i].TYPE == "A"){
			alsoAttendedArray.push(metBy.Table[i].MET_BY);
		}
		else{
			metByArray.push(metBy.Table[i].MET_BY);
		}
	}
	$m.juci.dataset("metBy", metByArray);
	$m.juci.dataset("also_attened", alsoAttendedArray);
};

function getSelectedInteractionType(obj){
	return obj.TYPE_OF_INT;
}
function getSelectedMetBy(obj){
	return obj.MET_BY;
}

function validateSearchInteraction(){
	var interactionDetails = $m.juci.dataset("searchInteraction");
	var regExnameOfFundManager = /^[A-Z|a-z0-9\s]{2,50}$/;
	var regExaccompainedBy = /^[A-Z|a-z0-9\s]{2,50}$/;
	var regExnameOfInvestor = /^[A-Z|a-z0-9\s]{2,50}$/;
	var regExbrokerageHouse = /^[A-Z|a-z0-9\s]{2,50}$/;
	
	if(!(interactionDetails.fromDate[0] === null)){
		if((interactionDetails.fromDate[1] === null)){
			$m.alert("For searching by date : both fields should be filled");
			return;
		}
	}
	if(!(interactionDetails.fromDate[1] === null)){
		if((interactionDetails.fromDate[0] === null)){
			$m.alert("For searching by date : both fields should be filled");
			return;
		}
	}
	if((!interactionDetails.nameOfFundManager === "") && !regExnameOfFundManager.test(interactionDetails.nameOfFundManager)){
		$m.alert("Fund Manager is Invalid ");
		return;
	}
	if((!interactionDetails.accompainedBy === "") && !regExaccompainedBy.test(interactionDetails.accompainedBy)){
		$m.alert("Accompained By is Invalid ");
		return;
	}
	if((!interactionDetails.nameOfInvestor === "") && !regExnameOfInvestor.test(interactionDetails.nameOfInvestor)){
		$m.alert("Investor is Invalid ");
		return;
	}
	if((!interactionDetails.brokerageHouse === "") && !regExbrokerageHouse.test(interactionDetails.brokerageHouse)){
		$m.alert("Brokerage House is Invalid ");
		return;
	}
	var searchData  = $m.juci.dataset("searchInteraction");
	var searchInteraction = {
		"fromDate" : [],
		"nameOfFundManager"	: "",
		"accompainedBy"	: "",
		"nameOfInvestor" : "",
		"selectedInteractionType" : "",
		"brokerageHouse" : "",
		"selectedMetBy" : "",
		"selectedAlsoAttended" : "",
		"selectedCity" : ""
	};
	searchData.selectedInteractionType = searchData.selectedInteractionType ? searchData.selectedInteractionType.TYPE_OF_INT : "";
	$m.showProgress("Searching...");
	interaction_details.searchInteraction(searchData, function(res){
		$m.juci.dataset("interactionList",res.rows);
		if(res.rows.length == 0){
			$m.hideProgress();
			$m.alert("No result found");
			return;
		}
		else{
			$m.hideProgress();
			$m.open("Searching...", "/IRM2/List.html" , res.rows,hamburgeroptions);
		}
	}, function(fresp){
		$m.hideProgress();
		$m.alert("No result found");
	});
}

function validate(InteractionDetails) {
   var errorObj = {
       "key": key,
       "error": "Filled"
   };
   for (var key in InteractionDetails) {
       if (!InteractionDetails[key]) {
           errorObj.key = key;
           errorObj.error = "Empty";
           return errorObj;
       }
   }
   return false;
}

function searchFundName() {
	// Declare variables
	var input, filter, i;
	input = document.getElementById('fund-name').children[3].value;
	filter = input.toUpperCase();
	if(!filter){
		document.getElementById("interactionList").style.display = "none";
		return;
	}
	var interactionList = $m.juci.dataset("fundNameList");
	// Loop through all list items, and hide those who don't match the search query
	document.getElementById("interactionList").style.display = "block";
	for (i = 0; i < interactionList.length; i++) {
		if (interactionList[i].NAME_OF_PERSON.toUpperCase().indexOf(filter) > -1) {
			document.getElementById("fund-name-id_"+i).style.display = "";
		}else {
			document.getElementById("fund-name-id_"+i).style.display = "none";
		}
	}
}

function setFundName(event){
	var data = JSON.parse(ko.toJSON(event));
	var list = $m.juci.getDataset("searchInteraction")();
	list.nameOfFundManager(data.NAME_OF_PERSON);
	interaction_details.getLastRecord(data.NAME_OF_PERSON,function(res){
		console.log(res.rows);
		var response = {
			"nameOfFundManager"	: res.rows[0].NAME_OF_PERSON,
			"nameOfInvestor" : res.rows[0].FUND_NAME,
			"selectedCountryOfInvestor": res.rows[0].COUNTRY_OF_MEETING
		};
		$m.juci.dataset("searchInteraction", response);
	},function(fres){
		$m.alert("No result found");
	});
	document.getElementById("interactionList").style.display = "none";
}

function searchAccompainedBy() {
	// Declare variables
	var input, filter, i;
	input = document.getElementById('accompained-by').children[3].value;
	filter = input.toUpperCase();
	if(!filter){
		document.getElementById("accompained-by-list").style.display = "none";
		return;
	}
	var accompainedByList = $m.juci.dataset("accompainedByList");
	// Loop through all list items, and hide those who don't match the search query
	document.getElementById("accompained-by-list").style.display = "block";
	for (i = 0; i < accompainedByList.length; i++) {
		if (accompainedByList[i].ACCOMPANIED_BY.toUpperCase().indexOf(filter) > -1) {
			document.getElementById("accompained-by-id_"+i).style.display = "";
		}else {
			document.getElementById("accompained-by-id_"+i).style.display = "none";
		}
	}
}

function setAccompainedBy(event){
	var data = JSON.parse(ko.toJSON(event));
	var list = $m.juci.getDataset("searchInteraction")();
	list.accompainedBy(data.ACCOMPANIED_BY);
	document.getElementById("accompained-by-list").style.display = "none";
}

function searchInvestor() {
	// Declare variables
	var input, filter, i;
	input = document.getElementById('investor').children[3].value;
	filter = input.toUpperCase();
	if(!filter){
		document.getElementById("investor-list").style.display = "none";
		return;
	}
	var List = $m.juci.dataset("investors");
	// Loop through all list items, and hide those who don't match the search query
	document.getElementById("investor-list").style.display = "block";
	for (i = 0; i < List.length; i++) {
		if (List[i].FUND_NAME.toUpperCase().indexOf(filter) > -1) {
			document.getElementById("investor-id_"+i).style.display = "";
		}else {
			document.getElementById("investor-id_"+i).style.display = "none";
		}
	}
}

function setInvestor(event){
	var data = JSON.parse(ko.toJSON(event));
	var list = $m.juci.getDataset("searchInteraction")();
	list.nameOfInvestor(data.FUND_NAME);
	document.getElementById("investor-list").style.display = "none";
}

function searchBrokerageHouse() {
	// Declare variables
	var input, filter, i;
	input = document.getElementById('brokerage-house').children[3].value;
	filter = input.toUpperCase();
	if(!filter){
		document.getElementById("brokerage-house-list").style.display = "none";
		return;
	}
	var List = $m.juci.dataset("brokerageHouseList");
	// Loop through all list items, and hide those who don't match the search query
	document.getElementById("brokerage-house-list").style.display = "block";
	for (i = 0; i < List.length; i++) {
		if (List[i].BROKERAGE_HOUSE.toUpperCase().indexOf(filter) > -1) {
			document.getElementById("brokerage-house-id_"+i).style.display = "";
		}else {
			document.getElementById("brokerage-house-id_"+i).style.display = "none";
		}
	}
}

function setBrokerageHouse(event){
	var data = JSON.parse(ko.toJSON(event));
	var list = $m.juci.getDataset("searchInteraction")();
	list.brokerageHouse(data.BROKERAGE_HOUSE);
	document.getElementById("brokerage-house-list").style.display = "none";
}

function getCountry(){
	interaction_details.getCity(function(res){
		$m.juci.dataset("country", res.rows);
		document.getElementById("country-list").style.display = "none";
	}, function(fresp){
		$m.alert("No result found");
	});
}

function searchCountry() {
	// Declare variables
	var input, filter, i;
	input = document.getElementById('country').children[3].value;
	filter = input.toUpperCase();
	if(!filter){
		document.getElementById("country-list").style.display = "none";
		return;
	}
	var List = $m.juci.dataset("country");
	// Loop through all list items, and hide those who don't match the search query
	document.getElementById("country-list").style.display = "block";
	for (i = 0; i < List.length; i++) {
		if (List[i].CITY_OF_MEETING.toUpperCase().indexOf(filter) > -1) {
			document.getElementById("country-id_"+i).style.display = "";
		}else {
			document.getElementById("country-id_"+i).style.display = "none";
		}
	}
}

function setCountry(event){
	var data = JSON.parse(ko.toJSON(event));
	var list = $m.juci.getDataset("searchInteraction")();
	list.selectedCity(data.CITY_OF_MEETING);
	document.getElementById("country-list").style.display = "none";
}

function clearData(){
	var clear = {
		"fromDate" : [],
		"nameOfFundManager"	: "",
		"accompainedBy"	: "",
		"nameOfInvestor" : "",
		"selectedInteractionType" : "",
		"brokerageHouse" : "",
		"selectedMetBy" : "",
		"selectedAlsoAttended" : "",
		"selectedCity" : ""
	};
	$m.juci.addDataset("searchInteraction", clear);
}