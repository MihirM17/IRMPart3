var holding_detailsTableName = "holding_details";
// Constructor
function holding_details(obj){
	var columns = holding_details.getColumns();
	for(var i=0; i<columns.length; i++){
		if(typeof obj[columns[i].name] === "string"){
			obj[columns[i].name] = obj[columns[i].name].replace(/,/g , "");
		}
		this[columns[i].name] = obj[columns[i].name] ? obj[columns[i].name] : columns[i].objdefault;
	}
} 

// Prototype methods
holding_details.getMaxDate = function(success_callback, failure_callback){
	var query = "select max(RECORDDATE) as MAXDATE from holding_details";
	window.dbHelper.db.executeSql(query, success_callback, failure_callback);
}

holding_details.latestRecord = function(success_callback, failure_callback){
	var query = "select *, sum(SHARESHELD) as SUMSHARE, sum(HOLDINGPERCENTAGE) as PERCENTAGE from holding_details as hd where RECORDDATE = (select max(RECORDDATE) from holding_details where FUNDMANAGER = hd.FUNDMANAGER) group by hd.FUNDMANAGER";
	window.dbHelper.db.executeSql(query, success_callback, failure_callback);
};

holding_details.lastRecord = function(success_callback, failure_callback){
	var query = "select *, sum(SHARESHELD) as SUMSHARE, sum(HOLDINGPERCENTAGE) as PERCENTAGE from holding_details as hd where RECORDDATE = (select RECORDDATE from holding_details where FUNDMANAGER = hd.FUNDMANAGER order by RECORDDATE limit 1,1) group by hd.FUNDMANAGER";
	window.dbHelper.db.executeSql(query, success_callback, failure_callback);
};

holding_details.getRecords = function(data, success_callback, failure_callback){
	var query = "select *, sum(SHARESHELD) as SUMSHARE, sum(HOLDINGPERCENTAGE) as PERCENTAGE from holding_details where RECORDDATE = '"+data.toString("yyyy-MM-dd")+"' group by FUNDMANAGER order by SUMSHARE desc";
	window.dbHelper.db.executeSql(query, success_callback, failure_callback);
};

holding_details.dateSync = function(data, success_callback, failure_callback){
	var query = "select * from holding_details where RECORDDATE = '"+data.toString("yyyy-MM-dd")+"'";
	window.dbHelper.db.executeSql(query, success_callback,failure_callback,[]);
};

holding_details.syncFundManager = function(data, success_callback, failure_callback){
	var query = "select *, sum(SHARESHELD) as SUMSHARE, sum(HOLDINGPERCENTAGE) as PERCENTAGE from holding_details where RECORDDATE = '"+data.toString("yyyy-MM-dd")+"' group by FUNDMANAGER order by SUMSHARE desc limit 15";	
	window.dbHelper.db.executeSql(query, success_callback,failure_callback,[]);
};

holding_details.syncGroupName = function(data, success_callback, failure_callback){
	var query = "select *, sum(SHARESHELD) as SUMSHARE, sum(HOLDINGPERCENTAGE) as PERCENTAGE from holding_details where RECORDDATE = '"+data.toString("yyyy-MM-dd")+"' group by GROUPNAME order by SUMSHARE desc limit 15";	
	window.dbHelper.db.executeSql(query, success_callback,failure_callback,[]);
};

holding_details.syncCities = function(data, success_callback, failure_callback){
	var query = "select *, sum(SHARESHELD) as SUMSHARE, sum(HOLDINGPERCENTAGE) as PERCENTAGE from holding_details where RECORDDATE = '"+data.toString("yyyy-MM-dd")+"' and CITY != 'Not Defined' group by CITY order by SUMSHARE desc limit 15";
	window.dbHelper.db.executeSql(query, success_callback,failure_callback,[]);
};

holding_details.getCityFundManager = function(data, success_callback, failure_callback){
	var query = "select *, sum(SHARESHELD) as SUMSHARE, sum(HOLDINGPERCENTAGE) as PERCENTAGE from holding_details where CITY like '%"+data+"%' group by FUNDMANAGER order by SUMSHARE desc limit 15";
	window.dbHelper.db.executeSql(query, success_callback, failure_callback,[]);
};

holding_details.getCountryFundManager = function(data, success_callback, failure_callback){
	var query = "select *, sum(SHARESHELD) as SUMSHARE, sum(HOLDINGPERCENTAGE) as PERCENTAGE from holding_details where COUNTRY like '%"+data+"%' and CITY != 'Not Defined' group by CITY order by SUMSHARE desc limit 15";
	window.dbHelper.db.executeSql(query, success_callback, failure_callback,[]);
};

holding_details.syncCountry = function(data, success_callback, failure_callback){
	var query = "select *, sum(SHARESHELD) as SUMSHARE, sum(HOLDINGPERCENTAGE) as PERCENTAGE from holding_details where RECORDDATE = '"+data.toString("yyyy-MM-dd")+"' group by COUNTRY order by SUMSHARE desc limit 15";	
	window.dbHelper.db.executeSql(query, success_callback,failure_callback,[]);
};

holding_details.getGraphData = function(data,success_callback,failure_callback){
	var basequery = "select * from holding_details WHERE RECORDDATE >= '"+data.toString("yyyy-mm-dd")+"' and RECORDDATE < (select date_add(RECORDDATE,interval 7 day) as RECORDDATE_7)";
	window.dbHelper.db.executeSql(basequery, success_callback,failure_callback,[]);
};

holding_details.searchbuyers = function(data,success_callback,failure_callback){
	var basequery = "select *, sum(SHARESHELD) as SUMSHARE, sum(HOLDINGPERCENTAGE) as PERCENTAGE from holding_details as hd group by FUNDMANAGER having (select sum(SHARESHELD) as SUMSHARE from holding_details as hd1 group by FUNDMANAGER having hd1.FUNDMANAGER = hd.FUNDMANAGER and RECORDDATE <= '"+data.Today.toString("yyyy-mm-dd")+"') < (select sum(SHARESHELD) as SUMSHARE from holding_details as hd2 group by FUNDMANAGER having hd2.FUNDMANAGER = hd.FUNDMANAGER and RECORDDATE <= '"+data.lastDate.toString("yyyy-mm-dd")+"') order by SUMSHARE desc limit 15";
	window.dbHelper.db.executeSql(basequery, success_callback,failure_callback,[]);
};

holding_details.searchsellers = function(data,success_callback,failure_callback){
	var basequery = "select *, sum(SHARESHELD) as SUMSHARE, sum(HOLDINGPERCENTAGE) as PERCENTAGE from holding_details as hd group by FUNDMANAGER having (select sum(SHARESHELD) as SUMSHARE from holding_details as hd1 group by FUNDMANAGER having hd1.FUNDMANAGER = hd.FUNDMANAGER and RECORDDATE <= '"+data.Today.toString("yyyy-mm-dd")+"') > (select sum(SHARESHELD) as SUMSHARE from holding_details as hd2 group by FUNDMANAGER having hd2.FUNDMANAGER = hd.FUNDMANAGER and RECORDDATE <= '"+data.lastDate.toString("yyyy-mm-dd")+"') order by SUMSHARE desc limit 15";
	window.dbHelper.db.executeSql(basequery, success_callback,failure_callback,[]);
};

holding_details.prototype.insert = function(success_callback,failure_callback){
	window.dbHelper.Insert(holding_detailsTableName,this).execute(success_callback,failure_callback);
};

holding_details.prototype.remove = function(success_callback,failure_callback){
	var filter = new DB.Filter.equal("customerid", "'" + this.customerid + "'");
	window.dbHelper.Delete(holding_detailsTableName,this).setFilter(filter).execute(success_callback,failure_callback);
};

holding_details.prototype.update = function(success_callback,failure_callback){
	window.dbHelper.Replace(holding_detailsTableName,this).execute(success_callback,failure_callback);
};

// Static Helpers
holding_details.createTable = function(success_callback,failure_callback){
	window.dbHelper.CreateTable(holding_detailsTableName, this.getColumns(),true).execute(success_callback,failure_callback);
};

holding_details.alterTable = function(columns, success_callback,failure_callback){
	window.dbHelper.AlterTable(holding_detailsTableName, columns).execute(success_callback,failure_callback);
};

holding_details.multipleInsert = function(entity, success_callback,failure_callback,inc_cb){
	window.dbHelper.MultiInsert(holding_detailsTableName, getKeyColums(this.getColumns()), entity, success_callback, inc_cb);
};

holding_details.multipleReplace = function(entity,success_callback,failure_callback){
	window.dbHelper.MultiReplace(holding_detailsTableName,getKeyColums(this.getColumns()), entity, success_callback, function inc_cb(tName, incrCounter, rowsInserted) {
		$m.logInfo(tName + '---' + rowsInserted + 'record(s) inserted successfully');
		$m.showProgress("Holding Details "  + rowsInserted + 'record(s) inserted successfully');
	});
};


holding_details.selectHolding = function(success_callback,failure_callback){
	var query = "select * from holding_details order by SHARESHELD DESC,RECORDDATE DESC LIMIT 15";
	window.dbHelper.db.executeSql(query, success_callback,failure_callback,[]);
};

holding_details.searchFundManager = function(data,success_callback,failure_callback){
	var query = "select *, sum(SHARESHELD) as SUMSHARE, sum(HOLDINGPERCENTAGE) as PERCENTAGE from holding_details where FUNDMANAGER like '%"+data+"%' group by FUNDMANAGER ORDER BY SHARESHELD DESC,RECORDDATE DESC LIMIT 15";
	window.dbHelper.db.executeSql(query, success_callback,failure_callback,[]);
};

holding_details.searchGroupName = function(data,success_callback,failure_callback){
	var query = "select *, sum(SHARESHELD) as SUMSHARE, sum(HOLDINGPERCENTAGE) as PERCENTAGE from holding_details where GROUPNAME like '%"+data+"%' group by GROUPNAME ORDER BY SHARESHELD DESC,RECORDDATE DESC LIMIT 15";
	window.dbHelper.db.executeSql(query, success_callback,failure_callback,[]);
};

holding_details.searchBar = function(data,success_callback,failure_callback){
	var query = "";
	switch(data.toggle){
		case 'fund-manager':
			query = "select *, sum(SHARESHELD) as SUMSHARE, sum(HOLDINGPERCENTAGE) as PERCENTAGE from holding_details where FUNDMANAGER like '%"+data.value+"%' group by FUNDMANAGER order by SUMSHARE DESC limit 15";
			break;
		case 'group-name':
			query = "select *, sum(SHARESHELD) as SUMSHARE, sum(HOLDINGPERCENTAGE) as PERCENTAGE from holding_details where GROUPNAME like '%"+data.value+"%' group by GROUPNAME order by SUMSHARE DESC limit 15";
			break;
		case 'country':
			query = "select *, sum(SHARESHELD) as SUMSHARE, sum(HOLDINGPERCENTAGE) as PERCENTAGE from holding_details where COUNTRY like '%"+data.value+"%' group by COUNTRY order by SUMSHARE DESC limit 15";
			break;
		case 'city':
			query = "select *, sum(SHARESHELD) as SUMSHARE, sum(HOLDINGPERCENTAGE) as PERCENTAGE from holding_details where CITY like '%"+data.value+"%' group by CITY order by SUMSHARE DESC limit 15";
			break;
		case 'buyers':
			query = "select *, sum(SHARESHELD) as SUMSHARE, sum(HOLDINGPERCENTAGE) as PERCENTAGE from holding_details where FUNDMANAGER like '%"+data.value+"%' group by FUNDMANAGER order by SUMSHARE DESC limit 15";
			break;
		case 'sellers':
			query = "select *, sum(SHARESHELD) as SUMSHARE, sum(HOLDINGPERCENTAGE) as PERCENTAGE from holding_details where FUNDMANAGER like '%"+data.value+"%' group by FUNDMANAGER order by SUMSHARE DESC limit 15";
			break;
	}
	window.dbHelper.db.executeSql(query, success_callback,failure_callback,[]);
};

holding_details.getByConference = function(data,success_callback,failure_callback){
	var query;
	if(data.selectedvalue == "ALL"){
		query = "select *, sum(SHARESHELD) as SUMSHARE, sum(HOLDINGPERCENTAGE) as PERCENTAGE from holding_details where RECORDDATE = '"+data.date.toString("yyyy-MM-dd")+"' group by "+data.currentToggle+" order by SUMSHARE desc limit 15";
	}else if(data.selectedvalue == "DOM-ALL" || data.selectedvalue == "DOMESTIC"){
		query = "select *, sum(SHARESHELD) as SUMSHARE, sum(HOLDINGPERCENTAGE) as PERCENTAGE from holding_details where STATUS in ("+domestic+") and RECORDDATE = '"+data.date.toString("yyyy-MM-dd")+"' group by "+data.currentToggle+" order by SUMSHARE desc limit 15";
	}else if(data.selectedvalue == "FOR-ALL" || data.selectedvalue == "FOREIGN"){
		query = "select *, sum(SHARESHELD) as SUMSHARE, sum(HOLDINGPERCENTAGE) as PERCENTAGE from holding_details where STATUS in ("+foreign+") and RECORDDATE = '"+data.date.toString("yyyy-MM-dd")+"' group by "+data.currentToggle+" order by SUMSHARE desc limit 15";
	}
	else{
		query = "select *, sum(SHARESHELD) as SUMSHARE, sum(HOLDINGPERCENTAGE) as PERCENTAGE from holding_details where STATUS = '"+data.selectedvalue+"' and RECORDDATE = '"+data.date.toString("yyyy-MM-dd")+"' group by "+data.currentToggle+" order by SUMSHARE desc limit 15";
	}
	window.dbHelper.db.executeSql(query, success_callback,failure_callback,[]);
};

holding_details.removeAll = function(success_callback,failure_callback){
	var query = "delete from holding_details";
	window.dbHelper.db.executeSql(query, success_callback,failure_callback,[]);
};

holding_details.multipleDelete = function(filter,success_callback,failure_callback){
	window.dbHelper.Delete(holding_detailsTableName,this).setFilter(filter).execute(success_callback,failure_callback);
};

holding_details.Select = function(success_callback,failure_callback){
	//var filter = new window.DB.Filter.equal("todelete", "'0'");
	window.dbHelper.Select(holding_detailsTableName, null,false).execute(function(response){
		if($m.isWeb()){
			response = JSON.parse(JSON.stringify(response));
		}
		success_callback(response);
	},failure_callback);
};

holding_details.SelectWithFilter = function(a,success_callback,failure_callback){
	var filter = new DB.Filter.equal("tempapplid", "'" + a + "'");
	var deletefilter = new window.DB.Filter.equal("todelete", "'0'");
	var andfilter = new DB.CompositeFilter(DB.CompositeFilter.AND,[deletefilter,filter]);
	window.dbHelper.Select(holding_detailsTableName, null,false).setFilter(andfilter).execute(function(response){
		if($m.isWeb()){
			response = JSON.parse(JSON.stringify(response));
		}
		//$m.logInfo(JSON.stringify(response));
		success_callback(response);
	},failure_callback);
};

holding_details.UpdateTable = function(data,filter,success_callback,failure_callback) {
	window.dbHelper.Update(holding_detailsTableName,data)
	.setFilter(filter)
	.execute(success_callback,failure_callback);
};


holding_details.searchfilter = function(query,success_callback,failure_callback){
/*	window.dbHelper.Select(holding_detailsTableName, null,false).setFilter(filter).execute(function(response){
		if($m.isWeb()){
			response = JSON.parse(JSON.stringify(response));
		}
		success_callback(response);
	},failure_callback);*/
 	window.dbHelper.db.executeSql(query, success_callback,failure_callback,[]);
};

holding_details.getHoldingByManager = function(query,success_callback,failure_callback){
/*	window.dbHelper.Select(holding_detailsTableName, null,false).setFilter(filter).execute(function(response){
		if($m.isWeb()){
			response = JSON.parse(JSON.stringify(response));
		}
		success_callback(response);
	},failure_callback);*/
 	window.dbHelper.db.executeSql(query, success_callback,failure_callback,[]);
};



holding_details.selectDataToSync = function(readSuccess,readFailure){
	var filter = new window.DB.Filter.equal("issync", "'0'");
	window.dbHelper.Select(holding_detailsTableName,null,false)
	.setFilter(filter)
	.execute(function(response){
		if($m.isWeb()){
			response = JSON.parse(JSON.stringify(response));
		}
		var rows = [], resultsetLength = response.rows.length;
		for(var i=0; i<resultsetLength; i++){
			rows.push(new holding_details(response.rows[i]));
		}
		readSuccess(rows);
	},readFailure);
};

holding_details.multipleDataInsert = function(info,inc_cb,success_callback,failure_callback){
	window.dbHelper.MultiReplace(holding_detailsTableName,getKeyColums(holding_details.getColumns()), info, success_callback,inc_cb);
};

holding_details.updateSync = function(data,filter,success_callback,failure_callback) {
	window.dbHelper.Update(holding_detailsTableName,data)
	.setFilter(filter)
	.execute(success_callback,failure_callback);
};

holding_details.getColumns = function(){
	return [
			{"name" : "RECORDDATE",						"datatype" : "DATE",						"objdefault" :''},
			{"name" : "HOLDINGTYPE",					"datatype" : "VARCHAR",						"objdefault" :''},
			{"name" : "STATUS",							"datatype" : "VARCHAR",						"objdefault" :''},
			{"name" : "GROUPNAME",						"datatype" : "VARCHAR",						"objdefault" :''},
			{"name" : "FUNDMANAGER",					"datatype" : "VARCHAR",						"objdefault" :''},
			{"name" : "COUNTRY",						"datatype" : "VARCHAR",						"objdefault" :''},
			{"name" : "CITY",							"datatype" : "VARCHAR",						"objdefault" :''},
			{"name" : "SHARESHELD",						"datatype" : "VARCHAR",						"objdefault" :''},
			{"name" : "HOLDINGPERCENTAGE",				"datatype" : "VARCHAR",						"objdefault" :''},
			{"name" : "SHARECAPITAL",					"datatype" : "VARCHAR",						"objdefault" :''}
		];
}; 

window.holding_details = holding_details;