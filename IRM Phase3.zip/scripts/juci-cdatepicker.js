(function(){
	/**
		@namespace
		@name cdatepicker
		@augments basecontrol
		@description datepicker controls enables user to pick a date by opening a calendar. The calendar is opened after user taps on the control.
		@dataattribute {String} data-juci A string with value <i>datepicker</i>.
		@dataattribute {String} data-picker A string - Default - "cal", other - "dob"
		@html <div data-juci="cdatepicker" data-label="Datepicker" placeholder="Choose a date"></div>
		@html <div data-juci="cdatepicker" data-label="Datepicker with binding" data-bind="ref: dated"></div>
		@css .juci_cdatepicker_box
		@css .juci_cdatepicker_box.touch
		@csshtml <div data-juci="cdatepicker" data-label="Custom Datepicker" class="juci_basecontrol juci_datepicker juci_parent">
		<div class="juci_flag_drawer">
			<div class="juci_linker"></div>
		</div>
		<div class="juci_ctrl_label">
			<label class="juci_label_text">Datepicker</label>
			<div class="juci_label_flagctr"></div>
		</div>
		<div class="juci_ctrl_box juci_datepicker_box">Thu Jan 17 2013</div></div>
		@note The default return value for datepicker control is a <i>Date</i> object
		@see calendar
	*/
	
	var cdatepicker = function(elem){
		this._super = juci.controls.basepicker;
		this._super(elem);
	}
	cdatepicker.prototype = {
		type: "cdatepicker",
		DefaultFormatter: function(date){return date.toString(this._format);},
		DefaultCalendarTitle: '"Pick a date"',
		DefaultPlaceholder: "Pick a date...",
		DefaultValue: null,
		getDatabindConfig: function(){
			var r = this._super();
			juci.utils.arrayPushAll(r.keys, ["basecontrol", "calendarTitle"]);
			juci.utils.arrayPushAll(r.map, ["ref", "calendarTitle"]);
			juci.utils.arrayPushAll(r.defaults, ['""', this.DefaultCalendarTitle]);
			return r;
		},
		init: function(){
			this._mode = this.j.getAttr("data-mode", "panel"); //default mobile select, set to popup for dropdown select
			if(!this._mode)
				this._mode = "panel"; //default to normable mobile select behaviour			
			this.opened = 0;
			this._super();
			this.showClear = this.j.getAttr("data-clear", false);
			this.showClose = this.j.getAttr("data-close", false);
			this._picker = this.j.getAttr("data-picker", "ccal");
			this._format = this.j.getAttr("data-format", "dd MMM yyyy");
			this._minDate = this.j.getAttr("data-mindate");
			this._maxDate = this.j.getAttr("data-maxdate");
			this.showMonthNav = this.j.getAttr("data-month", true);
			this.showYearNav = this.j.getAttr("data-year", true);
			this._mode = this.j.getAttr("data-mode", "panel");
			this._defaultDate = this.j.getAttr("data-default", new Date().toString());
			this.value(this._val);
			this.calendarPop = new juci.elem('<div tabindex=0 class="juci_calendar_popup"></div>');
			this.calendarPop.insertAfter(this.j);
			this.calendarPop.hide();
		},
		Events: juci.controls.basecontrol.prototype.Events.concat(["openpicker", "closepicker"]),
		calendarEvents: ["dateselect", "customdateselect", "calendaropen", "calendarnavigate"],
		doOpenPicker: function(){
			var evt = new EventObject();
			this.fireEvent("beforeoptionsopen", evt);
			if(!evt.isCancelled()){
				var options = {format: this._format, defaultDate: this._defaultDate};
				/*if(this._picker === "cal"){
					if(this._mode == "panel"){
						var calPanel = juci.controls.calendar.getCalendarPanel();
						calPanel.openCalendar(this.__params.calendarTitle, this._val, this._onDateSelectInCalendar, this, options, this.onClosePicker, this.showClear);	
					} else {
						this._pcontrol.value(this._val);
						this.opened = 1;
						this.calendarPop.show();
						juci.setGhostBusters(true);
					}
				} else */
				if(this._picker === "ccal"){
					var calEvents = [];
					for(var i=0; i<this.calendarEvents.length; i++){
						var handler = this.j.el.getAttribute("on"+this.calendarEvents[i]);
						if(handler && handler != "null"){
							var obj = {
								"name": this.calendarEvents[i],
								"handler": this.j.el.getAttribute("on"+this.calendarEvents[i])
							};
							calEvents.push(obj);	
						}
					}
					if(!this._pcontrol && this._mode == "popup"){
						var calendarElement = new juci.elem(juci.controls.ccalendar.getCalendarStructure(this.showClear, this.showClose, this.showMonthNav, this.showYearNav, this._minDate, this._maxDate, calEvents));
						this.initCCalendar(calendarElement);
					}
					if(this._mode == "panel"){
						var ccalPanel = juci.controls.ccalendar.getCalendarPanel(this.showClear, this.showClose, this.showMonthNav, this.showYearNav, this._minDate, this._maxDate, calEvents);
						ccalPanel.openCalendar(this.__params.calendarTitle, this._val, this._onDateSelectInCalendar, this, options, this.onClosePicker, this.showClear);
						juci.setGhostBusters(true);
					} else {
						this._pcontrol.value(this._val);
						this._pcontrol.listenOnce("dateselect", this._onDateSelectInCalendar, this);
						this.opened = 1;
						this.fireEvent("init");
						this._pcontrol.fireEvent("calendaropen");
						this.calendarPop.show();
						juci.setGhostBusters(true);
					}
				} 
				/*else {
					if(this._mode == "panel"){
						var dobpickPanel = juci.controls.dobpick.getDobpickPanel();
						dobpickPanel.openDobpick(this.__params.calendarTitle, this._val, this._onDateSelectInCalendar, this, options, this.onClosePicker, this.showClear);
					} else {
						this._pcontrol.value(this._val);
						this.opened = 1;
						this.calendarPop.show();
						juci.setGhostBusters(true);
					}
				} */
			}
		},
		openPicker: function(evt){
			if (this.opened == 0){
				var e = new EventObject(evt);
				this.hideOptions(evt);
				this.fireEvent("openpicker", e);
				if(!e.isCancelled()){
					this._pickerOpened = true;
					this.doOpenPicker();
				}
				if(evt)
					evt.preventDefault();
			} else if(this.opened == 1){
				if(this.calendarPop){
					this.calendarPop.hide();
					this.opened = 0;	
					juci.removeGhostBusters();
				}
			}
		},
		setClickOutsideCloseEvent: function(){
			if (document.activeElement) {
				document.activeElement.blur()
			}
			evts = ["tap","touchend", "mousedown","click"];
			cb = this.hideOptions;
			evts.forEach(function(evtName){
				document.addEventListener(evtName, cb, true);
			});
		},		
		hideOptions: function(evt){
			var datepickers = juci.findByAttrVal("data-juci", "cdatepicker");
			for(var i=0; i<datepickers.length; i++){
				if(datepickers[i].getAttr("data-mode") == "popup"){
					if(datepickers[i].el != evt.target){
						if(juci.getControl(datepickers[i].el) && $(juci.getControl(datepickers[i].el).calendarPop.el).find("*").toArray().indexOf(evt.target) == -1){
							if(datepickers[i].children() && datepickers[i].children().indexOf(new juci.elem(evt.target.parentElement)) == -1 && juci.getControl(datepickers[i].el).opened == 1){
								juci.getControl(datepickers[i].el).calendarPop.hide();
								juci.removeGhostBusters();
								if(evt.target.parentElement !== datepickers[i].el){
									juci.getControl(datepickers[i].el).opened = 0;
								}
							}
						}
					}
				}
			}
		},
		initCCalendar: function(element){
			var pCalBg = new juci.elem("<div class='juci_calendar_popup' id='juci_ccalendar_popup' data-panel-id='"+this._id+"_pcalendar'></div>");
			var pCalContainer = new juci.elem("<div></div>");
			pCalContainer.append(element);
			this.calendarPop.append(pCalBg);
			pCalContainer.appendTo(pCalBg);
			juci.controls.init(pCalBg.el);
			pCalBg.calendar = pCalBg.el.children[0].children[0];
			this._pcontrol = juci.getControl(pCalBg.calendar);
			this._pcontrol.onAfterChange(this._onDateSelectInCalendar, this);
			this.setClickOutsideCloseEvent(this);
		},
		_onDateSelectInCalendar: function(e){
			this.onClosePicker();
			this.__fireBeforeChange(this._val, e.date);
			this.calendarPop.hide();
			this.opened = 0;
			setTimeout(function(){
				juci.removeGhostBusters();
			}, 300);
			e.preventDefault();
		},
		format: function(f){
			this._format = f ? f : this._format;
			return this._format;
		},
		setText: function(val){
			// TODO Whenever placeholder is set, add a special class
			var inners = (val) ? this._formatter(val) : this.placeholder;
			if(!inners){
				inners = this.placeholder;
				this.j.addClass("juci_placeholder");
			}else{
				this.j.removeClass("juci_placeholder");
			}
			this.i.html(inners);
		},
		value: function(val){
			if(typeof val == "undefined"){
				return this._val ? this._returner(this._val) : '';
			}else{
				this._val = val ? ((val instanceof Date) ? val : new Date(val)) : val;
				this.setText(this._val);
			}
		}
	};
	juci.extend(cdatepicker, juci.controls.basepicker);
	juci.controls.cdatepicker = cdatepicker;
})();