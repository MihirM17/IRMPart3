var Constants = {
	"DBName":"IRM"
};

var hamburgeroptions = {
		  "openHamburger": "true",
		  "hamburgerPages": [
		    {
		      "name": "Left Page",
		      "url": "/system/menu.html",
		      "type": "left",
		      "width": 75
		    }
		  ],
		  "showProgress": false,
};

/*HAMBURGER*/
function openMenu(side){
	$m.openMenu(side);
}

function getDbhelper(callback) {
    new window.DB(Constants.DBName, function(db) {
        window.dbHelper = db;
        dbHelper = db;
        callback(window.dbHelper);
    }, function(error) {
        $m.logError("Unable to open database due to -- " + JSON.stringify(error));
    });
}