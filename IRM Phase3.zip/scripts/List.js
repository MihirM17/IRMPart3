$m.onReady(function(){
	$m.showProgress("Searching...");
	$m.pageTitle("Interaction List");
	$m.pageTitleLeftButton('<img id="menu" class="menuimage" src="images/Backward.png"></img>');
	/*$m.pageTitleRightButton('<img id="menu" class="menuimage" src="images/more.png""></img>');*/
	$m.juci.findById("__leftBtn").onClick(function(){openMenu(1);});
});

$m.juci.addDataset("uniqueMeetingNumber", "");
$m.juci.addDataset("interactionList", []);

$m.onData(function (eventObject) {
	var data = eventObject.data;
	var flag = 0;
	console.log(data   );
	$m.juci.dataset("interactionList", data);
	var meetingNumber = [];
	for(var i = 0 ; i < data.length ; i++){
		for(var j = i+1 ; j < data.length ; j++){
			if(data[i].MEETINGNO == data[j].MEETINGNO){
				flag = 1;
				break;
			}
		}
		if(flag != 1){
			meetingNumber.push(data[i].MEETINGNO);
		}
		flag = 0;
	}
	$m.juci.dataset("uniqueMeetingNumber", meetingNumber.length);
	$m.hideProgress();
});

