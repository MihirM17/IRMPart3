$m.juci.addDataset("newsDetails", newsDetails);
$m.juci.addDataset("searchPop","");
$m.juci.addDataset("interactionList", []);
$m.juci.addDataset("pageVisible", "0");

var selectedFundManager = {
	"FUNDMANAGER" : "",
	"STATUS" : "",
	"PERCENTAGE" : ""
};
$m.juci.addDataset("FUNDMANAGER", "black");
$m.juci.addDataset("PERCENTAGE", "100");
$m.juci.addDataset("STATUS", "FII");
$m.juci.addDataset("CITY", "New York");

var x2js = new X2JS();
var fundName;
var dbHelper;

$m.onResume(function(){
	$m.juci.dataset("interactionList", []);
});

$m.onData(function(eventObject){
//	eventObject.hideProgress = false;
	$m.juci.getControl("interaction-toggle").toggle(0);
	$m.showProgress("Fetching Interaction data...");
	fundName = eventObject.data;
	$m.juci.dataset("FUNDMANAGER", fundName);
	var dbhelpercallback = function(db) {
		window.dbHelpher = db;
		holding_details.searchFundManager(fundName.toUpperCase(),function(res){
			for(var i = 0 ; i < res.rows.length ; i++){
				res.rows[i].PERCENTAGE = res.rows[i].PERCENTAGE.toFixed(5);
			}
			$m.juci.dataset("PERCENTAGE", res.rows[0].PERCENTAGE);
			$m.juci.dataset("STATUS", res.rows[0].STATUS);
			$m.juci.dataset("CITY", res.rows[0].CITY);
			$m.showProgress("Fetching Interactions..");
			getInteractiondetails();
		},function(f){
			$m.alert("failed to fetch data");
		});
		
    };
    getDbhelper(dbhelpercallback);
});

function getDbhelper(callback) {
    new window.DB(Constants.DBName, function(db) {
        window.dbHelper = db;
        dbHelper = db;
        callback(window.dbHelper);
    }, function(error) {
        $m.logError("Unable to open database due to -- " + JSON.stringify(error));
    });
}

function closeFunc(){
	$m.close();
}

function getInteractionData(){
	$m.showProgress("Fetching Interactions...");
	var fundlist = fundName;
	var fundArray = [];
	var fundObject = {};
	fundObject[fundlist] = "";
	for(var key in fundObject){
		fundArray.push("'"+key+"'");	
     }
	interaction_details.Select(function(res){
		for(var i = 0 ; i < res.rows.length ; i++){
			var timeStamp = new Date(res.rows[i].DATE_OF_INT).getTime();
			var date = new Date(timeStamp).getDate();
			date = (date < 10 ? "0" : "") + date;
			var month = new Date(timeStamp).getMonth()+1;
			month = (month < 10 ? "0" : "") + month;
			var year = new Date(timeStamp).getFullYear();
			res.rows[i].DATE_OF_INT = date + "-" + month + "-" + year;
		}
		},function(res){
			$m.alert("No data found");
	});
}

function getInteractiondetails(){
	$m.showProgress("Fetching Interaction...");
	var data = fundName;
	interaction_details.selectInteraction(data,function(response){
		var interactionResp = response.rows;
		if(interactionResp.length > 20){
			interactionResp.slice(0,20);
		}
		if(interactionResp.length == 0){
			$m.alert("No Interactions Found.");
		}
		$m.juci.dataset("interactionList", interactionResp);
		$m.hideProgress();
	},function(fail){
		$m.alert("No data found");
	});
}

$m.juci.addDataset("pageVisible", "0");

function toggleVisible(event){
	var buttonClickedId = event.newToggled;
	var toolgePage = "" ;
	switch(buttonClickedId){
		case 0:
			toolgePage = "0";
			break;
		case 1:
			setGraphData(fundName);
			toolgePage = "1";
			break;
		case 2:
			getNews(fundName);
			toolgePage = "2";
			break;
	}
	$m.juci.dataset("pageVisible", buttonClickedId);
}

function setGraphData(data){
	$m.showProgress("Fecthing Holding trends...");
	var startDate = new Date(new Date().getTime() - 300*24*60*60*1000).toString("yyyy-MM-dd");
	var query = "select * from holding_details where FUNDMANAGER='"+fundName+"' and RECORDDATE >='"+startDate+"' ORDER BY RECORDDATE ASC";
	holding_details.getHoldingByManager(query,function(res){
		var resp = res.rows;
		var graphdata = [];
		var graphLabel = [];
		for(var i=0;i<resp.length;i++){
			var weekData = [];
			var value = parseFloat(resp[i].HOLDINGPERCENTAGE);
			var dateTime = new Date(resp[i].RECORDDATE).getTime();
			weekData.push(dateTime);
			weekData.push(value);
			graphdata.push(weekData);
		}
		$m.hideProgress();
		setChart(graphdata,data.FUNDMANAGER);
	},function(f){
		$m.hideProgress();
		$m.alert("fail to fetch data");
	});
}

function getNews(fundmanager){
	var isConnected = $m.networkConnected();
	if(isConnected){
		$m.showProgress("Fetching Google News...")
		var url = "https://news.google.com/news/rss/search/section/q/"+fundmanager+"/"+fundmanager+"";
		//var url = "https://news.google.com/news/rss/headlines/section/topic/BUSINESS.en_in/Business?ned=in&hl=en-IN&gl=IN";
		//var url = "https://news.google.com/news/rss/?ned=us&gl=US&hl=en";
		$m.get(encodeURI(url), function(response){
			if(response.code === 200){
				// Success
				var result = response.result;
				try{
					var resp = x2js.xml_str2json(result.data);
					var totalresponse = resp.rss.channel.item;
					var details = resp.rss.channel.image;
					var newsdetails = {
						"image":details.url,
						"title":details.title,
						"link":details.link
					};
					$m.juci.dataset("newsDetails", newsdetails);
					$m.juci.dataset("newsList", totalresponse);
					$m.hideProgress();	
				}
				catch(e){
					$m.hideProgress();
					$m.alert("Error in request. Please try again");
				}
				
			} else{
				// Error
				$m.hideProgress();
				var errMsg = response.error.message;
				$m.alert(errMsg);
			}
		});
	}
	else{
		$m.hideProgress();
		$m.toast("No network connection to fetch Google news");
		$m.juci.dataset("newsList", []);
		$m.juci.dataset("newsDetails", newsDetails);
	}
}