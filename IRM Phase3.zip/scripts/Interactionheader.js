$m.onReady(function(){
	$m.pageTitle("Add a Interaction Page");
	$( ".juci_panel_title" ).addClass( "interaction_header" );
	$m.pageTitleLeftButton('<img id="menu" class="menuimage" src="images/menu-icon.png"></img>');
	/*$m.pageTitleRightButton('<img id="menu" class="menuimage" src="images/more.png"></img>');*/
	$m.juci.findById("__leftBtn").onClick(function(){openMenu(1);});
});

$m.juci.addDataset("interaction_type", []);
$m.juci.addDataset("met_by", []);
$m.juci.addDataset("also_attened",[]);
$m.juci.addDataset("fundNameList", []);
$m.juci.addDataset("accompainedByList", []);
$m.juci.addDataset("investors", []);
$m.juci.addDataset("brokerageHouseList", []);
$m.juci.addDataset("city", []);
$m.juci.addDataset("country", []);
$m.juci.addDataset("locationOfMeeting", []);
$m.juci.addDataset("conferenceType", ["Domestic", "International", "Other"]);

var addInteraction = {
	"meetingNumber" : "",
	"dateOfMeeting" : new Date(),
	"nameOfFundManager"	: "",
	"accompainedBy"	: "",
	"nameOfInvestor" : "",
	"selectedInteractionType" : "",
	"brokerageHouse" : "",
	"metBy" : [],
	"alsoAttended" : "",
	"selectedCity" : "",
	"selectedLocation" : "",
	"managerNames": [],
	"selectedConferenceType" : "",
	"selectedCountryOfInvestor": ""
};
$m.juci.addDataset("addInteraction", addInteraction);

$m.onResume(function(){
	var addInteraction = {
		"meetingNumber" : "",
		"dateOfMeeting" : new Date(),
		"nameOfFundManager"	: "",
		"accompainedBy"	: "",
		"nameOfInvestor" : "",
		"selectedInteractionType" : "",
		"brokerageHouse" : "",
		"metBy" : "",
		"alsoAttended" : [],
		"selectedCity" : "",
		"selectedLocation" : "",
		"managerNames": [],
		"selectedConferenceType" : "",
		"selectedCountryOfInvestor": ""
	};
	$m.juci.dataset("addInteraction", addInteraction);
});

var callbackforInsertInteraction = function(resp){
	var response = x2js.xml_str2json(resp.data);	
	var responseStatus = response["Envelope"]["Body"]["P_INSRT_IRM_INTERACTIONResponse"]["P_INSRT_IRM_INTERACTIONResult"];
	//insertInteraction = JSON.parse(insertInteraction);
	console.log(responseStatus);
	if(responseStatus === "SUCCESS"){
		$m.hideProgress();
		$m.juci.dataset("addInteraction", addInteraction);
		$m.alert("Interaction saved successfully");
	}
};

var callbackforIntType = function(resp){
	var response = x2js.xml_str2json(resp.data);
	var interaction_type = response["Envelope"]["Body"]["P_GET_IRM_INT_TYPEResponse"]["P_GET_IRM_INT_TYPEResult"];
	
	interaction_type = JSON.parse(interaction_type);
	$m.juci.dataset("interaction_type", interaction_type.Table);
};
var callbackforMetBy = function(resp){
	var response = x2js.xml_str2json(resp.data);
	var metBy = response["Envelope"]["Body"]["P_GET_IRM_METBYResponse"]["P_GET_IRM_METBYResult"];
	
	metBy = JSON.parse(metBy);
	var metByArray = [];
	var alsoAttendedArray = [];
	for(var i = 0 ;i < metBy.Table.length; i++){
		if(metBy.Table[i].TYPE == "A"){
			alsoAttendedArray.push(metBy.Table[i].MET_BY);
		}
		else{
			metByArray.push(metBy.Table[i].MET_BY);
		}
	}
	$m.juci.dataset("met_by", metByArray);
	$m.juci.dataset("also_attened", alsoAttendedArray);
};

var x2js = new X2JS();
$m.onData(function() {
	getFundName();
	IRMServices.getIntType("", callbackforIntType);
	IRMServices.getMetBy("", callbackforMetBy);
});

function getSelectedInteractionType(obj){
	return obj.TYPE_OF_INT;
}
function getSelectedMetBy(obj){
	return obj.MET_BY;
}

function validateAddInteraction(){
	var interactionDetails = $m.juci.dataset("addInteraction");
	var isInvalid = validate(interactionDetails);
	var regExmeetingNumber = /^[0-9]{1,50}$/;
//	var regExnameOfFundManager = /^[A-Z\w&.]+$/;
//	var regExaccompainedBy = /^[A-Z][A-Z|a-z0-9\s]{2,50}$/;
//	var regExnameOfInvestor = /^[A-Z][A-Z|a-z0-9\s]{2,50}$/;
//	var regExbrokerageHouse = /^[A-Z][A-Z|a-z0-9\s]{2,50}$/;
//	var regExselectedCountry = /^[A-Z][A-z|a-z\s]{2,20}$/;
//	var regExselectedLocation = /^[A-Z][A-z|a-z\s]{2,20}$/;
	if (isInvalid) {
		if (isInvalid.error === "Empty") {
			message = " is Mandatory";
		} 
		else {
			message = " is Invalid";
		}
		var messageMap = {
			"meetingNumber" : "Meeting Number",
			"dateOfMeeting" : "Date Of Meeting",
			"nameOfFundManager"	: "Fund Manager",
			"accompainedBy"	: "Accompained By",
			"nameOfInvestor" : "Investor",
			"selectedInteractionType" : "Interaction Type",
			"brokerageHouse" : "Brokerage House",
			"metBy" : "Met By",
			"alsoAttended" : "Also Attended",
			"selectedCity" : "City of Meeting",
			"selectedLocation" : "Location"
		};
		$m.alert(messageMap[isInvalid.key] + message, "", function() {});
		return;
	}
	else{
		if(!regExmeetingNumber.test(interactionDetails.meetingNumber)){
			$m.alert("Meeting Number is Invalid. No letters are allowed ");
			return;
		}
//		if(!regExnameOfFundManager.test(interactionDetails.nameOfFundManager)){
//			$m.alert("Fund Manager is Invalid. Your 1st value should a letter and should be capital ");
//			return;
//		}
//		if(!regExaccompainedBy.test(interactionDetails.accompainedBy)){
//			$m.alert("Accompained By is Invalid. Your 1st value should a letter and should be capital ");
//			return;
//		}
//		if(!regExnameOfInvestor.test(interactionDetails.nameOfInvestor)){
//			$m.alert("Investor is Invalid. Your 1st value should a letter and should be capital ");
//			return;
//		}
//		if(!regExbrokerageHouse.test(interactionDetails.brokerageHouse)){
//			$m.alert("Brokerage House is Invalid. Your 1st value should a letter and should be capital ");
//			return;
//		}
//		if(!regExselectedCountry.test(interactionDetails.selectedCity)){
//			$m.alert("City of Meeting is Invalid. Your 1st value should a letter and should be capital ");
//			return;
//		}
//		if(!regExselectedLocation.test(interactionDetails.selectedLocation)){
//			$m.alert("Location is Invalid. Your 1st value should a letter and should be capital ");
//			return;
//		}
	}
	$m.showProgress("Saving Interaction...");
	var data = $m.juci.dataset("addInteraction");
	if(data.selectedConferenceType == "Domestic"){
		data.selectConferenceType = "Y";
	}
	else if(data.selectedConferenceType == "International"){
		data.selectConferenceType = "N";
	}else if(data.selectedConferenceType == "Other"){
		data.selectConferenceType = "O";
	}
	IRMServices.insertInteraction(data, callbackforInsertInteraction);
	console.log("validation done");
}

function validate(InteractionDetails) {
   var errorObj = {
       "key": key,
       "error": "Filled"
   };
   for (var key in InteractionDetails) {
       if (!InteractionDetails[key]) {
           errorObj.key = key;
           errorObj.error = "Empty";
           return errorObj;
       }
   }
   return false;
}

//This Function is to get the list of distinct fund name from database
function getFundName(){
	var dbhelpercallback = function(db) {
	window.dbHelpher = db;
	interaction_details.getFundManagers(function(res){
			$m.juci.dataset("fundNameList", res.rows);
			document.getElementById("interactionList").style.display = "none";
			getAccompainedBy();
			getInvestor();
			getBrokerageHouse();
			getCity();
			getLocationOfMeeting();
			getCountry();
		}, function(fresp){
			$m.alert("No result found");
		});
	};
	getDbhelper(dbhelpercallback);
}

//This funtion is to search inserting values to fund name in list
function searchFundName() {
	// Declare variables
	var input, filter, i;
	input = document.getElementById('fund-name').children[3].value;
	filter = input.toUpperCase();
	if(!filter){
		document.getElementById("interactionList").style.display = "none";
		return;
	}
	var interactionList = $m.juci.dataset("fundNameList");
	// Loop through all list items, and hide those who don't match the search query
	document.getElementById("interactionList").style.display = "block";
	for (i = 0; i < interactionList.length; i++) {
		if (interactionList[i].NAME_OF_PERSON.toUpperCase().indexOf(filter) > -1) {
			document.getElementById("fund-name-id_"+i).style.display = "";
		}else {
			document.getElementById("fund-name-id_"+i).style.display = "none";
		}
	}
}

function setFundName(event){
	var data = JSON.parse(ko.toJSON(event));
	var list = $m.juci.getDataset("addInteraction")();
	list.nameOfFundManager(data.NAME_OF_PERSON);
	interaction_details.getLastRecord(data.NAME_OF_PERSON,function(res){
		console.log(res.rows);
		var response = {
			"nameOfFundManager"	: res.rows[0].NAME_OF_PERSON,
			"nameOfInvestor" : res.rows[0].FUND_NAME,
			"selectedCountryOfInvestor": res.rows[0].COUNTRY_OF_MEETING
		};
		$m.juci.dataset("addInteraction", response);
	},function(fres){
		$m.alert("No result found");
	});
	document.getElementById("interactionList").style.display = "none";
}

function getAccompainedBy(){
	interaction_details.getAccompainedBy(function(res){
		$m.juci.dataset("accompainedByList", res.rows);
		document.getElementById("accompained-by-list").style.display = "none";
	}, function(fresp){
		$m.alert("No result found");
	});
}

function getInvestor(){
	interaction_details.getInvestors(function(res){
		$m.juci.dataset("investors", res.rows);
		document.getElementById("investor-list").style.display = "none";
	}, function(fresp){
		$m.alert("No result found");
	});
}

function getBrokerageHouse(){
	interaction_details.getBrokerageHouse(function(res){
		$m.juci.dataset("brokerageHouseList", res.rows);
		document.getElementById("brokerage-house-list").style.display = "none";
	}, function(fresp){
		$m.alert("No result found");
	});
}

function getCity(){
	interaction_details.getCity(function(res){
		$m.juci.dataset("city", res.rows);
		document.getElementById("city-list").style.display = "none";
	}, function(fresp){
		$m.alert("No result found");
	});
}

function getLocationOfMeeting(){
	interaction_details.getLocationOfMeeting(function(res){
		$m.juci.dataset("locationOfMeeting", res.rows);
		document.getElementById("location-of-meeting-list").style.display = "none";
	}, function(fresp){
		$m.alert("No result found");
	});
}

function searchAccompainedBy() {
	// Declare variables
	var input, filter, i;
	input = document.getElementById('accompained-by').children[3].value;
	filter = input.toUpperCase();
	if(!filter){
		document.getElementById("accompained-by-list").style.display = "none";
		return;
	}
	var accompainedByList = $m.juci.dataset("accompainedByList");
	// Loop through all list items, and hide those who don't match the search query
	document.getElementById("accompained-by-list").style.display = "block";
	for (i = 0; i < accompainedByList.length; i++) {
		if (accompainedByList[i].ACCOMPANIED_BY.toUpperCase().indexOf(filter) > -1) {
			document.getElementById("accompained-by-id_"+i).style.display = "";
		}else {
			document.getElementById("accompained-by-id_"+i).style.display = "none";
		}
	}
}

function setAccompainedBy(event){
	var data = JSON.parse(ko.toJSON(event));
	var list = $m.juci.getDataset("addInteraction")();
	list.accompainedBy(data.ACCOMPANIED_BY);
	document.getElementById("accompained-by-list").style.display = "none";
}

function searchInvestor() {
	// Declare variables
	var input, filter, i;
	input = document.getElementById('investor').children[3].value;
	filter = input.toUpperCase();
	if(!filter){
		document.getElementById("investor-list").style.display = "none";
		return;
	}
	var List = $m.juci.dataset("investors");
	// Loop through all list items, and hide those who don't match the search query
	document.getElementById("investor-list").style.display = "block";
	for (i = 0; i < List.length; i++) {
		if (List[i].FUND_NAME.toUpperCase().indexOf(filter) > -1) {
			document.getElementById("investor-id_"+i).style.display = "";
		}else {
			document.getElementById("investor-id_"+i).style.display = "none";
		}
	}
}

function setInvestor(event){
	var data = JSON.parse(ko.toJSON(event));
	var list = $m.juci.getDataset("addInteraction")();
	list.nameOfInvestor(data.FUND_NAME);
	document.getElementById("investor-list").style.display = "none";
}

function searchBrokerageHouse() {
	// Declare variables
	var input, filter, i;
	input = document.getElementById('brokerage-house').children[3].value;
	filter = input.toUpperCase();
	if(!filter){
		document.getElementById("brokerage-house-list").style.display = "none";
		return;
	}
	var List = $m.juci.dataset("brokerageHouseList");
	// Loop through all list items, and hide those who don't match the search query
	document.getElementById("brokerage-house-list").style.display = "block";
	for (i = 0; i < List.length; i++) {
		if (List[i].BROKERAGE_HOUSE.toUpperCase().indexOf(filter) > -1) {
			document.getElementById("brokerage-house-id_"+i).style.display = "";
		}else {
			document.getElementById("brokerage-house-id_"+i).style.display = "none";
		}
	}
}

function setBrokerageHouse(event){
	var data = JSON.parse(ko.toJSON(event));
	var list = $m.juci.getDataset("addInteraction")();
	list.brokerageHouse(data.BROKERAGE_HOUSE);
	document.getElementById("brokerage-house-list").style.display = "none";
}

function searchCity() {
	// Declare variables
	var input, filter, i;
	input = document.getElementById('city').children[3].value;
	filter = input.toUpperCase();
	if(!filter){
		document.getElementById("city-list").style.display = "none";
		return;
	}
	var List = $m.juci.dataset("city");
	// Loop through all list items, and hide those who don't match the search query
	document.getElementById("city-list").style.display = "block";
	for (i = 0; i < List.length; i++) {
		if (List[i].CITY_OF_MEETING.toUpperCase().indexOf(filter) > -1) {
			document.getElementById("city-id_"+i).style.display = "";
		}else {
			document.getElementById("city-id_"+i).style.display = "none";
		}
	}
}

function setCity(event){
	var data = JSON.parse(ko.toJSON(event));
	var list = $m.juci.getDataset("addInteraction")();
	list.selectedCity(data.CITY_OF_MEETING);
	document.getElementById("city-list").style.display = "none";
}

function searchLocationOfMeeting() {
	// Declare variables
	var input, filter, i;
	input = document.getElementById('location-of-meeting').children[3].value;
	filter = input.toUpperCase();
	if(!filter){
		document.getElementById("location-of-meeting-list").style.display = "none";
		return;
	}
	var List = $m.juci.dataset("locationOfMeeting");
	// Loop through all list items, and hide those who don't match the search query
	document.getElementById("location-of-meeting-list").style.display = "block";
	for (i = 0; i < List.length; i++) {
		if (List[i].LOCATION_OF_MEETING.toUpperCase().indexOf(filter) > -1) {
			document.getElementById("location-of-meeting-id_"+i).style.display = "";
		}else {
			document.getElementById("location-of-meeting-id_"+i).style.display = "none";
		}
	}
}

function setLocationOfMeeting(event){
	var data = JSON.parse(ko.toJSON(event));
	var list = $m.juci.getDataset("addInteraction")();
	list.selectedLocation(data.LOCATION_OF_MEETING);
	document.getElementById("location-of-meeting-list").style.display = "none";
}

function getMeetingNumber(){
	var callbackforGetMeetingNumber = function(resp){
		var response = x2js.xml_str2json(resp.data);
		var meetingNumber = response["Envelope"]["Body"]["P_GET_IRM_MEETING_NOResponse"]["P_GET_IRM_MEETING_NOResult"];
		meetingNumber = JSON.parse(meetingNumber);
		var meetNumber = {
			"meetingNumber" : meetingNumber.Table[0].CURRENT_NO
		};
		$m.juci.addDataset("addInteraction", meetNumber);
		$m.hideProgress();
	};
	$m.showProgress("Fetching Meeting Number");
	IRMServices.getMeetingNo("", callbackforGetMeetingNumber);
}

function redirectToTop15(){
	$m.open("Top15", "/IRM2/Dashboard.html");
}

function getCountry(){
	interaction_details.getCountry(function(res){
		$m.juci.dataset("country", res.rows);
		document.getElementById("country-of-investor-list").style.display = "none";
	}, function(fresp){
		$m.alert("No result found");
	});
}

function searchCountry() {
	// Declare variables
	var input, filter, i;
	input = document.getElementById('country-of-investor').children[3].value;
	filter = input.toUpperCase();
	if(!filter){
		document.getElementById("country-of-investor-list").style.display = "none";
		return;
	}
	var countryList = $m.juci.dataset("country");
	// Loop through all list items, and hide those who don't match the search query
	document.getElementById("country-of-investor-list").style.display = "block";
	for (i = 0; i < countryList.length; i++) {
		if (countryList[i].COUNTRY_OF_MEETING.toUpperCase().indexOf(filter) > -1) {
			document.getElementById("country-of-investor-id_"+i).style.display = "";
		}else {
			document.getElementById("country-of-investor-id_"+i).style.display = "none";
		}
	}
}

function setCountry(event){
	var data = JSON.parse(ko.toJSON(event));
	var list = $m.juci.getDataset("addInteraction")();
	list.accompainedBy(data.COUNTRY_OF_MEETING);
	document.getElementById("country-of-investor-list").style.display = "none";
}

function enableConferenceType(){
	var interactionType = $m.juci.dataset("addInteraction");
	if(interactionType.selectedInteractionType.TYPE_OF_INT != "Conference"){
		interactionType.selectedConferenceType = "Other";
		$(".conference_type").attr("disabled", "disabled");
		$m.juci.dataset("addInteraction", interactionType);
	}
	else{
		interactionType.selectedConferenceType = "";
		$(".conference_type").removeAttr("disabled");
		$m.juci.dataset("addInteraction", interactionType);
	}
	
}