(function(){
	var displaygrid = function(elem){
		elem.removeAttr("data-titles");
		elem.removeAttr("data-subtitle");
		elem.removeAttr("data-subtitles");
		this._super = juci.controls.xlist;
		this._super(elem);
	}
	displaygrid.prototype = {
		type: "displaygrid",
		Events: juci.controls.basecontrol.prototype.Events.concat("rowselect"),
		selectedItems: [],
		selectedItemsWithIndex : [],
		init: function(){
			var that = this;
			this.addListener("rowselect", function(that){
				if(that.listItem.hasClass("item_selected") == false){
					that.listItem.addClass("item_selected");
					juci._currTouch.className += " item_selected";
					that.control.selectedItems.push(that.control.getItem(that.index, false));
					that.control.selectedItemsWithIndex.push({"index": that.index, "data":that.control.getItem(that.index, false)});
					if(typeof that.index  == "number")
						that.control._idx = that.index;
				}
				else{
					that.listItem.removeClass("item_selected");
					juci._currTouch.className = juci._currTouch.className.replace(" item_selected", "");
					that.control._idx = -1;
					that.control.selectedItems.splice(that.index, 1);
					that.control.selectedItemsWithIndex.splice(that.index,1);
				}
			});
            this._super();
        },
		getListItemTemplate: function(){
            var listitem = this._super();
			var headers = this.j.attr("table-headers");
			var columnWidth = this.j.attr("data-column-width");
			var css = ".juci_displaygrid .juci_title.juci_fixed_table{\n"+
				"	display: table-cell;\nwidth: "+columnWidth+"% !important;\n"+
			"}";
			var style = new juci.elem("<style type='text/css'>\n"+css+"\n</style>").appendTo(juci.findByTag("head")[0]);
			var hctr = new juci.elem(this._getHeaderContainer(headers)).prependTo(this.j);
			return listitem;
		},
		_getHeaderContainer: function(headers){
			var headersArray = headers.split(",");
			var headerContainer = "<div class='juci_xlist_pane juci_displaygrid_listPane'><div data-juci='list_item' class='juci_xlist_item juci_displaygrid_item juci_parent'>";
			for(var i=0; i<headersArray.length; i++)
				headerContainer += "<div class='juci_title juci_fixed_table'><div class='juci_display_container'>"+headersArray[i].replace(' ', '')+"</div><div class='juci_display_padder_right'></div></div>";
			headerContainer += "</div></div>";
			return headerContainer;
		},
		getSelectedItems: function(){
			return this.selectedItems;
		},
		getSelectedItemsWithIndex: function(){
			return this.selectedItemsWithIndex;
		},
		postInitializeList: function(){
			this._super();
			this.addListItemClick(this.fireActionClick, this, ".juci_displaygrid_item");
		},
		fireActionClick: function(e){
			var evt = new EventObject(e, e);
			this.fireEvent("rowselect", evt);
		},
        onRowSelect: function(fp, ctx){
			this.addListener("listitemclick", fp, ctx);
		}
	};
	displaygrid.prototype.type = "displaygrid";
	juci.extend(displaygrid, juci.controls.xlist);
	juci.controls.displaygrid = displaygrid;
})();