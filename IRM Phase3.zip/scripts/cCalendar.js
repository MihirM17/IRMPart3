$m.juci.addDataset("ccal","Sun Mar 08 2020 00:00:00 GMT+0530 (India Standard Time)");

function restrictDate(event){
	//debugger;
}