

$m.onClose(function(){
	var currdate = new Date().getTime();
	var lastseen = new Date(currdate).toString("dd-MMM-yyyy hh:mm:ss tt");
	$m.putPref("userlastseen",lastseen);
	$m.savePref();
});