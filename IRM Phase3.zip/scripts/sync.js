
var packageName = "com.cloudpact.irmuat";

if(isAppForeground){
	$m.juci.addDataset("lastSync", "", true);
	$m.juci.addDataset("tablesInfo", []);
	$m.juci.addDataset("backgroundSyncEnable", false);
}

$m.onResume(function(){
	setheight();
});

function setheight(){
	var setHeight = document.documentElement.clientHeight-122;
	document.getElementById("page-body").style.height = setHeight + 'px';
}

var totalTableCount = 8,
	requestCounter = 0,
	tablecount = 0;
	altercount = 0;
	tableLength = 7;
var syncInProgress = false;
var Tables = {
	"holding_details" :"Address Details",
	"interaction_details": "Interaction Details",
};

var dbTablesMap = {
	"Address_Details": "ad",
	"LoanApplications": "la",
	"Customer_Details": "cd",
	"Document_Details":"dd",
	"Signature":"sg",
//	"CibilScoreDetails":"crd",
	"cibilString":"cs",
	"CibilReport_Details":"cr",
	"LosSystem":"ls"
};
var getKeyColums = function(columnsObjs) {
	var columns = [];
	for (var i = 0; i < columnsObjs.length; i++) {
		columns.push(columnsObjs[i].name);
	}
	return columns;
};
var tableNamesArr = [
	Tables.LoanApplications,
	Tables.Address_Details,
	Tables.Customer_Details,
	Tables.Document_Details,
	Tables.Signature,
//	Tables.CibilScoreDetails,
	Tables.CibilReport_Details,
	Tables.cibilString,
	Tables.LosSystem
];
var defaultdataset = [{
	"name": Tables.LoanApplications,
	"status": "ready",
	"className": "LoanApplications"
},{	"name": Tables.Address_Details,
	"status": "ready",
	"className": "Address_Details"
}, {
	"name": Tables.Customer_Details,
	"status": "ready",
	"className": "Customer_Details"
},{
	"name": Tables.Document_Details,
	"status": "ready",
	"className": "Document_Details"
},{
	"name": Tables.Signature,
	"status": "ready",
	"className": "Signature"
},
/*{
	"name": Tables.CibilScoreDetails,
	"status": "ready",
	"className": "CibilScoreDetails"
},*/
{
	"name": Tables.CibilReport_Details,
	"status": "ready",
	"className": "CibilReport_Details"
},{
	"name": Tables.cibilString,
	"status": "ready",
	"className": "cibilString"
},
{
	"name": Tables.LosSystem,
	"status": "ready",
	"className": "LosSystem"
}
];

function init() {
	if(isAppForeground){
		Utils.PutPref("userid",Utils.GetUserName());
		$m.juci.getControl("sync-button").enable();
		$m.juci.getDataset("lastSync")($m.getPref("lastSync") ? Utils.GetDateFormat($m.getPref("lastSync")) : "Never Done");
		var isBGEnabled = $m.getPref("enableBGSync");
		$m.juci.dataset("backgroundSyncEnable", true);
		if(!isBGEnabled){
			$m.juci.dataset("backgroundSyncEnable", false);
		}
	}	
	new window.DB(Constants.DBName, function(db) {
		window.dbHelper = db;
		updateList();
		if (!$m.getPref("TableCreation")) {
			createTables();
		}
	/*	var isTableAltered = $m.getPref("TableAlterationUpdate");	
		$m.logInfo(isTableAltered);
		if(!isTableAltered){
			alterTables();
		}*/
		
		checkLastSync();
		checkBackgroundTask();
		syncBeforeLogout();
	}, function(error) {	
		if(isAppForeground){
			$m.logError("BG : Unable to open database due to -- " + JSON.stringify(error));
			$m.alert("Unable to open database");
		}		
	});
}

function backgroundSync(){
	new window.DB(window.Constants.DBName, function(db) {
		window.dbHelper = db;
		startSync();
		
	}, function(error) {
		if(isAppForeground){
			$m.logError("Unable to open database due to -- " + JSON.stringify(error));
			$m.alert("Unable to open database");
		}		
	});
}

function checkLastSync(){
	if(isAppForeground){
		if($m.getPref("isSync")){			
			startSync();
		}
	}	
}

$m.onData(init);
function updateList() {
	if(isAppForeground){
		var temp = {};
		var list = [];
		for (var i = 0; i < tableNamesArr.length; i++) {
			temp = {};
			temp.name = tableNamesArr[i];
			temp.status = "Ready";
			temp.totalrecs = 0;
			temp.timeremaining = "Not started";
			temp.lastinstime = new Date().getTime();
			list.push(temp);
		}
		$m.juci.dataset("tablesInfo", list);
		document.querySelector(".progress_bars .master div").style.width = 0;
		document.querySelector(".progress_bars").style.display = 'none';
		document.querySelector(".progress_bars .text").innerHTML = 'Sync not started';
	}
}

function showProgressDivisions() {
	if(isAppForeground){
		document.querySelector(".progress_bars").style.display = "block";
		document.querySelector(".progress_bars .text").innerHTML = "Sync in progress...";
		document.querySelector(".progress_bars .master div").style.width = 0;
	}
}

function sync() {
	if(!$m.networkConnected()){    	
        $m.logError("Sync failed: No internet connection");
        var options = {
			"title":"Sync Failed",
			"msg":"No network connection",
			"package":packageName
		}
		$m.localNotification(options); 
        $m.putPref("enableLogout", false);
		$m.savePref();
        if(isAppForeground){
			$m.alert("No internet connection");
        }
        return false;
    }
	syncInProgress = true;
	if(isAppForeground){
		$m.juci.getControl("sync-button").disable();
	}
	showProgressDivisions();
	var syncCallback = function(){
		updateList();
		$m.putPref("lastSync", new Date().getTime());
		$m.putPref("lastSyncTimestamp", new Date().getTime());		
        $m.putPref("isSync",false);
		$m.savePref();		
		$m.logInfo("Sync Final");
		var data = {			
			"title":"MCAS Success",
			"msg":"Sync Completed!",
			"package":packageName
		}
		if(!$m.getPref("enableLogout")){			
			$m.localNotification(data);
		}
		syncInProgress = false;
		if(isAppForeground){
			$m.juci.getDataset("lastSync")(Utils.GetDateFormat($m.getPref("lastSync")));
			if($m.getPref("enableLogout")){
				var accountName = __mowbly__.Page.userName;
				$m.removePref("com.mowbly.system.user", true);
				$m.savePref();
				$m.showProgress("Logging out...");
				__mowbly__.Shell.AccountManager.deleteAccount(accountName);
			} 
		}		
	};
	syncTable(0, true, syncCallback);
	var options = {
		"title":"MCAS Syncing "+ tableNamesArr[0],
		"msg":"Sync 0% of 100% completed",
		"progress":1,
		"progressmax":100,
		"package":packageName
	}
	$m.localNotification(options);
}

function startSync() {
/*	var versionInfo = $m.getPref("versionInfo");
	appversion  = versionInfo.appversion;
	uatversion  = versionInfo.uatversion
	if(appversion != uatversion){
		totalTableCount = 7;
		tableLength = 6;
	}
	else if(appversion == uatversion){
			totalTableCount = 9;
			tableLength = 8;
	} */
	if($m.networkConnected()){
		count = totalTableCount;
		requestCounter = 0;
		updateList();
		sync();
		var options = {
			"title":"MCAS Sync Started",
			"msg":"Connecting to the server",
			"package":packageName
		}
		$m.localNotification(options); 
	}else{
		$m.putPref("enableLogout", false);
    	$m.savePref();	
    	var options = {
			"title":"Sync Failed",
			"msg":"No network connection",
			"package":packageName
		}
		$m.localNotification(options);
    	if(isAppForeground){
    		$m.alert("Please check your network connection", "Try Again", function(){});
    	}
	}
}

function create_table_success(res) {
	$m.logInfo("Table created successfully");
	tablecount = tablecount + 1;
	if (tablecount == totalTableCount) {
		$m.putPref("TableCreation", true);
		$m.savePref();
		if(isAppForeground){
			$m.toast("Tables created successfully!");
		}
	} else {
		$m.putPref("TableCreation", false);
	}
}

function create_table_failure(res) {
	$m.logError("Failed to create table --- " + JSON.stringify(res));
}

function inc_cb(tidx) {
	return function(tName, incrCounter, rowsInserted) {
		if(isAppForeground){
				var ds = $m.juci.getDataset("tablesInfo")()[tidx];
				var etime = new Date().getTime();
				var totalrecs = ds.totalrecs();
				document.querySelector(".progress_bars .text").innerHTML = 'Syncing ' + tName + " - " + incrCounter + " of " + totalrecs + " records inserted";
				ds.status(incrCounter);
				var lsttime = ds.lastinstime();
				var tt;
				if (totalrecs > 100) {
					if (incrCounter % 100 === 0) {
						tt = (etime - lsttime) * ((totalrecs - incrCounter) / 100);
						ds.timeremaining(readableTime(tt));
						ds.lastinstime(etime);
					}
				} else if (totalrecs > 10) {
					if (incrCounter % 10 === 0) {
						tt = (etime - lsttime) * ((totalrecs - incrCounter) / 10);
						ds.timeremaining(readableTime(tt));
						ds.lastinstime(etime);
					}
				} else {
					ds.timeremaining("few seconds");
				}
				
			};
		}
}

function createTables() {
	LoanApplications.createTable(create_table_success, create_table_failure);
	Address_Details.createTable(create_table_success, create_table_failure);
	Customer_Details.createTable(create_table_success, create_table_failure);
	Document_Details.createTable(create_table_success, create_table_failure);
	Signature.createTable(create_table_success, create_table_failure);
//	CibilScoreDetails.createTable(create_table_success, create_table_failure);
	CibilReport_Details.createTable(create_table_success, create_table_failure);
	cibilString.createTable(create_table_success, create_table_failure);
	LosSystem.createTable(create_table_success, create_table_failure);
}

function alterTables(){
//	activity_visit.createTable(alter_table_success, alter_table_failure);
//	Opportunities.createTable(alter_table_success, alter_table_failure);
}

/*function alter_table_success(res){
	$m.logInfo("Table alter successfully");
	altercount = altercount+1;
	if(altercount == 2){
		$m.putPref("TableAlterationUpdate",true);
		$m.savePref();
		$m.toast("Tables altered successfully!");
	}else{
		$m.putPref("TableAlterationUpdate",false);
		$m.savePref();
	}
}
function alter_table_failure(res){
	$m.logError("Failed to alter table --- " + JSON.stringify(res));
}*/

function readableTime(ms) {
	var h = Math.floor(ms / 3600000); // 1 Hour = 360000 Milliseconds
	var m = Math.floor((ms % 3600000) / 60000); // 1 Minutes = 60000 Milliseconds
	var s = Math.floor(((ms % 360000) % 60000) / 1000); // 1 Second = 1000 Milliseconds
	return (h === 0 ? '' : h + ' hour ') + (m === 0 ? '' : m + ' min(s) ') + (s + ' second(s)');
}

function syncTable(tableIndex, fullsync, callback){
	$m.logInfo("BG : Sycing table - " + tableIndex);
	if (!$m.networkConnected()) {
    	syncInProgress = false;    	
        $m.putPref("enableLogout", false);
        $m.savePref();
        var options = {
			"title":"Sync Failed",
			"msg":"No network connection",
			"package":packageName
		}
		$m.localNotification(options);
        if (isAppForeground) {
            $m.alert("No internet connection");
        }        
        return false;
    }
	var tableObj = null;
	var tables = JSON.parse(JSON.stringify(defaultdataset));
	var table = tables[tableIndex];
	if(isAppForeground){
		setTableSyncStatus(tableIndex, "Syncing...");
	}	
	var currentTableName = table.className;
	$m.logInfo(currentTableName);
	var tableObj = window[currentTableName];
	var unsycedDataCallback = function(mobileDataToSync) {	
		var requestData = {};
			requestData.lastsynctime = $m.getPref(currentTableName) ? $m.getPref(currentTableName) : "0";
			requestData.table = dbTablesMap[currentTableName];
			requestData.userid = window.Utils.GetUserName();
			requestData.syncdata = mobileDataToSync;
			requestData.action = "sync" + currentTableName;
		$m.logInfo(currentTableName);
		$m.logInfo($m.getPref(currentTableName));
		var requestName = "Sync_" + currentTableName;
		var syncServerReponse = function(serverDataToSync) {
			$m.logInfo("BG : Server Data - " + tableIndex);
			if(!serverDataToSync){
				syncInProgress = false;
				$m.putPref("enableLogout", false);
    			$m.savePref();
    			var notifydata ={    					
					"title":"MCAS Sync Failed!",
					"msg":"Could not connect to server",
					"package":packageName
				}
				$m.localNotification(notifydata);
    		/*	if(isAppForeground){    				
					$m.alert("Could not connect to server", "Try Again!", function(){
						$m.close();
					});		
				}	*/		
			}			
			var deleteDataCallback = function() {
				var updateDataCallback = function() {
					var insertDataCallback = function() {
						$m.putPref(currentTableName, new Date().getTime());
						var completed = Math.floor((((tableIndex+1) / totalTableCount) * 100));
						var message ="Sync Completed";
						var title = "MCAS Sync";
						if(tableIndex!= tableLength){
							message = "Sync "+completed+"% of 100% completed";
							title = "MCAS Syncing "+ tableNamesArr[tableIndex];
						}
						var options = {
							"title":title,
							"msg":message,
							"progress":completed,
							"package":packageName,
							"progressmax":100							
						}
						$m.localNotification(options);
						if(isAppForeground){
							setTableSyncStatus(tableIndex, "Done");
							setTableTime(tableIndex, "0");
							document.querySelector(".progress_bars .master div").style.width = (((tableIndex+1) / totalTableCount) * 100) + '%';							
						}						
						if(fullsync && tableIndex != (totalTableCount-1)){
							syncTable(tableIndex + 1, fullsync, callback);
						}else{
							callback();	
						}
					};
					var incrementCallback = function(tableName, incrementCounter, rowsInserted) {};
					var dataToInsert = serverDataToSync.insert;
					setTotalrecs(tableIndex,dataToInsert.length);
					$m.logInfo("InsertNO"+dataToInsert.length+"TableINdex"+tableIndex);	
					insertResponseData(tableObj, dataToInsert, inc_cb(tableIndex), insertDataCallback);	
				};
				var incrementCallback = function(tableName, incrementCounter, rowsInserted) {};
				var dataToUpdate = serverDataToSync.update;
				setTotalrecs(tableIndex,dataToUpdate.length);
				updateResponseData(tableObj, dataToUpdate, inc_cb(tableIndex), updateDataCallback);
			};
			var dataToDelete = serverDataToSync.deleteData;
			deleteResponseData(tableObj, dataToDelete, deleteDataCallback);
		};	
		window.Utils.FireRequest(requestName, requestData, syncServerReponse);	
	};
	getUnsyncedData(tableObj, unsycedDataCallback);
}

function getUnsyncedData(tableObj, callback) {
	var success_callback = function(response) {
		callback(response);
	};
	var error_callback = function(error) {
		callback([], error);
	};
	$m.logInfo("BG : Fetching Unsynced records - " + tableObj);
	tableObj.selectDataToSync(success_callback, error_callback);	
}

function insertResponseData(tableObj, data, incrementalCallback, callback) {
	var success_callback = function(response) {
		callback(true);
	};
	var error_callback = function(error) {
		callback(false, error);
	};
	tableObj.multipleDataInsert(data, incrementalCallback,success_callback,error_callback);
}

function updateResponseData(tableObj, data, incrementalCallback, callback) {
	var success_callback = function(response) {
		callback(true);
	};
	var error_callback = function(error) {
		callback(false, error);
	};
	if(!data.length){
		callback(true);
		return;
	}
	var filter = new window.DB.Filter.equal("issync", "'0'");
	var updateData = {"issync":"1"};
	tableObj.updateSync(updateData,filter,success_callback, error_callback);
}

function deleteResponseData(tableObj, data, callback) {
	var success_callback = function(response) {
		callback(true);
	};
	var error_callback = function(error) {
		callback(false, error);
	};
	if(!data.length){
		callback(true);
		return;
	}
	var filter = new window.DB.Filter.equal("todelete", "'1'");
	tableObj.multipleDelete(filter,success_callback, error_callback);	
}

function setTableSyncStatus(tableIndex, status){
	if(isAppForeground){		
		$m.juci.getDataset("tablesInfo")()[tableIndex].status(status);
	}
}

function setTableTime(tableIndex, time){
	if(isAppForeground){
		$m.juci.getDataset("tablesInfo")()[tableIndex].timeremaining(time);
	}	
}

function setTotalrecs(tableIndex, totalrecs){
	if(isAppForeground){
		$m.juci.getDataset("tablesInfo")()[tableIndex].totalrecs(totalrecs);
	}	
}

$m.onClose(function(){
	if(syncInProgress){
		$m.alert("Sync in progress", "Please wait", function(){
			
		});
		event.preventDefault();
	}
});

function syncBeforeLogout(){
	if($m.getPref("enableLogout")){
		startSync();
	}
}




  