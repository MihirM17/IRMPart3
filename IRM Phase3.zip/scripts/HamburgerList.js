function getDashbordpage(){
	$m.open("Dashboard","/IRM2/FinalDashbord.html");
}
function searchInteraction(){
	$m.open("Search An Interaction","/IRM2/SearchInteraction.html");
}
 function addInteraction(){
	$m.open("Add An Interaction","/IRM2/Addinteraction.html");
}
 function getList(){
	$m.open("List","/IRM2/List.html");
}
 function closeHamburger(){
	$m.close();
}

var x2js = new X2JS();
$m.juci.addDataset("lastSync", "09-Feb-2018");

$m.onData(function(){
	var date = $m.getPref("lastSyncDate");
	$m.juci.dataset("lastSync", date);
});

function sync(){
	var lastDate = $m.getPref("lastDate");
	
	var lastSync = new Date().toString("dd-MM-yyyy ");
	lastSync +=  new Date().toLocaleString("en-US",{hour:"numeric", minute: 'numeric', hour12: true});
	
	$m.putPref("lastSyncDate", lastSync);
	$m.savePref();
	$m.juci.dataset("lastSync", lastSync);
	lastDate = new Date();
	$m.putPref("lastDate", lastDate);
	$m.savePref;
	IRMServices.sync({"fromDate" : lastDate.toString("dd-MMM-yyyy"), "toDate" : new Date().toString("dd-MMM-yyyy")}, callbackSync);
//	onDataInitialize();
}

var callbackSync = function(res){
	var response = x2js.xml_str2json(res.data);
	var responseData = response["Envelope"]["Body"]["P_GET_IRM_HOLDING_DATEWISEResponse"]["P_GET_IRM_HOLDING_DATEWISEResult"];
	
	responseData = JSON.parse(responseData);
	if(responseData.Table.length == 0){
		$m.toast("No updates found");
	}
};

function onDataInitialize(){
	if(getDatePref()){
		var callback = function(){
		getHoldingDetails();	
	};
	initializeData(callback);	
	}	
}

function getDatePref(){
	var flag = false;
	var prefDate = Utils.GetPref("dataSyncTime");
	if(!prefDate){
		return true;
	}
	var today = new Date().getTime();
	var currentdate = new Date(today).getDate();
	prefDate = new Date(prefDate).getDate();
	if(prefDate != currentdate){
		flag = true;
	}
	return flag;
}

function getHoldingDetails(){
	var callback = function(resp){
		var response = x2js.xml_str2json(resp.data);
		var data = response["Envelope"]["Body"]["P_GET_IRM_HOLDINGResponse"]["P_GET_IRM_HOLDINGResult"];
		data = JSON.parse(data);
		data = data.Table.slice(1,9000);
		var holdingArray = [];
		for(var j=0;j<data.length;j++){
			data[j].SRNO = parseInt(j)+1;
			data[j].RECORDDATE = setDate(data[j].RECORDDATE);
			var holdingData = new holding_details(data[j]);
			holdingArray.push(holdingData);
		}
		holding_details.removeAll(function(res){
			holding_details.multipleReplace(holdingArray,function(resp){
				$m.hideProgress();
				Utils.PutPref("dataSyncTime", Utils.GetTimeStamp());
				$m.toast("Data saved successfully");
				insertInteraction();
			},function(res){
				$m.hideProgress();
				$m.alert("failed to insert data");
			});
		},function(fresp){
			$m.hideProgress();
			$m.alert("failed to delete data");
		});	
	};
	$m.showProgress("Fetching Holding Data...");
	IRMServices.getHolding("",callback);
}


function insertInteraction(){
	var callback = function(resp){
		var response = x2js.xml_str2json(resp.data);
		var data = response["Envelope"]["Body"]["P_GET_IRM_INTERACTIONResponse"]["P_GET_IRM_INTERACTIONResult"];
		data = JSON.parse(data);
		data = data.Table;
		var interactionArray = [];
		for(var i=0;i<data.length;i++){
			data[i].DATE_OF_INT = setDate(data[i].DATE_OF_INT);
			if(data[i].FUND_NAME){
				data[i].FUND_NAME = data[i].FUND_NAME.toUpperCase();	
			}
			var interactiondata = new interaction_details(data[i]);
			interactionArray.push(interactiondata);
		}
		interaction_details.removeAll(function(response){
			interaction_details.multipleReplace(interactionArray,function(resp){
				$m.hideProgress();
				$m.toast("Data saved successfully");
			},function(res){
				$m.hideProgress();
				$m.alert("failed to insert data");
			});
		});	
	};
	$m.showProgress("Fetching Interaction Data...");
	IRMServices.getInteraction("",callback);
}

function initializeData(callback){
	var dbhelpercallback = function(dbhelper) {
        if (dbhelper) {
			interaction_details.createTable(create_table_success, create_table_failure);
			holding_details.createTable(create_table_success, create_table_failure);
			callback();
        } else {
            $m.alert("Error while opening database");
        }
    };
    getDbhelper(dbhelpercallback);
}

function create_table_success(res) {
	$m.logInfo("Table created successfully");
	$m.toast("Tables created successfully!");
}

function create_table_failure(res) {
	$m.logError("Failed to create table --- " + JSON.stringify(res));
}

function setDate(recorddate){
	if(recorddate){
		recorddate = recorddate.slice(0,10);
		var datesplit = recorddate.split("-");
		var newdate = datesplit[0]+"-"+datesplit[1]+"-"+datesplit[2];
		return newdate;
	}
	else{
		return "1970-01-01";
	}
}