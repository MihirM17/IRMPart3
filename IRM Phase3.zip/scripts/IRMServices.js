/**
 * IRMServices.js
 * @author CloudPact Technologies
 * @description : This script is used for setting the SOAP template with IRM service
 **/
var IRMServices = {
	"_serviceUrl":"http://121.240.20.32/IRM_OUT_HOST/IRM_OUT_HOST.svc",
	"_actions" : {
		"addInteraction" : "AddInteraction",
		"getDates" : "GETDATES",
		"getHoldingData" : "GetHoldingsData",
		"getInteractionData" : "GetInteractionsData",
		"getLastRecordDates" : "GetLastRecordDates",
		"getBuyersAndSellers" : "GetTop15BuyerSeller",
		"getTop15FundManagers" : "GetTop15HoldingsData",
		"getGraphData" : "GetTrend",
		"getFundMangerByStatus" : "GetTop15HoldingsDataByStatus",
		"getFundManagerByCity" : "GetTop15FundManagerDataByCity",
		"getCityByCountry" : "GetTop15CityDataByCountry",
		"getBuyersSellers" : "GetTop15BuyerSeller",
		"getInteraction" : "P_GET_IRM_INTERACTION",
		"getHolding" : "P_GET_IRM_HOLDING",
		"getMeetingNo" : "P_GET_IRM_MEETING_NO",
		"getIntType" : "P_GET_IRM_INT_TYPE",
		"getMetBy" : "P_GET_IRM_METBY",
		"getUserDels" : "P_Get_IRM_UserDels",
		"getLOV" : "P_GET_IRM_LOV",
		"sync" : "P_GET_IRM_HOLDING_DATEWISE",
		"insertInteraction" : "P_INSRT_IRM_INTERACTION",
		"updateInteraction" : "P_UPDATE_IRM_INTERACTION"		
	},
	"_templates" : {
		"addInteraction" : '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:tem="http://tempuri.org/"><soapenv:Header/><soapenv:Body><tem:AddInteraction><tem:I_DATE_OF_INT>?dateofint?</tem:I_DATE_OF_INT><tem:I_MEETINGNO>?meetingno?</tem:I_MEETINGNO><tem:I_NAME_OF_PERSON>?nameofperson?</tem:I_NAME_OF_PERSON><tem:I_ACCOMPANIED_BY>?accompaniedby?</tem:I_ACCOMPANIED_BY><tem:I_GROUP_NAME>?groupname?</tem:I_GROUP_NAME><tem:I_TYPE_OF_INT>?typeofint?</tem:I_TYPE_OF_INT><tem:I_BROKERAGE_HOUSE>?brokerage?</tem:I_BROKERAGE_HOUSE><tem:I_CITY_OF_MEETING>?city?</tem:I_CITY_OF_MEETING><tem:I_LOCATION_OF_MEETING>?location?</tem:I_LOCATION_OF_MEETING><tem:I_MET_BY>?metby?</tem:I_MET_BY><tem:I_ALSO_ATTENDED>?attended?</tem:I_ALSO_ATTENDED><tem:I_IS_LOCAL_CONFERENCES>?conference?</tem:I_IS_LOCAL_CONFERENCES><tem:I_COUNTRY_OF_MEETING>?countryofmeeting?</tem:I_COUNTRY_OF_MEETING><tem:I_WINDOWSID>?windowsid?</tem:I_WINDOWSID><tem:O_MSG>?message?</tem:O_MSG></tem:AddInteraction></soapenv:Body></soapenv:Envelope>',
		
		"getDates" : '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:tem="http://tempuri.org/"><soapenv:Header/><soapenv:Body><tem:GETDATES/></soapenv:Body></soapenv:Envelope>',
		
		"getHoldingData" : '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:tem="http://tempuri.org/"><soapenv:Header/><soapenv:Body><tem:GetHoldingsData><tem:I_ASON_RECORDDATE>?09-Mar-2018?</tem:I_ASON_RECORDDATE></tem:GetHoldingsData></soapenv:Body></soapenv:Envelope>',
		
		"getInteractionData" : '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:tem="http://tempuri.org/"><soapenv:Header/><soapenv:Body><tem:GetInteractionsData><tem:I_INT_DATE>?09-Mar-2018?</tem:I_INT_DATE></tem:GetInteractionsData></soapenv:Body></soapenv:Envelope>',
		
		"getLastRecordDates" : '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:tem="http://tempuri.org/"><soapenv:Header/><soapenv:Body><tem:GetLastRecordDates/></soapenv:Body></soapenv:Envelope>',
		
		"getBuyersAndSellers" : '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:tem="http://tempuri.org/"><soapenv:Header/><soapenv:Body><tem:GetTop15BuyerSeller><tem:I_FLAG>?S?</tem:I_FLAG><tem:I_FROM_DATE>?02-Mar-2018?</tem:I_FROM_DATE><tem:I_TO_DATE>?09-Mar-2018?</tem:I_TO_DATE><tem:I_STATUS>?ALL?</tem:I_STATUS></tem:GetTop15BuyerSeller></soapenv:Body></soapenv:Envelope>',
		
		"getTop15FundManagers" : '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:tem="http://tempuri.org/"><soapenv:Header/><soapenv:Body><tem:GetTop15HoldingsData><tem:I_ASON_RECORDDATE>09-Mar-2018</tem:I_ASON_RECORDDATE></tem:GetTop15HoldingsData></soapenv:Body></soapenv:Envelope>',
		
		"getGraphData" : '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:tem="http://tempuri.org/"><soapenv:Header/><soapenv:Body><tem:GetTrend><tem:I_NAME>?BLACKROCK?</tem:I_NAME><tem:I_TYPE>FUNDMANAGER</tem:I_TYPE><tem:I_ASON_RECORDDATE>?</tem:I_ASON_RECORDDATE></tem:GetTrend></soapenv:Body></soapenv:Envelope>',
		
		"getFundMangerByStatus" : '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:tem="http://tempuri.org/"><soapenv:Header/><soapenv:Body><tem:GetTop15HoldingsDataByStatus><tem:I_ASON_RECORDDATE>?09-Mar-2018?</tem:I_ASON_RECORDDATE><tem:I_STATUS>?FII?</tem:I_STATUS></tem:GetTop15HoldingsDataByStatus></soapenv:Body></soapenv:Envelope>',

		"getCityByCountry" : '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:tem="http://tempuri.org/"><soapenv:Header/><soapenv:Body><tem:GetTop15CityDataByCountry><tem:I_COUNTRY>?US?</tem:I_COUNTRY><tem:I_ASON_RECORDDATE>?09-Mar-2018?</tem:I_ASON_RECORDDATE><tem:I_STATUS>ALL</tem:I_STATUS></tem:GetTop15CityDataByCountry></soapenv:Body></soapenv:Envelope>',

		"getFundManagerByCity" : '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:tem="http://tempuri.org/"><soapenv:Header/><soapenv:Body><tem:GetTop15FundManagerDataByCity><tem:I_CITY>?LONDON?</tem:I_CITY><tem:I_ASON_RECORDDATE>?09-Mar-2018?</tem:I_ASON_RECORDDATE><tem:I_STATUS>ALL</tem:I_STATUS></tem:GetTop15FundManagerDataByCity></soapenv:Body></soapenv:Envelope>',

		"getInteraction" : '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:tem="http://tempuri.org/"><soapenv:Header/><soapenv:Body><tem:P_GET_IRM_INTERACTION/></soapenv:Body></soapenv:Envelope>',
		
		"getBuyersSellers" : '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:tem="http://tempuri.org/"><soapenv:Header/><soapenv:Body><tem:GetTop15BuyerSeller><tem:I_FLAG>?B?</tem:I_FLAG><tem:I_FROM_DATE>?02-Mar-2018?</tem:I_FROM_DATE><tem:I_TO_DATE>?09-Mar-2018?</tem:I_TO_DATE><tem:I_STATUS>?ALL?</tem:I_STATUS></tem:GetTop15BuyerSeller></soapenv:Body></soapenv:Envelope>',
		
		"getHolding" : '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:tem="http://tempuri.org/"><soapenv:Header/><soapenv:Body><tem:P_GET_IRM_HOLDING/></soapenv:Body></soapenv:Envelope>',
		
		"getMeetingNo" : '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:tem="http://tempuri.org/"><soapenv:Header/><soapenv:Body><tem:P_GET_IRM_MEETING_NO/></soapenv:Body></soapenv:Envelope>',
		
		"getIntType" : '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:tem="http://tempuri.org/"><soapenv:Header/><soapenv:Body><tem:P_GET_IRM_INT_TYPE/></soapenv:Body></soapenv:Envelope>',
		
		"getMetBy" : '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:tem="http://tempuri.org/"><soapenv:Header/><soapenv:Body><tem:P_GET_IRM_METBY/></soapenv:Body></soapenv:Envelope>',
		
		"getUserDels" : '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:tem="http://tempuri.org/"><soapenv:Header/><soapenv:Body><tem:P_Get_IRM_UserDels/></soapenv:Body></soapenv:Envelope>',
		
		"getLOV" : '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:tem="http://tempuri.org/"><soapenv:Header/><soapenv:Body><tem:P_GET_IRM_LOV><!--Optional:--><tem:I_TYPE>HOLDING_CATEGORY</tem:I_TYPE><!--Optional:--><tem:I_TITLE></tem:I_TITLE></tem:P_GET_IRM_LOV></soapenv:Body></soapenv:Envelope>',
		
		"sync" : '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:tem="http://tempuri.org/"><soapenv:Header/><soapenv:Body><tem:P_GET_IRM_HOLDING_DATEWISE><!--Optional:--><tem:I_FROMDATE>?1-JAN-2018?</tem:I_FROMDATE><!--Optional:--><tem:I_TODATE>?31-JAN-2018?</tem:I_TODATE></tem:P_GET_IRM_HOLDING_DATEWISE></soapenv:Body></soapenv:Envelope>',
		
		"insertInteraction" : '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:tem="http://tempuri.org/"><soapenv:Header/><soapenv:Body><tem:P_INSRT_IRM_INTERACTION><tem:I_DATE_OF_INT>?dateofint?</tem:I_DATE_OF_INT><tem:I_MEETINGNO>?meetingno?</tem:I_MEETINGNO><tem:I_NAME_OF_PERSON>?nameofperson?</tem:I_NAME_OF_PERSON><tem:I_ACCOMPANIED_BY>?accompaniedby?</tem:I_ACCOMPANIED_BY><tem:I_GROUP_NAME>?groupname?</tem:I_GROUP_NAME><tem:I_TYPE_OF_INT>?typeofint?</tem:I_TYPE_OF_INT><tem:I_BROKERAGE_HOUSE>?brokerage?</tem:I_BROKERAGE_HOUSE><tem:I_CITY_OF_MEETING>?city?</tem:I_CITY_OF_MEETING><tem:I_LOCATION_OF_MEETING>?location?</tem:I_LOCATION_OF_MEETING><tem:I_MET_BY>?metby?</tem:I_MET_BY><tem:I_ALSO_ATTENDED>?attended?</tem:I_ALSO_ATTENDED><tem:I_IS_LOCAL_CONFERENCES>?conference?</tem:I_IS_LOCAL_CONFERENCES><tem:I_COUNTRY_OF_MEETING>?countryofmeeting?</tem:I_COUNTRY_OF_MEETING><tem:I_WINDOWSID>?windowsid?</tem:I_WINDOWSID><tem:O_MSG>?message?</tem:O_MSG></tem:P_INSRT_IRM_INTERACTION></soapenv:Body></soapenv:Envelope>',
		
		"updateInteraction" : '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:tem="http://tempuri.org/"><soapenv:Header/><soapenv:Body><tem:P_UPDATE_IRM_INTERACTION><tem:I_DATE_OF_INT>?dateofint?</tem:I_DATE_OF_INT><tem:I_MEETINGNO>?meetingno?</tem:I_MEETINGNO><tem:I_NAME_OF_PERSON>?nameofperson?</tem:I_NAME_OF_PERSON><tem:I_ACCOMPANIED_BY>?accompaniedby?</tem:I_ACCOMPANIED_BY><tem:I_GROUP_NAME>?groupname?</tem:I_GROUP_NAME><tem:I_TYPE_OF_INT>?typeofint?</tem:I_TYPE_OF_INT><tem:I_BROKERAGE_HOUSE>?brokerage?</tem:I_BROKERAGE_HOUSE><tem:I_CITY_OF_MEETING>?city?</tem:I_CITY_OF_MEETING><tem:I_LOCATION_OF_MEETING>?location?</tem:I_LOCATION_OF_MEETING><tem:I_MET_BY>?metby?</tem:I_MET_BY><tem:I_ALSO_ATTENDED>?attended?</tem:I_ALSO_ATTENDED><tem:I_IS_LOCAL_CONFERENCES>?conference?</tem:I_IS_LOCAL_CONFERENCES><tem:I_COUNTRY_OF_MEETING>?countryofmeeting?</tem:I_COUNTRY_OF_MEETING><tem:I_WINDOWSID>?windowsid?</tem:I_WINDOWSID><tem:I_SRNO>?srno?</tem:I_SRNO><tem:O_MSG>?message?</tem:O_MSG></tem:P_UPDATE_IRM_INTERACTION></soapenv:Body></soapenv:Envelope>'
	},
	"addInteraction" : function(data, callbacck){
		var url = this._serviceUrl;
		var requestTemplate = this._templates.addInteraction;
		dateOfMeeting = data.dateOfMeeting.toString("dd-MMM-yyyy");
		requestTemplate = requestTemplate.replace("?dateofint?", dateOfMeeting);
		requestTemplate = requestTemplate.replace("?meetingno?", data.meetingNumber);
		requestTemplate = requestTemplate.replace("?nameofperson?", data.nameOfFundManager);
		requestTemplate = requestTemplate.replace("?accompaniedby?", data.accompainedBy);
		requestTemplate = requestTemplate.replace("?groupname?", "GROUP NAME");
		requestTemplate = requestTemplate.replace("?typeofint?", data.selectedInteractionType.TYPE_OF_INT);
		requestTemplate = requestTemplate.replace("?brokerage?", data.brokerageHouse);
		requestTemplate = requestTemplate.replace("?city?", data.selectedCity);
		requestTemplate = requestTemplate.replace("?location?", data.selectedLocation);
		requestTemplate = requestTemplate.replace("?metby?", data.metBy);
		requestTemplate = requestTemplate.replace("?attended?", data.alsoAttended);
		requestTemplate = requestTemplate.replace("?conference?", data.selectConferenceType);
		requestTemplate = requestTemplate.replace("?countryofmeeting?", data.selectedCountryOfInvestor);
		requestTemplate = requestTemplate.replace("?windowsid?","DIPESHGITC");
		requestTemplate = requestTemplate.replace("?message?","");
		this._fireRequest(url,this._actions.addInteraction, requestTemplate,callback);
	},
	"getDates" : function(data, callback){
		var url = this._serviceUrl;
		var requestTemplate = this._templates.getDates;
		this._fireRequest(url,this._actions.getDates,requestTemplate,callback);
	},
	"getTop15FundManagers" : function(data, callback){
		var url = this._serviceUrl;
		var requestTemplate = this._templates.getTop15FundManagers;
		var dateOfMeeting = data.toString("dd-MMM-yyyy");
		requestTemplate = requestTemplate.replace("?09-Mar-2018?", dateOfMeeting);
		this._fireRequest(url,this._actions.getTop15FundManagers,requestTemplate,callback);
	},
	"getFundMangerByStatus" : function(data, callback){
		var url = this._serviceUrl;
		var requestTemplate = this._templates.getFundMangerByStatus;
		var dateOfMeeting = data.DATES.toString("dd-MMM-yyyy");
		requestTemplate = requestTemplate.replace("?09-Mar-2018?", dateOfMeeting);
		requestTemplate = requestTemplate.replace("?FII?", data.STATUS);
		this._fireRequest(url,this._actions.getFundMangerByStatus,requestTemplate,callback);
	},
	"getHoldingData" : function(data, callback){
		var url = this._serviceUrl;
		var requestTemplate = this._templates.getHoldingData;
		var dateOfMeeting = data.toString("dd-MMM-yyyy");
		requestTemplate = requestTemplate.replace("?09-Mar-2018?", dateOfMeeting);
		this._fireRequest(url,this._actions.getHoldingData,requestTemplate,callback);
	},
	"getCityByCountry" : function(data, callback){
		var url = this._serviceUrl;
		var requestTemplate = this._templates.getHoldingData;
		var dateOfMeeting = data.date.toString("dd-MMM-yyyy");
		requestTemplate = requestTemplate.replace("?US?", data.country);
		requestTemplate = requestTemplate.replace("?09-Mar-2018?", dateOfMeeting);
		this._fireRequest(url,this._actions.getHoldingData,requestTemplate,callback);
	},
	"getFundManagerByCity" : function(data, callback){
		var url = this._serviceUrl;
		var requestTemplate = this._templates.getHoldingData;
		var dateOfMeeting = data.date.toString("dd-MMM-yyyy");
		requestTemplate = requestTemplate.replace("?US?", data.CITY);
		requestTemplate = requestTemplate.replace("?09-Mar-2018?", dateOfMeeting);
		this._fireRequest(url,this._actions.getHoldingData,requestTemplate,callback);
	},
	"getInteractionData" : function(data, callback){
		var url = this._serviceUrl;
		var requestTemplate = this._templates.getInteractionData;
		var dateOfMeeting = data.toString("dd-MMM-yyyy");
		requestTemplate = requestTemplate.replace("?09-Mar-2018?", dateOfMeeting);
		this._fireRequest(url,this._actions.getInteractionData,requestTemplate,callback);
	},
	"getLastRecordDates" : function(data, callback){
		var url = this._serviceUrl;
		var requestTemplate = this._templates.getLastRecordDates;
		this._fireRequest(url,this._actions.getLastRecordDates,requestTemplate,callback);
	},
	"getInteraction" : function(data, callback){
		var url = this._serviceUrl;
		var requestTemplate = this._templates.getInteraction;
		this._fireRequest(url,this._actions.getInteraction,requestTemplate,callback);
	//	this.fireHttpRequest(url,this._actions.getInteraction,requestTemplate,callback);
	},
	"getBuyersSellers" : function(data, callback){
		var url = this._serviceUrl;
		var requestTemplate = this._templates.getBuyersSellers;
		var fromDate = data.DATES[0].toString("dd-MMM-yyyy");
		var toDate = data.DATES[1].toString("dd-MMM-yyyy");
		requestTemplate = requestTemplate.replace("?B?", data.FLAG);
		requestTemplate = requestTemplate.replace("?02-Mar-2018?", fromDate);
		requestTemplate = requestTemplate.replace("?09-Mar-2018?", toDate);
		requestTemplate = requestTemplate.replace("?ALL?", data.STATUS);
		this._fireRequest(url,this._actions.getBuyersSellers,requestTemplate,callback);
	},
	"getHolding" : function(data, callback){
		var url = this._serviceUrl;
		var requestTemplate = this._templates.getHolding;
		this._fireRequest(url,this._actions.getHolding,requestTemplate,callback);
	},
	"getMeetingNo" : function(data, callback){
		var url = this._serviceUrl;
		var requestTemplate = this._templates.getMeetingNo;
		this._fireRequest(url,this._actions.getMeetingNo,requestTemplate,callback);
	},
	"getIntType" : function(data, callback){
		var url = this._serviceUrl;
		var requestTemplate = this._templates.getIntType;
		this._fireRequest(url,this._actions.getIntType,requestTemplate,callback);
	},
	"getMetBy" : function(data, callback){
		var url = this._serviceUrl;
		var requestTemplate = this._templates.getMetBy;
		this._fireRequest(url,this._actions.getMetBy,requestTemplate,callback);
	},
	"getUserDels" : function(data, callback){
		var url = this._serviceUrl;
		var requestTemplate = this._templates.getUserDels;
		this._fireRequest(url,this._actions.getUserDels,requestTemplate,callback);
	},
	"getLOV" : function(data, callback){
		var url = this._serviceUrl;
		var requestTemplate = this._templates.getLOV;
		this._fireRequest(url,this._actions.getLOV,requestTemplate,callback);
	},
	"sync" : function(data, callback){
		var url = this._serviceUrl;
		var requestTemplate = this._templates.sync;
		requestTemplate = requestTemplate.replace("?1-JAN-2018?", data.fromDate);
		requestTemplate = requestTemplate.replace("?31-JAN-2018?", data.toDate);
		this._fireRequest(url, this._actions.sync, requestTemplate, callback);
	},
	"insertInteraction" : function(data, callback){
		var url = this._serviceUrl;
		var requestTemplate = this._templates.insertInteraction;
		dateOfMeeting = data.dateOfMeeting.toString("dd-MMM-yyyy");
		requestTemplate = requestTemplate.replace("?dateofint?", dateOfMeeting);
		requestTemplate = requestTemplate.replace("?meetingno?", data.meetingNumber);
		requestTemplate = requestTemplate.replace("?nameofperson?", data.nameOfFundManager);
		requestTemplate = requestTemplate.replace("?accompaniedby?", data.accompainedBy);
		requestTemplate = requestTemplate.replace("?groupname?", "GROUP NAME");
		requestTemplate = requestTemplate.replace("?typeofint?", data.selectedInteractionType.TYPE_OF_INT);
		requestTemplate = requestTemplate.replace("?brokerage?", data.brokerageHouse);
		requestTemplate = requestTemplate.replace("?city?", data.selectedCity);
		requestTemplate = requestTemplate.replace("?location?", data.selectedLocation);
		requestTemplate = requestTemplate.replace("?metby?", data.metBy);
		requestTemplate = requestTemplate.replace("?attended?", data.alsoAttended);
		requestTemplate = requestTemplate.replace("?conference?", data.selectConferenceType);
		requestTemplate = requestTemplate.replace("?countryofmeeting?", data.selectedCountryOfInvestor);
		requestTemplate = requestTemplate.replace("?windowsid?","DIPESHGITC");
		requestTemplate = requestTemplate.replace("?message?","");
		this._fireRequest(url,this._actions.insertInteraction, requestTemplate,callback);
	},
	"updateInteraction" : function(data, callback){
		var url = this._serviceUrl;
		var requestTemplate = this._templates.updateInteraction;
		requestTemplate = requestTemplate.replace("?dateofint?", "01-JAN-2018");
		requestTemplate = requestTemplate.replace("?meetingno?", "753");
		requestTemplate = requestTemplate.replace("?nameofperson?", "PERSON NAME");
		requestTemplate = requestTemplate.replace("?accompaniedby?", "ACOMPANIED BY");
		requestTemplate = requestTemplate.replace("?groupname?", "GROUP NAME");
		requestTemplate = requestTemplate.replace("?typeofint?", "Meeting at office");
		requestTemplate = requestTemplate.replace("?brokerage?", "BROKERAHE HOUSE");
		requestTemplate = requestTemplate.replace("?city?", "MUMBAI");
		requestTemplate = requestTemplate.replace("?location?", "MUMBAI");
		requestTemplate = requestTemplate.replace("?metby?", "Conrad Dsouza");
		requestTemplate = requestTemplate.replace("?attended?", "Anjalee Tarapore");
		requestTemplate = requestTemplate.replace("?conference?", "O");
		requestTemplate = requestTemplate.replace("?countryofmeeting?", "INDIA");
		requestTemplate = requestTemplate.replace("?windowsid?","DIPESHGITC");
		requestTemplate = requestTemplate.replace("?srno?","123");
		requestTemplate = requestTemplate.replace("?message?","");
		this._fireRequest(url,this._actions.updateInteraction, requestTemplate,callback);
	},

	"_fireRequest" : function(url,action, data, callback){
        if ($m.networkConnected()) {
			//var messagedigest = md5(data, Constants.mdkey);
            $m.post(url, data, {
				"timeout":60000,
                "headers": {
                    "Content-Type": "text/xml;charset=UTF-8",
                    "SOAPAction": "http://tempuri.org/IIRM_OUT_HOST/" + action
                }
            }, function(cb) {
                return function(response) {
                    if (response.code == 200) {
                    	console.log(response.code);
                        // Success
                        var result = response.result;
                        cb.call(this, result);
                    } else {
                    	console.log("error from service;");
                        // Error
						$m.alert("Please Try again","Server Error",function(){
						$m.hideProgress();
                        });
                        var errMsg = response;
                        $m.logError(JSON.stringify(response));
                    }
                };
            }(callback));
        } else {
            $m.alert("No Network connection","Network Alert",function(){
            	$m.hideProgress();
            });
        }
	}

}