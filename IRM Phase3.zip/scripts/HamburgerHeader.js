$m.onReady(function(){
	$m.pageTitle("");
	$m.pageTitleLeftButton('<img id="menu" class="mdesk" src="images/logo.png"></img>');
});

var dbHelper;

$m.onData(function(){
	var dbhelpercallback = function(db) {
		window.dbHelpher = db;
    };
    getDbhelper(dbhelpercallback);
});

function getDbhelper(callback) {
    new window.DB(Constants.DBName, function(db) {
        window.dbHelper = db;
        dbHelper = db;
        callback(window.dbHelper);
    }, function(error) {
        $m.logError("Unable to open database due to -- " + JSON.stringify(error));
    });
}