(function(){
	
	
	var headerselectbox = function(elem){
		this._super = juci.controls.basepicker;
		this._super(elem);
	}
	headerselectbox.prototype = {
		type: "selectbox",
		DefaultValue: null,
		DefaultOptionsTitle: '"Options"',
		DefaultPlaceholder: "Choose...",
		getDatabindConfig: function(){
			var r = this._super();
			juci.utils.arrayPushAll(r.keys, ["basecontrol", "optionsTitle", "list"]);
			juci.utils.arrayPushAll(r.map, ["ref", "optionsTitle", "optionsList"]);
			juci.utils.arrayPushAll(r.defaults, ['""', this.DefaultOptionsTitle]);
			r.ignore.push("optionsList");
			return r;
		},
		_onBindingsInitialize: function(params){
			this._super(params);
			if(this._val !== null){
				this.value(this._val);
			}
		},
		init: function(){
	
			if(typeof this._isMultiple == "undefined"){
				 this._isMultiple = (this._ds.multiple == "true");
			}
			this._mode = this.j.getAttr("data-mode", "select"); //default mobile select, set to popup for dropdown select
			if(!this._mode)
				this._mode = "select"; //default to normable mobile select behaviour
			this.showClear = this.j.getAttr("data-clear", false);
			this.opened = 0;
			this._super();
			this._tempVal = null;
			var comparator = this.j.attr("data-comparator");
			this._comparatorFn = window[comparator] ? function(val1, val2){ return window[comparator](val1 ? ko.mapping.toJS(val1) : val1, val2 ? ko.mapping.toJS(val2) : val2)} : juci.utils.defaultComparator;
			var optionValue = this.j.attr("data-option-value");
			this._optionValueFn = window[optionValue] ? function(val1, val2){ return window[optionValue](val1 ? ko.mapping.toJS(val1) : val1, val2 ? ko.mapping.toJS(val2) : val2)} : function(item){return item};
			if(this._isMultiple){
				this.j.addClass("multiple");
			}
			var optTmpl = this.j.find("[data-juci=optiontemplate]")[0];
			if(optTmpl){
				this.optionTemplate = "<div data-juci='optiontemplate'>"+optTmpl.html()+'</div>';
				optTmpl.remove();
			}else{
				this.optionTemplate = "";
			}
			this.selectPop = new juci.elem('<div tabindex=0 class="juci_selectbox_popup"></div>');
			this.selectPop.onBlur(function(){
			this._onCloseOptions(); //not stable in mobile
			},this);
			this.selectPop.insertAfter(this.j);
			this.selectPop.hide();
	
		},
		
		openPicker: function(evt){
			
			if (this.opened == 0){
		
				var e = new EventObject(evt);
				this.fireEvent("openpicker", e);
				if(!e.isCancelled()){
					this._pickerOpened = true;
					this.doOpenPicker();
				}
		
			
			}else{
				
				this.selectPop.hide();
				this.opened = 0;
			}
			
			
		},
		doOpenPicker: function(){
			if(!this.optionsPanel){
				this.initOptions();
				this.initPOptions();
			}
			var evt = new EventObject();
			this.fireEvent("beforeoptionsopen", evt);
			if(!evt.isCancelled()){
				if(this._mode == "select")
					this.optionsPanel.open(this.__params.optionsTitle);
				else{
					this._pcontrol.value(this._val);
					this.opened = 1;
					this.selectPop.show();
					//this.selectPop.el.focus(); //not stable in mobile
				}
			}
		},
		getComparator: function(){
			return this._comparatorFn;
		},
		setComparator: function(fn){
			this._comparatorFn = fn === juci.utils.defaultComparator ? fn : function(val1, val2){ return fn(val1 ? ko.mapping.toJS(val1) : val1, val2 ? ko.mapping.toJS(val2) : val2)};
		},
		setText: function(val){
			var inners = (val) ? this._formatter(val) : this.placeholder;
			//if(!inners){
			if(inners == this.placeholder){
				//To apply css for placeholder in selectbox
				inners = this.placeholder;
				this.j.addClass("juci_placeholder");
			}else{
				this.j.removeClass("juci_placeholder");
			}
			this.i.html(inners);
		},
		_onCloseOptions: function(evt){
			this.onClosePicker();
			this.selectPop.hide();
			this.opened = 0;
			if(this._search)
				this._search.clearSearch(true);
			if(!this._isMultiple){
				this._control.removeListener("beforechange", this._closeOptions, this); //Removed - since panel is closed without choosing an option
			}
			var oldVal = this._val;
			this._valueInList = this._control.value();
			var newVal = this._getNewValueFromControl(this._valueInList);
			if(oldVal !== newVal){
				this.__fireBeforeChange(oldVal, newVal);
			}
		},
		_getNewValueFromControl: function(){
			return this._optionValueFn(this._control.value());
		},
		_onOpenOptions: function(evt){
			if(typeof this._valueInList === "undefined"){
				this._valueInList = this.getValueFromList(this._val);
			}
			this._control.value(this._valueInList, true);
			this._control.refresh();
			if(!this._isMultiple){
				this._control.listenOnce("beforechange", this._closeOptions, this); // Pass true with the closePanel, this data can be read in onClose
			}
		},
		_closeOptions: function(){
			juci.closePanel(true);
		},
		// IMPORTANT options can be at any reference level - data, parent, root. By default select, options start from root always and ref starts from data
		// Document how to set data for options
		initOptions: function(){
			var optionsBg = new juci.elem("<div class='juci_selectbox_options_panel' data-panel-id='"+this._id+"_options'></div>");
			var optionsContainer = new juci.elem("<div></div>");
			var dataBindString = 'optionsList: $data' +
				(this._ds.optionsText ? ',optionsText: ' + this._ds.optionsText : '') +
				(this._ds.optionsValue ? ',optionsValue :' + this._ds.optionsValue : '') ;
			var controlElem = new juci.elem("<div data-juci='"+
					(this._isMultiple ? 'checkboxgroup' : 'radiogroup' )+
					"' data-bind='"+ dataBindString +"'>"+this.optionTemplate+"</div>"
				).appendTo(optionsContainer);
			// Adding search by default
			var searchString = this.j.attr("data-searcher");
			var searchDelayString = this.j.attr("data-search-delay");
			var searchBoxString = "";
			var placeholder = this.j.attr("data-search-placeholder");
			searchBoxString = "<div data-juci='searchbox' data-bind='ref: $data" +
				(searchDelayString ? (",delay:" + searchDelayString + "") : "") + "'" +
				" placeholder='"+ (placeholder ?  placeholder : "Search") +"'" +
				" " + (searchString ? ("data-searcher='" + searchString + "'") : ("data-aui='" + controlElem.getId() + "'")) +
			"></div>";
			var searchBoxElem = new juci.elem(searchBoxString).appendTo(optionsContainer);
			this.optionsPanel = new juci.panel(optionsBg);
			optionsBg.attr("data-bind","juciwith: $data");
			if(this.showClear){
				var bbar = new juci.elem("<div class='juci_vertical_bbar juci_selectbox_clearbbar'>"+
				"<button data-juci='button'>Clear</button>"+
			"</div>").appendTo(optionsBg);
				var bbar2 = bbar.clone();
				bbar.addClass("juci_selectbox_top");
				bbar2.addClass("juci_selectbox_bottom");
				bbar2.prependTo(optionsBg);
				bbar2.attr("data-bind", "ref: " + this._ds.optionsList + ", show: function(i){return i.length > 6}");
			}
			this.fireEvent("beforeinitoptions", {optionsPanel: this.optionsPanel});
			this.optionsPanel.listenOnce("init", function(){
				optionsContainer.appendTo(optionsBg);
				juci.controls.init(optionsContainer.el);
				juci.viewModel.applyBinding(optionsContainer.el, this.__params.list);
				this._search = juci.getControl(searchBoxElem);
				this._control = juci.getControl(controlElem);
				searchBoxElem.prependTo(optionsBg);
				this._search.setValueAccessor(this.__params.list);
				this._search.addListener("beforesearch", this._control._onBeforeSearch, this._control);
				this._search.addListener("beforesearch", this._onBeforeSearch, this);
				this._search.addListener("search", this._control._onSearch, this._control);
				this._search.addListener("search", this._onSearch, this);
				this._search.addListener("clear", this._control._onClearSearch, this._control);
				this._search.addListener("clear", this._onClearSearch, this);
				this._search.addListener("aftersearch", this._control._onAfterSearch, this._control);
				this._search.addListener("aftersearch", this._onAfterSearch, this);
				this._control.onBeforeChange(this._fireValidation, this);
				this.fireEvent("initoptions");
			}, this);
			if(this.showClear){
				this.optionsPanel.listenOnce("init", function(){
					var bs1 = bbar.children();
					var bs2 = bbar2.children();
					bbar2.appendTo(optionsBg);
					juci.getControl(bs1[0]).onClick(this._control.clear, this._control);
					juci.getControl(bs2[0]).onClick(this._control.clear, this._control);
				}, this);
			}
			this.postInitOptions(optionsBg);
		},

		initPOptions: function(){
			var poptionsBg = new juci.elem("<div class='juci_selectbox_popup_panel' data-panel-id='"+this._id+"_poptions'></div>");
			var poptionsContainer = new juci.elem("<div></div>");
			var dataBindString = 'optionsList: $data' +
				(this._ds.optionsText ? ',optionsText: ' + this._ds.optionsText : '') +
				(this._ds.optionsValue ? ',optionsValue :' + this._ds.optionsValue : '');
			var controlElem = new juci.elem("<div data-juci='"+
					(this._isMultiple ? 'checkboxgroup' : 'headerradiogroup' )+
					"' data-bind='"+ dataBindString +"'>"+this.optionTemplate+"</div>"
				).appendTo(poptionsContainer);
			this.selectPop.append(poptionsBg);
			poptionsBg.attr("data-bind","juciwith: $data");

			poptionsContainer.appendTo(poptionsBg);
			juci.controls.init(poptionsContainer.el);
			juci.viewModel.applyBinding(poptionsContainer.el, this.__params.list);
			this._control = juci.getControl(controlElem);
			this._pcontrol = juci.getControl(controlElem);
			this._pcontrol.onBeforeChange(this._fireValidation, this);
			this._pcontrol.onAfterChange(this._onCloseOptions, this);
		},

		hideClearBar: function(){
			if(this.optionsPanel){
				var clearBars = this.optionsPanel.j.findByClass(".juci_selectbox_clearbbar");
				for(var i = 0; i < clearBars.length; i++){
					clearBars[i].hide();
				}
			}else{
				this.showClear = false;
			}
		},
		showClearBar: function(){
			if(this.optionsPanel){
				var clearBars = this.optionsPanel.j.findByClass(".juci_selectbox_clearbbar");
				for(var i = 0; i < clearBars.length; i++){
					clearBars[i].show();
				}
			}else{
				this.showClear = true;
			}
		},
		Events: juci.controls.basecontrol.prototype.Events.concat(juci.controls.basepicker.prototype.Events.concat(["beforeinitoptions", "initoptions", "afterinitoptions","beforesearch", "search", "searchclear", "aftersearch", "beforeoptionsopen"])),
		postInitOptions: function(optionsBg){
			this.optionsPanel.addListener("open", this._onOpenOptions, this);
			this.optionsPanel.addListener("close", this._onCloseOptions, this);
			this.fireEvent("afterinitoptions", {optionsPanel: this.optionsPanel});
		},
		_onBeforeSearch: function(evt){
			this.fireEvent("beforesearch", new EventObject(evt, evt));
		},
		_onAfterSearch: function(evt){
			this.fireEvent("aftersearch", new EventObject(evt, evt));
		},
		_onSearch: function(evt){
			this.fireEvent("search", new EventObject(evt, evt));
		},
		_onClearSearch: function(evt){
			this.fireEvent("searchclear", new EventObject(evt, evt));
		},
		_fireValidation: function(evt){
			this.fireEvent("checkconstraints", new EventObject(evt, evt));
			if(!evt.isCancelled()){
				this._control.value(evt.newValue, true);
			}
		},
		value: function(val, dontCheck){
			if(typeof val == "undefined"){
				return this._returner(this._val);
			}else{
				// Check from list of values with comparator and then set the value
				if(this._val !== val){
					this._valueInList = this.getValueFromList(val);
					this._val = this._valueInList;
				}

				this.setText(this._val);
			}
		},
		getValueFromList: function(val){
			var v = null, ds = ko.utils.unwrapObservable(this.__params.list), noOpts = ds ? ds.length : 0;
			for(var i = 0; i < noOpts; i++){
				var item = ds[i];
				if(this.getComparator()(item, val, i)){
					v = item;
					break;
				}
			}
			return v;
		}
	};
	// Events
	{
	}
	juci.extend(headerselectbox, juci.controls.basepicker);
	juci.controls.headerselectbox = headerselectbox;


var headerradiogroup = function(elem){
		this._super = juci.controls.basecontrol;
		this._super(elem);
	}
	headerradiogroup.prototype = {
		type: "radiogroup",
		DefaultValue: null,
		getDefaultValue: function(){
			return new Function("return " + this.j.getAttr("data-value", this.DefaultValue))();
		},
		_onOptionClick: function(e){
			var delegatee = e.delegatee;
			if(delegatee != null){
				this._onOptionSelected(delegatee);
			}
		},
		_onOptionSelected: function(elem){
			var oldSelected = this.j.findByClass("selected")[0];
			if(oldSelected && elem != oldSelected){
				oldSelected.removeClass("selected");
			}
			elem.addClass("selected");
			var oldVal = this._val;
			this._val = this._valueHandler(ko.dataFor(elem.el));
			this.__fireBeforeChange(oldVal, this._val);
		},
		getInnerOptionTemplate: function(){
			var optTmpl = this.j.find("[data-juci=optiontemplate]")[0], inners;
			if(optTmpl){
				inners = '<div class="juci_option_label">' + optTmpl.html() + '<div>';
				optTmpl.remove();
			}else{
				inners = '<div class="juci_option_label">' + // cell
				'<label data-bind="html: '+
						(this._ds.optionsText ? this._ds.optionsText : 'function(item){return item}')+
				'"></label>' +
				'</div>';
			}
			return inners;
		},
		getDatabindConfig: function(){
			var r = this._super();
			juci.utils.arrayPushAll(r.keys, ["basecontrol"]);
			juci.utils.arrayPushAll(r.map, ["ref"]);
			juci.utils.arrayPushAll(r.defaults, ['""']);
			juci.utils.arrayPushAll(r.ignore, ["optionsList", "optionsText", "optionsValue"]);
			return r;
		},
		init: function(){
		
			if(this._ds){
				this.j.attr("data-bind", this.getDatabindString());
			}
			if(this.j.attr("data-label")){
				this.label = juci.controls.addLabel(this.j, this.j.attr("data-label-bind"));
			}
			//var dataBindString = 'ref: ' + (this._ds.ref ? this._ds.ref : '""')  + ',optionsList: $root.' +
			var dataBindString = 'ref: ' + (this._ds.ref ? this._ds.ref : this._ds.optionsList)  + ',optionsList: ' +
						this._ds.optionsList + (this._ds.optionsText ? ', optionsText: ' + this._ds.optionsText : '') +
						(this._ds.optionsValue ? ", optionsValue: " + this._ds.optionsValue : "");
			/*
				<div class="juci_radiogroup">
					<div class="juci_control_label>
						<label></label>
					</div>
					<ul class="juci_ctrl_box juci_options"> table
						<li class="juci_check juci_option"> table row repeat
							<div class="juci_option_label"> cell
								<label>Red</label>
							</div>
						</li>
					</ul>
				</div>
			*/
			this._container = new juci.elem("<ul data-juci='radio' data-bind='"+dataBindString+"'></ul>").appendTo(this.j);
			if(!juci.hasTouch){
				this._focusser = new juci.elem('<a class="juci_ctrl_focusser" href="#"></a>');
				this.j.prepend(this._focusser);
				this._focusser.onFocus(this._onFocus, this);
				this._focusser.onBlur(this._onBlur, this);
				this._focusser.onKeyDown(function(e){
					this._onKeyPress(e);
				}, this);
				this._focusser.onKeyPress(this._onKeyPress, this);
			}
			this.optionTemplate = new juci.elem('<li>' + //table row repeat
							this.getInnerOptionTemplate() +
							'</li>', false).appendTo(this._container);
			this._container.onClick(this._onOptionClick, this, ".juci_option");
			// TODO Add options placeholder data-options-placeholder
			var optsPlaceholder = "No options";
			//this.j.append("<div class='juci_options_placeholder' data-bind='show: $root."+this._ds.optionsList+"().length == 0'>"+optsPlaceholder+"</div>");
			this.j.append("<div class='juci_options_placeholder' data-bind='ref: "+this._ds.optionsList+", show: juci.utils.isEmpty'>"+optsPlaceholder+"</div>");
			this._valueHandler = null;
			//this._val = null;
			this._selectedOption = null;
			var comparator = this.j.attr("data-comparator");
			this._comparatorFn = window[comparator] ? function(val1, val2){ return window[comparator](val1 ? ko.mapping.toJS(val1) : val1, val2 ? ko.mapping.toJS(val2) : val2)} : juci.utils.defaultComparator;
			var that = this;
			this.searchHandler = this._ds.optionsValue ? function(item, searchValue){
				return that.__listparams.optionsValue(item).toLowerCase().search(searchValue.toLowerCase()) > -1;
			}: this._ds.optionsText ? function(item, searchValue){
				return that.__listparams.optionsText(item).toLowerCase().search(searchValue.toLowerCase()) > -1;
			} : function(item, searchValue){
				return (""+item).toLowerCase().search(searchValue.toLowerCase()) > -1;
			};
		},
		_onFocus: function(){
			this._options = this._container.find(".juci_check.juci_option");
			if(this._options.length == 0){
				this._currIndex = -1;
				return;
			}
			this._currIndex = 0;
			this._options[this._currIndex].addClass("touch");
			this._options[this._currIndex].scrollIntoViewIfNeeded();
		},
		_onBlur: function(){
			if(this._currIndex != -1){
				this._options[this._currIndex].removeClass("touch");
				this._currIndex = -1;
			}
		},
		_onKeyPress: function(e){
			var kC = e.srcEvent.keyCode;
			if(kC == 13 || kC == 32){
				// Select
				this._onOptionSelected(this._options[this._currIndex]);
				e.preventDefault();
			}else if(kC == 38 && this._currIndex > 0){
				// Up
				this._options[this._currIndex--].removeClass("touch");
				this._options[this._currIndex].addClass("touch");
				this._options[this._currIndex].scrollIntoViewIfNeeded();
				e.preventDefault();
			}else if(kC == 40 && this._currIndex+1 < this._options.length){
				// Down
				this._options[this._currIndex++].removeClass("touch");
				this._options[this._currIndex].addClass("touch");
				this._options[this._currIndex].scrollIntoViewIfNeeded();
				e.preventDefault();
			}
		},
		_onAfterSearch: function(evt){
			this.fireEvent("aftersearch", new EventObject(evt, evt));
		},
		_onBeforeSearch: function(evt){
			this.fireEvent("beforesearch", new EventObject(evt, evt));
		},
		_onSearch: function(evt){
			this.fireEvent("search", new EventObject(evt, evt));
		},
		_onClearSearch: function(evt){
			this.fireEvent("searchclear", new EventObject(evt, evt));
		},
		enable: function(){
			this._container.enable();
		},
		disable: function(){
			this._container.disable();
		},
		_onListInitialize: function(params){
			this.__listparams = params;
			var v = this._val;
			this._val = null;
			this.value(v);
		},
		_onBindingsInitialize: function(){
			var params = this.__params;
			this._valueHandler = (typeof params.optionsValue == "undefined") ? function(value){return value;} : function(value){ return params.optionsValue(ko.mapping.toJS(value));};
		},
		refresh: function(){
			var handler = this._valueHandler;
			var opts = this.j.findByClass("juci_option", false);
			var optionSelected = false;
			var comparatorFn = this._comparatorFn;
			var valueInVal = this._val;
			this._selectedOption = null;
			var iteratorFn = valueInVal ?(
				function(opt, optIndex){
					opt.removeClass("selected");
					if(!optionSelected){
						var valueInOpt = handler(ko.dataFor(opt.el));
						if(comparatorFn(valueInOpt, valueInVal, optIndex)){
							opt.addClass("selected");
							optionSelected = true;
							this._selectedOption = opt;
							// TODO Fire on option select
						}
					}
				}
			) : (
				function(opt){
					opt.removeClass("selected");
				}
			);
			opts.forEach(iteratorFn, this);
		},
		getComparator: function(){
			return this._comparatorFn;
		},
		setComparator: function(fn){
			this._comparatorFn = fn === juci.utils.defaultComparator ? fn : function(val1, val2){ return fn(val1 ? ko.mapping.toJS(val1) : val1, val2 ? ko.mapping.toJS(val2) : val2)};
		},
		value: function(val, dontCheck){
			if(typeof val == "undefined"){
				return this._returner(this._val);
			}else{
				if(this._val !== val){
					this._valueInList = this.getValueFromList(val);
					this._val = this._valueInList;
					this.refresh();
				}
			}
		},
		getValueFromList: function(val){
			
			if(!this.__listparams){
				return val;
			}
			var v = null, ds = ko.utils.unwrapObservable(this.__listparams.optionsList), noOpts = ds ? ds.length : 0;
			for(var i = 0; i < noOpts; i++){
				var item = ds[i];
				if(this.getComparator()(item, val, i)){
					v = item;
					break;
				}
			}
			return v;
		}
	};
	juci.extend(headerradiogroup, juci.controls.basecontrol);
	juci.controls.headerradiogroup = headerradiogroup;
	
	
	
	
	
	
	
	
	
	
	

})();
