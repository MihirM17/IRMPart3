$m.juci.addDataset("topno", "15");
$m.juci.addDataset("filter", [{name : "ALL" , children  :[{name: "child1"}]}]);
$m.juci.addDataset("list_visible","");
$m.juci.addDataset("todays_date","");
$m.juci.addDataset("searchPop","");
$m.juci.addDataset("buyerss",[]);
$m.juci.addDataset("sellerss",[]);
$m.juci.addDataset("fundManager", []);
$m.juci.addDataset("groupName", []);
$m.juci.addDataset("country", []);
$m.juci.addDataset("cityList", []);
$m.juci.addDataset("newsList", []);
$m.juci.addDataset("managerName", "");
$m.juci.addDataset("selectedItem", "All");
$m.juci.addDataset("interactionList", []);
$m.juci.addDataset("buyersDate", []);
$m.juci.addDataset("sellersDate", []);

var latestRecord = [],lastRecord = [],Record_flag=1,bFlag = 0,sFlag = 0;

var newsDetails = {
	"image":"",
	"title":"",
	"link":""
};

$m.juci.addDataset("newsDetails", newsDetails);
$m.juci.addDataset("toggleVisible", "fund-manager");

var x2js = new X2JS();
var dbHelper;

$m.juci.addDataset("selectedFilter", {name: "ALL"});
var domestic = [];
var foreign = [];

function openPopUp(event){
	$('#body_start').css('position', 'fixed');
	$m.juci.dataset("managerName", "");
	$m.juci.showDialog("dialog_popup"); 
}

function openHambuggerPage(){
	console.log("ham");
	openMenu(1);
}

function closePopUp(e){
	$('#body_start').css('position','relative');
	$m.juci.hideDialog("dialog_popup");
}

$m.onReady(function(eventObject) {
	$m.juci.findById("__leftBtn").onClick(function(){openMenu(1);});
	$m.juci.dataset("todays_date", getLastFriday(new Date()));
});

$m.onData(function(eventObject){
	eventObject.hideProgress = false;
//	latestRecord = [],lastRecord = [],Record_flag=1,bFlag = 0,sFlag = 0;
	var dbhelpercallback = function(db) {
		window.dbHelpher = db;
		onDataInitialize();
//		getHoldingData();
    };
    getDbhelper(dbhelpercallback);
//    $m.showProgress();
    IRMServices.getLOV("", callbackforSelectBox);
//    IRMServices.getDates("", callbackforDates);
	$m.hideProgress();
});

var callbackforDates = function(resp){
	var response = x2js.xml_str2json(resp.data);
	var responseStatus = response["Envelope"]["Body"]["GETDATESResponse"]["GETDATESResult"];
	var dates = JSON.parse(responseStatus);
	dates = dates.Table;
	console.log(dates);
};

function onDataInitialize(){
	var firstTime = $m.getPref("FirstTime");
	if(firstTime === undefined){
		initializeData();
		$m.putPref("FirstTime", 1);
		getHoldingDetails();
		$m.savePref();
	}
	else{
		var callbackForRecordDates = function(resp){
			var response = x2js.xml_str2json(resp.data);
			var result = response["Envelope"]["Body"]["GetLastRecordDatesResponse"]["GetLastRecordDatesResult"];
			
			result = JSON.parse(result);
			result = result.Table;
			sync_time_details.lastSync(function(resp){
				if(resp.rows[0].HOLDINGTIME != result[0].RECORDDATE && result[0].FLAG == "H"){
					getHoldingDetails();
				}
				if(resp.rows[0].INTERACTIONTIME != result[2].RECORDDATE && result[2].FLAG == "I"){
					insertInteraction();
				}
				getDates();
				$m.hideProgress();
			},function(res){
				$m.hideProgress();
				$m.alert("Error...");
			});
		};
		IRMServices.getLastRecordDates("", callbackForRecordDates);
		
	}
}

var callbackforSelectBox = function(resp){
	var response = x2js.xml_str2json(resp.data);	
	var responseStatus = response["Envelope"]["Body"]["P_GET_IRM_LOVResponse"]["P_GET_IRM_LOVResult"];
	//insertInteraction = JSON.parse(insertInteraction);
	var selectbox = JSON.parse(responseStatus);
	selectbox = selectbox.Table;
	var selectboxValue = [{
			name : "",
			children : []
		},{
			name : "",
			children : []
		},{
			name : "",
			children : []
		}];
	for(var i = 0; i<selectbox.length ; i++){
		switch(selectbox[i].TYPE){
			case 'D':
				if(selectbox[i].ORD_LEVEL == 1){
					if(selectbox[i].STATUS == "ALL"){
						selectbox[i].STATUS = "DOM-ALL";
						selectboxValue[1].children.push(selectbox[i].STATUS);	
					}
					else{
						selectboxValue[1].children.push(selectbox[i].STATUS);
						domestic.push("'"+selectbox[i].STATUS+"'");
					}
				}
				else
					selectboxValue[1].name = selectbox[i].STATUS;
					break;
			case 'F':
				if(selectbox[i].ORD_LEVEL == 1){
					if(selectbox[i].STATUS == "ALL"){
						selectbox[i].STATUS = "FOR-ALL";
						selectboxValue[2].children.push(selectbox[i].STATUS);	
					}
					else{
						selectboxValue[2].children.push(selectbox[i].STATUS);
						foreign.push("'"+selectbox[i].STATUS+"'");
					}
				}
				else
					selectboxValue[2].name = selectbox[i].STATUS;
					break;
			case 'A':
				if(selectbox[i].ORD_LEVEL == 1){
					selectboxValue[0].children.push(selectbox[i].STATUS);
				}
				else
					selectboxValue[0].name = selectbox[i].STATUS;
					break;
		}
	}
	$m.juci.dataset("filter", selectboxValue);
};

//var csv is the CSV file with headers
function csvJSON(csv){
	var lines=csv.split("\n");
	var result = [];
	var headers=lines[0].split(",");
	for(var i=1;i<lines.length;i++){
		var obj = {};
		var currentline=lines[i].split(",");
		for(var j=0;j<headers.length;j++){
			obj[headers[j]] = currentline[j];
		}
		result.push(obj);
	}
	//return result; //JavaScript object
	return JSON.stringify(result); //JSON
}

function getHoldingDetails(){
	var callback = function(resp){
		var response = x2js.xml_str2json(resp.data);
		var data = response["Envelope"]["Body"]["GetHoldingsDataResponse"]["GetHoldingsDataResult"];
		data = JSON.parse(data);
		data = data.Table;
		var holdingArray = [];
		for(var j=0;j<data.length;j++){
			data[j].SRNO = parseInt(j)+1;
			data[j].RECORDDATE = setDate(data[j].RECORDDATE);
			var holdingData = new holding_details(data[j]);
			holdingArray.push(holdingData);
		}
		holding_details.removeAll(function(res){
			holding_details.multipleReplace(holdingArray,function(resp){
				$m.hideProgress();
				Utils.PutPref("dataSyncTime", Utils.GetTimeStamp());
				$m.toast("Data saved successfully");
//				insertInteraction();
			},function(res){
				$m.hideProgress();
				$m.alert("failed to insert data");
			});
		},function(fresp){
			$m.hideProgress();
			$m.alert("failed to delete data");
		});	
	};
	$m.showProgress("Fetching Holding Data...");
	IRMServices.getHoldingData(new Date($m.juci.dataset("todays_date")),callback);
}

function insertInteraction(){
	var callback = function(resp){
		var response = x2js.xml_str2json(resp.data);
		var data = response["Envelope"]["Body"]["GetInteractionsDataResponse"]["GetInteractionsDataResult"];
		data = JSON.parse(data);
		data = data.Table;
		var interactionArray = [];
		for(var i=0;i<data.length;i++){
			data[i].DATE_OF_INT = setDate(data[i].DATE_OF_INT);
			if(data[i].FUND_NAME){
				data[i].FUND_NAME = data[i].FUND_NAME.toUpperCase();	
			}
			var interactiondata = new interaction_details(data[i]);
			interactionArray.push(interactiondata);
		}
		interaction_details.removeAll(function(response){
			interaction_details.multipleReplace(interactionArray,function(resp){
				$m.hideProgress();
				$m.toast("Data saved successfully");
//				getHoldingData();
			},function(res){
				$m.hideProgress();
				$m.alert("failed to insert data");
			});
		});	
	};
	$m.showProgress("Fetching Interaction Data...");
	IRMServices.getInteractionData(new Date($m.juci.dataset("todays_date")),callback);
}

function getLastSyncDetails(){
	var callback = function(resp){
		var response = x2js.xml_str2json(resp.data);
		var data = response["Envelope"]["Body"]["GetLastRecordDatesResponse"]["GetLastRecordDatesResult"];
		data = JSON.parse(data);
		data = data.Table;
		var newdates = [];
		$m.juci.dataset("todays_date", new Date(data[0].RECORDDATE));
		var temp = {
			"HOLDINGTIME" : "",
			"MASTERTIME" : "",
			"INTERACTIONTIME" : ""
		};
		for(var i=0;i<data.length;i++){
			if(data[i].FLAG == "H")
				temp.HOLDINGTIME = data[i].RECORDDATE;
			else{
				if(data[i].FLAG == "M")
					temp.MASTERTIME = data[i].RECORDDATE;
				else{
					temp.INTERACTIONTIME = data[i].RECORDDATE;
				}
			}
			var datesdata = new sync_time_details(temp); 
		}
		newdates.push(datesdata);
		sync_time_details.removeAll(function(response){
			sync_time_details.multipleReplace(newdates,function(resp){
				$m.hideProgress();
				$m.toast("Data saved successfully");
//				getHoldingData();
			},function(res){
				$m.hideProgress();
				$m.alert("failed to insert data");
			});
		});	
	};
	$m.showProgress("Fetching Dates Data...");
	IRMServices.getLastRecordDates("",callback);
}

function getDates(){
	var callback = function(resp){
		var response = x2js.xml_str2json(resp.data);
		var data = response["Envelope"]["Body"]["GETDATESResponse"]["GETDATESResult"];
		data = JSON.parse(data);
		data = data.Table;
		var newdates = [];
		for(var i=0;i<data.length;i++){
			data[i].RECORDDATE = data[i].RECORDDATE;
//			data[i].DISPLAYDATE = String(data[i].DISPLAYDATE);
			var datesdata = new applicable_dates(data[i]);
			newdates.push(datesdata); 
		}
		applicable_dates.removeAll(function(response){
			applicable_dates.multipleReplace(newdates,function(resp){
				$m.hideProgress();
				$m.toast("Data saved successfully");
				getLastSyncDetails();
//				getHoldingData();
			},function(res){
				$m.hideProgress();
				$m.alert("failed to insert data");
			});
		});	
	};
	$m.showProgress("Fetching Dates Data...");
	IRMServices.getDates("",callback);
}

function searchHoldingData(){
	var togglePage = "";
	var currentToggle = $m.juci.dataset("toggleVisible");
	$('#body_start').css('position','relative');
	var fundmanager = $m.juci.dataset("managerName");
	if(!fundmanager){
		$m.alert("Please enter value");
		return;
	}
	var data = {
		"toggle" : currentToggle,
		"value" : fundmanager.toUpperCase()
	};
	switch(currentToggle){
		case 'fund-manager':
			getHoldingData();
			togglePage = "fund-manager";
			break;
		case 'group-name':
			getGroupName();
			togglePage = "group-name";
			break;
		case 'country':
			getCountry();
			togglePage = "country";
			break;
		case 'city':
			getCity();
			togglePage = "city";
			break;
		case 'buyers':
			$('.header_date').css('display','none');
			var buyersResult = [];
			if(buyers.length === 0){
				$m.alert("Please search buyers First");
				return;
			}
			else{
				for(var i = 0 ; i < buyers.length ; i++){
					if(data.value === buyers[i].FUNDMANAGER){
						buyersResult.push(buyers[i]);
					}
				}
			}
			$m.juci.dataset("buyerss", []);
			$m.juci.dataset("buyerss", buyersResult);
			togglePage = "buyers";
			break;
		case 'sellers':
			$('.header_date').css('display','none');
			var sellersResult = [];
			if(sellers.length === 0){
				$m.alert("Please search sellers First");
				return;
			}
			else{
				for(var i = 0 ; i < sellers.length ; i++){
					if(data.value === sellers[i].FUNDMANAGER){
						sellersResult.push(sellers[i]);
					}
				}
			}
			$m.juci.dataset("sellerss", []);
			$m.juci.dataset("sellerss", sellersResult);
			togglePage = "sellers";
			break;
	}
	$m.juci.dataset("toggleVisible",togglePage);
}

function showFundList(event){
	var selectedHeader = $m.juci.dataset("selectedFilter").name;
		
	var toggleName;
	switch($m.juci.dataset("toggleVisible")){
		case 'fund-manager':
			toggleName = "FUNDMANAGER";
			break;
		case 'group-name':
			toggleName = "GROUPNAME";
			break;
		case 'country':
			toggleName = "COUNTRY";
			break;
		case 'city':
			toggleName = "CITY";
			break;
		case 'buyers':
			toggleName = "FUNDMANAGER";
			break;
		case 'sellers':
			toggleName = "FUNDMANAGER";
			break;
	}
	var data = {
		"date" : $m.juci.dataset("todays_date"),
		"selectedvalue" : $m.juci.dataset("selectedFilter"),
		"currentToggle" : toggleName
	};
	$m.showProgress("Fetching data...");
	if($m.juci.dataset("toggleVisible") == "buyers" || $m.juci.dataset("toggleVisible") == "sellers"){
		if($m.juci.dataset("toggleVisible") == "buyers"){
			if($m.juci.dataset("buyerss").length === 0){
				$m.hideProgress();
				$m.alert("Please search buyers first");
				return;
			}
			else{
				getBuyers();
			}
		}
		else{
			if($m.juci.dataset("sellerss").length == 0){
				$m.alert("Please search sellers first");
				$m.hideProgress();
				return;
			}
			else{
				getSellers();
			}
		}
	}
	else{
		var callbackForHoldingData = function(resp){
			var response = x2js.xml_str2json(resp.data);
			var result = response["Envelope"]["Body"]["GetTop15HoldingsDataByStatusResponse"]["GetTop15HoldingsDataByStatusResult"];
			
			result = JSON.parse(result);
			result = result.Table;
			var fundManagerArray = [], groupNameArray = [], countryArray = [], cityArray = [];
			for(var i=0;i<result.length;i++){
				switch(result[i].TTYPE){
					case 'FUNDMANAGER':
						fundManagerArray.push(result[i]);
						break;
					case 'GROUPNAME':
						groupNameArray.push(result[i]);
						break;
					case 'COUNTRY':
						countryArray.push(result[i]);
						break;
					case 'CITY':
						cityArray.push(result[i]);
						break;
				}
			}
			$m.juci.dataset("fundManager", fundManagerArray);
			$m.juci.dataset("groupName", groupNameArray);
			$m.juci.dataset("country", countryArray);
			$m.juci.dataset("cityList", cityArray);
			$m.hideProgress();
		};
		var status = $m.juci.dataset("selectedFilter");
		if(status.name){
			switch(status.name){
				case 'ALL':
					status = status.name;
					break;
				case 'DOMESTIC':
					status = "DOM-ALL";
					break;
				case 'FOREIGN':
					status = "FOR-ALL";
					break;
			}
		}
		var data = {
			"DATES" : new Date($m.juci.dataset("todays_date")),
			"STATUS" : status
		};
		IRMServices.getFundMangerByStatus(data, callbackForHoldingData);
	}
}

function initializeData(callback){
	var dbhelpercallback = function(dbhelper) {
        if (dbhelper) {
			interaction_details.createTable(create_table_success, create_table_failure);
			holding_details.createTable(create_table_success, create_table_failure);
			applicable_dates.createTable(create_table_success, create_table_failure);
			sync_time_details.createTable(create_table_success, create_table_failure);
			callback();
        } else {
            $m.alert("Error while opening database");
        }
    };
    getDbhelper(dbhelpercallback);
}

function create_table_success(res) {
	$m.logInfo("Table created successfully");
	$m.toast("Tables created successfully!");
}

function create_table_failure(res) {
	$m.logError("Failed to create table --- " + JSON.stringify(res));
}

function toggleData(){
	var buttonClickedId = event.newToggled;
	var togglePage = "";
	switch(buttonClickedId){
		case 0:
			$('.header_date').css('display','block');
			togglePage = "fund-manager";
			break;
		case 1:
			$('.header_date').css('display','block');
			togglePage = "group-name";
			break;
		case 2:
			$('.header_date').css('display','block');
			togglePage = "country";
			break;
		case 3:
			$('.header_date').css('display','block');
			togglePage = "city";
			setCities();
			break;
		case 4:
			$('.header_date').css('display','none');
			togglePage = "buyers";
		
			$m.juci.dataset("buyerss", []);
			$m.juci.dataset("buyersDate", []);
			$m.alert("Please select date range.");
			break;
		case 5:
			$('.header_date').css('display','none');
			togglePage = "sellers";
			$m.juci.dataset("sellerss", []);
			$m.juci.dataset("sellersDate", []);
			$m.alert("Please select date range.");
			break;
	}
	$m.juci.dataset("toggleVisible",togglePage);
}


function getBuyers(){
	var Dates = $m.juci.dataset("buyersDate");
	if(Dates[0] === undefined || Dates[1] === undefined){
		$m.alert("Please select date range");
		return;
	}
	if(Dates[0] === null || Dates[1] === null){
		if(Dates[0] === null){
			$m.alert("Please select From Date");
			return;
		}
		else{
			$m.alert("Please select To Date");
			return;
		}
	}
	if(Dates[0] > Dates[1]){
		$m.alert("From Date Should be less than To Date");
		return;
	}
	var status = $m.juci.dataset("selectedFilter");
	if(status.name){
		switch(status.name){
			case 'ALL':
				status = status.name;
				break;
			case 'DOMESTIC':
				status = "DOM-ALL";
				break;
			case 'FOREIGN':
				status = "FOR-ALL";
				break;
		}
	}
	var data = {
		"TYPE" : "BUYERS",
		"DATES" : Dates,
		"STATUS" : status,
		"FLAG" : "B"
	};
	var callbackForBuyers = function(resp){
		var response = x2js.xml_str2json(resp.data);
		var result = response["Envelope"]["Body"]["GetTop15BuyerSellerResponse"]["GetTop15BuyerSellerResult"];
		
		result = JSON.parse(result);
		result = result.Table;
		if(result.length < 1){
			$m.alert("No buyers found.");
		}
		$m.hideProgress();
		$m.juci.dataset("buyerss", []);
		$m.juci.dataset("buyerss", result);
	};
	$m.showProgress("Fetching Buyers...");
	IRMServices.getBuyersSellers(data, callbackForBuyers);
}


function getSellers(){
	var Dates = $m.juci.dataset("sellersDate");
	if(Dates[0] === undefined || Dates[1] === undefined){
		$m.alert("Please select date range");
		return;
	}
	if(Dates[0] === null || Dates[1] === null){
		if(Dates[0] === null){
			$m.alert("Please select From Date");
			return;
		}
		else{
			$m.alert("Please select To Date");
			return;
		}
	}
	if(Dates[0] > Dates[1]){
		$m.alert("From Date Should be less than To Date");
		return;
	}
	var status = $m.juci.dataset("selectedFilter");
	if(status.name){
		switch(status.name){
			case 'ALL':
				status = status.name;
				break;
			case 'DOMESTIC':
				status = "DOM-ALL";
				break;
			case 'FOREIGN':
				status = "FOR-ALL";
				break;
		}
	}
	var data = {
		"TYPE" : "SELLERS",
		"DATES" : Dates,
		"STATUS" : status,
		"FLAG" : "S"
	};
	var callbackForSellers = function(resp){
		var response = x2js.xml_str2json(resp.data);
		var result = response["Envelope"]["Body"]["GetTop15BuyerSellerResponse"]["GetTop15BuyerSellerResult"];
		
		result = JSON.parse(result);
		result = result.Table;
		if(result.length < 1){
			$m.alert("No buyers found.");
		}
		$m.hideProgress();
		$m.juci.dataset("sellerss", []);
		$m.juci.dataset("sellerss", result);
	};
	$m.showProgress("Fetching Sellers...");
	IRMServices.getBuyersSellers(data, callbackForSellers);	
}

function getFriday(){
	var t = new Date().getDate() + (6 - new Date().getDay() - 1) - 7 ;
	var d = new Date();
	var friday = d.setDate(t);
}


function checkRecordDate(recordate){
	var lastfriday = getLastFridayOf();
	if(recordate == lastfriday){
		return true;
	}
	var timeDiff = Math.abs(friday.getTime() - recordate.getTime());
	var diffDays = Math.ceil(timeDiff / (1000 * 3600 * 24)); 
	if(diffDays == 7){
		return true;
	}
	else{
		return false;
	}
}

function getLastFridayOf() {
    var d = new Date();
    day = d.getDay();
    // diff = (day <= 5) ? (7 - 5 + day ) : (day - 5);
    var diff = (7 - 5 + day) % 7;
    d.setDate(d.getDate() - diff);
    d.setHours(0);
    d.setMinutes(0);
    d.setSeconds(0);
    return new Date(d.getTime()).toString("yyyy-MM-dd");
}

function getLastFriday(d) {
    day = d.getDay();
    // diff = (day <= 5) ? (7 - 5 + day ) : (day - 5);
    var diff = (7 - 5 + day) % 7;
    d.setDate(d.getDate() - diff);
    d.setHours(0);
    d.setMinutes(0);
    d.setSeconds(0);
    return new Date(d.getTime()).toString("yyyy-MM-dd");
}

function deleteDuplicate(array){
	var obj = {};
	for ( var i=0; i < array.length; i++ ){
		obj[array[i]['SRNO']] = array[i];
	}
	array = new Array();
	for ( var key in obj ){
		array.push(obj[key]);
	}
	return array;
}

function getDateDiff(date1,date2,failcondition){
	date1 = new Date(date1);
	date2 = new Date(date2);
	var timeDiff = Math.abs(date1.getTime() - date2.getTime());
	var diffDays = Math.ceil(timeDiff / (1000 * 3600 * 24)); 
	if(diffDays == 7 || diffDays == 14 || diffDays == 21){
		return true;
	}
	else{
		return false;
	}
}

function setCities(){
	$m.showProgress("Fetching Cities...");
	holding_details.syncCities($m.juci.dataset("todays_date"),function(res){
		
		for(var i = 0 ; i < res.rows.length ; i++){
			res.rows[i].PERCENTAGE = res.rows[i].PERCENTAGE.toFixed(5);
		}
		console.log(res.rows);
		$m.hideProgress();
		for(var i = 0 ; i < res.rows.length ; i++){
			if(res.rows[i].STATUS == "BANK"){
				res.rows[i].STATUS = "BNK";
			}
			if(res.rows[i].STATUS == "CORP"){
				res.rows[i].STATUS = "CRP";
			}
			if(res.rows[i].STATUS == "TRUSTS"){
				res.rows[i].STATUS = "TRS";
			}
		}
		$m.juci.dataset("cityList", res.rows);
	},function(fres){
		$m.hideProgress();
		$m.alert("fail to fetch data");
	})
}

function getHoldingData(){
	var callbackforHoldingData = function(resp){
		var response = x2js.xml_str2json(resp.data);
		var result = response["Envelope"]["Body"]["GetHoldingsDataResponse"]["GetHoldingsDataResult"];
		
		result = JSON.parse(result);
		$m.hideProgress();
	};
	$m.showProgress("Fetching Holding data...");
	IRMServices.getHoldingData(new Date($m.juci.dataset("todays_date")), callbackforHoldingData);
}

function getDbhelper(callback) {
    new window.DB(Constants.DBName, function(db) {
        window.dbHelper = db;
        dbHelper = db;
        callback(window.dbHelper);
    }, function(error) {
        $m.logError("Unable to open database due to -- " + JSON.stringify(error));
    });
}


function setDate(recorddate){
	if(recorddate){
		recorddate = recorddate.slice(0,10);
		var datesplit = recorddate.split("-");
		var newdate = datesplit[0]+"-"+datesplit[1]+"-"+datesplit[2];
		return newdate;
	}
	else{
		return "1970-01-01";
	}
}

function getDatePref(){
	var flag = false;
	var prefDate = Utils.GetPref("dataSyncTime");
	if(!prefDate){
		return true;
	}
	var today = new Date().getTime();
	var currentdate = new Date(today).getDate();
	prefDate = new Date(prefDate).getDate();
	if(prefDate != currentdate){
		flag = true;
	}
	return flag;
}

function setChart(data,fundmanager){
   Highcharts.stockChart('container', {
        rangeSelector: {
            selected: 1
        },
        title: {
            text: ''
        },
        yAxis: {
	    	 title: {
	            text: 'SHARES HOLDING PERCENTAGE'
	        },
		    labels: {
		        format: '{value:.2f}'
		    }
		},

        series: [{
            name: fundmanager,
            data: data,
            tooltip: {
                valueDecimals: 2
            }
        }],
        exporting: { enabled: false }
    });
}

function dateSync(event){
	event.stopPropagation();
	event.preventDefault();
	
	if($m.juci.dataset("toggleVisible" == "buyers")){
		getBuyers();
	}
	else if($m.juci.dataset("toggleVisible" == "sellers")){
		getSellers();
	}
	else{
		var callbackForHoldingData = function(resp){
			var response = x2js.xml_str2json(resp.data);
			var result = response["Envelope"]["Body"]["GetTop15HoldingsDataByStatusResponse"]["GetTop15HoldingsDataByStatusResult"];
			
			result = JSON.parse(result);
			result = result.Table;
			var fundManagerArray = [], groupNameArray = [], countryArray = [], cityArray = [];
			for(var i=0;i<result.length;i++){
				switch(result[i].TTYPE){
					case 'FUNDMANAGER':
						fundManagerArray.push(result[i]);
						break;
					case 'GROUPNAME':
						groupNameArray.push(result[i]);
						break;
					case 'COUNTRY':
						countryArray.push(result[i]);
						break;
					case 'CITY':
						cityArray.push(result[i]);
						break;
				}
			}
			$m.juci.dataset("fundManager", fundManagerArray);
			$m.juci.dataset("groupName", groupNameArray);
			$m.juci.dataset("country", countryArray);
			$m.juci.dataset("cityList", cityArray);
			$m.hideProgress();
		};
		var status = $m.juci.dataset("selectedFilter");
		if(status.name){
			switch(status.name){
				case 'ALL':
					status = status.name;
					break;
				case 'DOMESTIC':
					status = "DOM-ALL";
					break;
				case 'FOREIGN':
					status = "FOR-ALL";
					break;
			}
		}
		var data = {
			"DATES" : new Date($m.juci.dataset("todays_date")),
			"STATUS" : status
		};
		IRMServices.getFundMangerByStatus(data, callbackForHoldingData);
	}
}

function date_color(event){
	if(event){
		var year = event.year;
		var month = event.month+1;
		var Fridays = [];
		var selectedDates = [];
		applicable_dates.selectAll(function(resp){
			for(var i=0;i<resp.rows.length;i++){
				Fridays.push(new Date(resp.rows[i].RECORDDATE));
			}
			for(var i = 0 ; i < Fridays.length ; i++){
			var temp = {
				"type":"custom",
				"date": Fridays[i],
				"text":"Friday",
				"class": "juci_date",
				"select":"true"
			};
			if(temp.date > new Date())
				temp.select = "false";
			temp.date = temp.date.toString("MM/dd/yyyy");
			selectedDates.push(temp);
		}
		event.control.setCustomDatesToSelect(selectedDates);
		}, function(fresp){
			$m.alert("Error...");
		});
	}
	setTimeout(function(){
		var todayDate = new Date();
		var a = juci.findByClass("juci_date");
		for(var i=0;i < a.length;i++){
			if(a.valueOf()[i].el.textContent == ""){
				a.valueOf()[i].el.style.background = "#f1f1f1";
			}
		}
	},1);
//	$m.juci.getControl("juci_calendar_panel").onclick(date_color());
}

function date_open(event){
	var Fridays = getFridays(new Date());
	var selectedDates = [];
	applicable_dates.selectAll(function(resp){
		for(var i=0;i<resp.rows.length;i++){
			Fridays.push(new Date(resp.rows[i].RECORDDATE));
		}
		for(var i = 0 ; i < Fridays.length ; i++){
			var temp = {
				"type":"custom",
				"date": Fridays[i],
				"text":"Friday",
				"class": "juci_date",
				"select":"true"
			};
			if(temp.date > new Date())
				temp.select = "false";
			temp.date = temp.date.toString("MM/dd/yyyy");
			selectedDates.push(temp);
		}
		event.control.setCustomDatesToSelect(selectedDates);
	}, function(fresp){
		$m.alert("Error...");
	});
	setTimeout(function(){
		var todayDate = new Date();
		var a = juci.findByClass("juci_date");
		for(var i=0;i < a.length;i++){
			if(a.valueOf()[i].el.textContent == ""){
				a.valueOf()[i].el.style.background = "#f1f1f1";
			}
		}
	},1);
//	$m.juci.getControl("juci_calendar_panel").onclick(date_color());
}

function sync(){
	var lastFriday = getLastFridayOf();
	$m.showProgress("Fecthing Holding data...");
	holding_details.dateSync(lastFriday, function(res){
		$m.hideProgress();
		//getInteractionData();
		},function(res){
			$m.hideProgress();
			//getInteractionData();
			$m.alert("Failed to fetch data");
	});
}

function redirectToInteractionList(event){
	$m.open("Searching...", "/IRM2/InteractionList.html", event.srcEvent.data.FUNDMANAGER)
}

function redirectToGroupInteractionList(event){
	$m.open("Searching...", "/IRM2/GroupInteractionList.html", event.srcEvent.data.GROUPNAME);	
}

function currentDate(){
	return new Date().toString("MM/dd/yyyy");
}

function redirectToCityDetails(event){
	$m.open("City Details","/IRM2/CityDetails.html", event.srcEvent.data.CITY);
}

function redirectToCountryDetails(event){
	$m.open("Country Details", "/IRM2/CountryDetails.html", event.srcEvent.data.COUNTRY);
}

function getFridays(date) {
    var d = date,
        month = d.getMonth(),
        fridays = [];

    d.setDate(1);

    // Get the first Friday in the month
    while (d.getDay() !== 5) {
        d.setDate(d.getDate() + 1);
    }

    // Get all the other Mondays in the month
    while (d.getMonth() === month) {
        fridays.push(new Date(d.getTime()));
        d.setDate(d.getDate() + 7);
    }
    return fridays;
}

function formatDate(data){
	return data.toString("dd-MMM-yyyy");
}

function validateDate(){
	var buyersDate = $m.juci.dataset("buyersDate");
	var sellersDate = $m.juci.dataset(sellersDate);
	
	if(buyersDate[1]){
		if(!buyersDate[0]){
			$m.alert("From Date is Manadatory");
		}
	}
}

function getCountry(){
//	$m.showProgress("Fetching Countries...");
//	IRMServices.
}